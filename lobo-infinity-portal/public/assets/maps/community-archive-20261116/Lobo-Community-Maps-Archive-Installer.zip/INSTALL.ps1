param([string]$TtsRoot)
$ErrorActionPreference = 'Stop'
if (-not $TtsRoot) { $TtsRoot = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'My Games\Tabletop Simulator' }
$source = Join-Path $PSScriptRoot 'Lobo-Community-Archive-Ready.json'
if ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToLowerInvariant() -ne 'a0cb7797e2a60bd31e870c2a881439fb0fa038e4fff0193489bdb894f69831f9') { throw 'Save integrity check failed. Extract the complete installer again.' }
$saves = Join-Path $TtsRoot 'Saves'
$objects = Join-Path $saves 'Saved Objects'
New-Item -ItemType Directory -Path $saves -Force | Out-Null
New-Item -ItemType Directory -Path $objects -Force | Out-Null
$slot = 1
do { $destination = Join-Path $saves ('TS_Save_' + $slot + '.json'); $slot++ } while (Test-Path -LiteralPath $destination)
Copy-Item -LiteralPath $source -Destination $destination
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'Lobo-Community-Maps-Archive.json') -Destination (Join-Path $objects 'Lobo-Community-Maps-Archive.json') -Force
if ((Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash.ToLowerInvariant() -ne 'a0cb7797e2a60bd31e870c2a881439fb0fa038e4fff0193489bdb894f69831f9') { throw 'Installed save verification failed.' }
Write-Host ''
Write-Host 'Installed: Lobo Infinity Maps - Community Archive' -ForegroundColor Green
Write-Host 'Open TTS > Games > Save & Load and load that save.'
Write-Host 'The brown Community Maps Archive bag contains all 21 older setups.'
Write-Host 'Then Upload > Workshop Upload > Update Workshop > item 3719263238.'
Write-Host 'Your other save slots have been preserved.'
if (-not $env:LOBO_INSTALLER_NO_BROWSER) { Start-Process 'https://steamcommunity.com/sharedfiles/filedetails/?id=3719263238' }
