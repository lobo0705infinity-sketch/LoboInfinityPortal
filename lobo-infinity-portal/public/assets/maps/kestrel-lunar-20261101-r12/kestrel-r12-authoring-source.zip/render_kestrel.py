import os
os.environ['PYOPENGL_PLATFORM']='egl'
os.environ.setdefault('EGL_PLATFORM','surfaceless')
from pathlib import Path
import numpy as np,json,math
np.infty=np.inf
from PIL import Image,ImageDraw,ImageFont
import pyrender,trimesh
ROOT=Path(__file__).resolve().parents[2]
A=ROOT/'r12/assets'
B=json.load(open(ROOT/'r12/assets/kestrel-lunar-data-harvest.json'))['ObjectStates'][0]
import sys
if '--interiors'in sys.argv:
 B['ContainedObjects']=[o.get('States',{}).get('2',o)for o in B['ContainedObjects']]
scene=pyrender.Scene(bg_color=[.09,.12,.14,1],ambient_light=[.35,.35,.35])
def material(image):return pyrender.MetallicRoughnessMaterial(baseColorTexture=pyrender.Texture(source=np.array(Image.open(image).convert('RGB')),source_channels='RGB',sampler=pyrender.Sampler(magFilter=9729,minFilter=9987)),metallicFactor=0,roughnessFactor=1,doubleSided=True)
materials={f:material(A/f)for f in ['station-materials.jpg','kestrel-ground.jpg','lunar-regolith-diffuse.jpg']}
materials['lunar-glass.png']=pyrender.MetallicRoughnessMaterial(baseColorFactor=[.62,.85,1,.28],metallicFactor=.05,roughnessFactor=.08,alphaMode='BLEND',doubleSided=True)
def tm(o):
 t=o['Transform'];r=trimesh.transformations.rotation_matrix(math.radians(t['rotY']),[0,1,0]);r[:3,:3]=r[:3,:3]@np.diag([t['scaleX'],t['scaleY'],t['scaleZ']]);r[:3,3]=[t['posX'],t['posY'],t['posZ']];return r
for o in B['ContainedObjects']:
 if o.get('CustomMesh') and not ('--interiors'in sys.argv and 'glass'in o.get('Tags',[])):
  p=A/o['CustomMesh']['MeshURL'].rsplit('/',1)[-1]
  mesh=trimesh.load(p,force='mesh',process=False)
  if 'ground-surface'in o.get('Tags',[])or 'native-world'in o.get('Tags',[]):mesh.apply_transform(np.diag([-1,1,1,1]))
  chosen=materials[o['CustomMesh']['DiffuseURL'].rsplit('/',1)[-1]]
  if any(t.startswith('crater-')for t in o.get('Tags',[])):
   tint=o['ColorDiffuse'];chosen=pyrender.MetallicRoughnessMaterial(baseColorTexture=chosen.baseColorTexture,baseColorFactor=[float(tint['r']),float(tint['g']),float(tint['b']),1.0],metallicFactor=0,roughnessFactor=1,doubleSided=True)
  scene.add(pyrender.Mesh.from_trimesh(mesh,material=chosen,smooth='ground-surface'in o.get('Tags',[])or 'native-world'in o.get('Tags',[])),pose=tm(o))
for z in [-20,0,20]:
 marker=trimesh.creation.cylinder(radius=.79,height=.30);marker.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[1,0,0]));marker.apply_translation([0,3.41,z]);marker.visual.vertex_colors=[237,170,68,255]
 scene.add(pyrender.Mesh.from_trimesh(marker))
def pose(eye,target):
 eye=np.array(eye,float);target=np.array(target,float);z=(eye-target);z/=np.linalg.norm(z);x=np.cross([0,1,0],z);x/=np.linalg.norm(x);y=np.cross(z,x);r=np.eye(4);r[:3,:3]=np.stack([x,y,z],axis=1);r[:3,3]=eye;return r
light=pyrender.DirectionalLight(color=np.ones(3),intensity=2.0);scene.add(light,pose=pose([10,45,-25],[0,0,0]))
renderer=pyrender.OffscreenRenderer(1600,1400)
views=[('Angled',[-49,60,54],34,[0,1.25,0]),('Overhead',[0,85,.01],27,[0,1.25,0])]
if '--detail'in sys.argv:views=[('Crater-Detail',[-29,16,-16],4.5,[-18.7,3.0,-8.8])]
for label,eye,mag,target in views:
 camera=pyrender.OrthographicCamera(xmag=mag*1600/1400,ymag=mag,zfar=200)
 node=scene.add(camera,pose=pose(eye,target))
 color,depth=renderer.render(scene,flags=pyrender.RenderFlags.SHADOWS_DIRECTIONAL)
 im=Image.fromarray(color);draw=ImageDraw.Draw(im)
 draw.rectangle((0,0,1600,100),fill=(20,31,37))
 font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',34)
 small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',20)
 draw.text((35,18),'KESTREL LUNAR BASE  /  LUNAR RESEARCH BASE',font=font,fill=(244,226,195))
 draw.text((37,65),'Data Harvest · 48 × 48 inches · Actual terrain geometry preview',font=small,fill=(181,203,215))
 target=ROOT/'r12/deliverables'/('Kestrel-Orbital-'+('Interior-'if '--interiors'in sys.argv else'')+label+'.png');temp=target.with_suffix('.render-final');im.save(temp,format='PNG');temp.replace(target);scene.remove_node(node)
renderer.delete()
print('Rendered two actual-geometry previews')
