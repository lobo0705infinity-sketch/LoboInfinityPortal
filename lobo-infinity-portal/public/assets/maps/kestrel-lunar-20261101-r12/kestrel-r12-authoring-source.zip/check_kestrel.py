from pathlib import Path
import json,math,re
import numpy as np
from shapely.geometry import Point,Polygon,box,LineString
from shapely.ops import unary_union
from lupa import LuaRuntime
R=Path(__file__).resolve().parents[2]
A=R/'r12/assets'
B=json.load(open(R/'r12/deliverables/Kestrel-Orbital-Data-Harvest.json'))['ObjectStates'][0]
layout=json.load(open(A/'layout.json'))
def objects(o):
 yield o
 for v in o.get('ContainedObjects',[]):yield from objects(v)
 for v in o.get('States',{}).values():yield from objects(v)
allobj=list(objects(B));ids=[o['GUID']for o in allobj]
assert len(ids)==len(set(ids)),'GUID collision'
records={line[2:].split(',')[0]:list(map(float,line.split(',')[1:]))for line in B['LuaScript'].splitlines()}
assert set(records)=={o['GUID']for o in B['ContainedObjects']}
for o in B['ContainedObjects']:
 assert all(abs(a-o['Transform'][k])<1e-5 for a,k in zip(records[o['GUID']],['posX','posY','posZ','rotX','rotY','rotZ']))
for o in allobj:
 assert o['Name']in {'Bag','Custom_Model','Custom_Assetbundle','BlockSquare'},('Invalid TTS prefab',o['Name'],o.get('Nickname'))
 if o is B:continue
 assert 'LoboMap:1008da'in o['Tags']
 if o.get('LuaScript'):LuaRuntime().execute('assert(load(...))',o['LuaScript'])
 if 'building'in o.get('Tags',[]):
  h=float(re.search(r'Height \(base to top\): ([\d.]+)',o['Description'])[1]);assert abs(h*4-round(h*4))<1e-6,(o['Nickname'],h)
 for typ in ['CustomMesh','CustomImage']:
  for key,u in o.get(typ,{}).items():
   if isinstance(u,str)and '/kestrel-lunar-20261101-r12/'in u:assert(A/u.rsplit('/',1)[-1]).exists(),u
# Verify exported collision meshes, including the backing formerly omitted
# from renders. A floor sample must stay recessed and unblocked by the anchor.
def meshdata(file):
 verts=[];faces=[];parts=[];part=[]
 for line in file.read_text().splitlines():
  if line.startswith('v '):verts.append(list(map(float,line.split()[1:])))
  elif line.startswith('o '):
   if part:parts.append(part)
   part=[]
  elif line.startswith('f '):
   f=[int(t.split('/')[0])-1 for t in line.split()[1:]];faces.append(f);part.append(f)
 if part:parts.append(part)
 v=np.asarray(verts)
 if file.read_text().startswith('# Kestrel native TTS ground'):
  v[:,0]*=-1;faces=[f[::-1]for f in faces];parts=[[f[::-1]for f in part]for part in parts]
 return v,faces,parts
maxRenderVertices=0;maxColliderTriangles=0
for file in A.glob('*.obj'):
 v,f,parts=meshdata(file)
 if file.name.endswith('-collider.obj'):
  maxColliderTriangles=max(maxColliderTriangles,max(map(len,parts)))
  assert all(len(part)<=255 and len({i for face in part for i in face})<=255 for part in parts),file.name
 else:maxRenderVertices=max(maxRenderVertices,len(v));assert len(v)<25000,file.name
anchor=next(o for o in B['ContainedObjects']if o['GUID']=='c70000')
assert anchor['Name']=='Custom_Model' and anchor['Transform']['scaleX']==1
v,_,_=meshdata(A/anchor['CustomMesh']['MeshURL'].rsplit('/',1)[-1])
assert v[:,1].max()+anchor['Transform']['posY']<layout['baseY']-1
assert all(o['CustomMesh']['MaterialIndex']==2 for o in allobj if o.get('CustomMesh') and not any(x in o['CustomMesh']['DiffuseURL']for x in ['kestrel-ground.jpg','lunar-regolith-diffuse.jpg']) and 'glass'not in o.get('Tags',[]))
def support(x,z):
 heights=[]
 for o in B['ContainedObjects']:
  if not o.get('CustomMesh'):continue
  v,faces,_=meshdata(A/o['CustomMesh']['ColliderURL'].rsplit('/',1)[-1])
  t=o['Transform'];a=math.radians(t['rotY']);rr=np.array([[math.cos(a),0,math.sin(a)],[0,1,0],[-math.sin(a),0,math.cos(a)]])
  v=v@rr.T+np.array([t['posX'],t['posY'],t['posZ']])
  for f in faces:
   q=v[f];xz=q[:,[0,2]];ab=np.column_stack([xz[1]-xz[0],xz[2]-xz[0]])
   if abs(np.linalg.det(ab))<1e-10:continue
   u,w=np.linalg.solve(ab,np.array([x,z])-xz[0])
   if u>=-1e-8 and w>=-1e-8 and u+w<=1+1e-8:heights.append(q[0,1]+u*(q[1,1]-q[0,1])+w*(q[2,1]-q[0,1]))
 return max(heights)
assert abs(support(-15,-8)-layout['baseY'])<1e-6
assert support(-10,-8)>layout['baseY'] # The new research dome occupies the former collector site.
assert abs(support(-1,-1)-layout['baseY'])<1e-6
ps=[(a,Polygon(a['polygon']))for a in layout['footprints']if a['kind']!='building-state']
for i,(a,p)in enumerate(ps):
 assert box(-24,-24,24,24).covers(p),a['name']+' outside table'
 for b,q in ps[i+1:]:assert p.intersection(q).area<.01,(a['name'],b['name'])
objectiveClearance=min(p.distance(Point(*c))for c in layout['techCoffins']for _,p in ps)
assert objectiveClearance>2.4,objectiveClearance
for x,z in layout['templatePads']:
 assert min(p.distance(Point(x,z))for _,p in ps)>=2.5,(x,z)
 assert box(-24,-24,24,24).boundary.distance(Point(x,z))>=2.5
 assert all(box(*t).distance(Point(x,z))>=2.5 for t in layout['trenches'])
 assert min(math.dist([x,z],c)for c in layout['techCoffins'])>3.29
block=unary_union([p for a,p in ps if a['height']>=.6])
terrainFootprints=[Polygon(p['polygon'])for p in layout['landforms']]
assert len(layout['landforms'])==24
for p in terrainFootprints:
 assert box(-24,-24,24,24).covers(p)
 assert all(p.distance(Point(*c))>2.4 for c in layout['techCoffins'])
# Ridges are traversable terrain. Treat actual high crests as obstacles,
# while retaining continuous geometric access around them for 40 mm bases.
ridgeCover=[];ridgeCore=[]
for o in B['ContainedObjects']:
 if 'ground-surface'not in o.get('Tags',[]):continue
 vv,ff,_=meshdata(A/o['CustomMesh']['MeshURL'].rsplit('/',1)[-1])
 for f in ff:
  q=vv[f]
  if np.cross(q[1]-q[0],q[2]-q[0])[1]<=1e-7:continue
  if min(q[:,1])>=layout['baseY']+.6:ridgeCover.append(Polygon(q[:,[0,2]]))
  if min(q[:,1])>=layout['baseY']+1.5:ridgeCore.append(Polygon(q[:,[0,2]]))
cover=unary_union([block,*ridgeCover]);routeBlock=unary_union([block,*ridgeCore])
free=box(-23.20,-23.20,23.20,23.20).difference(routeBlock.buffer(.79))
components=list(free.geoms)if hasattr(free,'geoms')else[free]
main=next(p for p in components if p.covers(Point(0,0)))
for point in layout['techCoffins']+layout['templatePads']:assert main.covers(Point(*point)),('unreachable',point)
for side in [-23.2,23.2]:
 exits=[z/2 for z in range(-46,47)if main.buffer(1e-7).covers(Point(side,z/2))]
 assert exits and max(exits)-min(exits)>12,'need two separated deployment exits'
grid={(i,j):(i/2,j/2)for i in range(-46,47)for j in range(-46,47)if main.covers(Point(i/2,j/2))}
paths=[set(grid)]
maxCover=max(cover.distance(Point(x,z))for x,z in grid.values());assert maxCover<6.01,maxCover
# The previous complete central firelane must be blocked by full-height servers.
assert block.intersection(LineString([(0,-24),(0,24)])).length>2
assert sum(o.get('Nickname')=='Tech-Coffin'for o in B['ContainedObjects'])==3
assert sum(o.get('Nickname','').startswith('Data-Harvester ')for o in B['ContainedObjects'])==0
# Exercise the actual TTS controller + embedded UI lifecycle broker, not a
# substitute implementation. Engine APIs are mocked; live physics is separate.
lua=LuaRuntime(unpack_returned_tuples=True)
def to_lua(v):return lua.table_from(v,recursive=True)if isinstance(v,(dict,list))else v
def from_lua(v):
 if hasattr(v,'items'):
  d={k:from_lua(x)for k,x in v.items()}
  if d and all(isinstance(k,int)for k in d)and set(d)==set(range(1,len(d)+1)):return [d[i]for i in range(1,len(d)+1)]
  return d
 return v
lua.globals().decode=lambda s:to_lua(json.loads(s))
lua.globals().encode=lambda v:json.dumps(from_lua(v))
lua.execute('''
JSON={decode=decode,encode=encode}; queue={};objects={};vars={};nativeNodes={};xml='';nextId=0;clock=0
UI={getXmlTable=function()return nativeNodes end,setXml=function(s)xml=s end,setXmlTable=function(n)nativeNodes=n end,getCustomAssets=function()return{}end,setAttribute=function()end,loading=false}
Wait={}
function Wait.time(fn,delay,reps) nextId=nextId+1;queue[nextId]={fn=fn,reps=reps,due=clock+math.max(1,math.ceil((delay or .1)*10)),interval=math.max(1,math.ceil((delay or .1)*10))};return nextId end
function Wait.frames(fn,frames)return Wait.time(fn,(frames or 1)/10)end
function Wait.condition(fn,cond,timeout,failed)local id;id=Wait.time(function()if cond()then Wait.stop(id);fn()end end,.1,-1);return id end
function Wait.stop(id)queue[id]=nil end
function pump(n)for tick=1,n do clock=clock+1;local ids={};for id in pairs(queue)do ids[#ids+1]=id end;table.sort(ids);for _,id in ipairs(ids)do local t=queue[id];if t and clock>=t.due then if t.reps~=-1 then queue[id]=nil else t.due=clock+t.interval end;t.fn()end end end end
Global={getVar=function(k)return vars[k]end,setVar=function(k,v)vars[k]=v end}
function getObjectFromGUID(g)return objects[g]end
function getObjectsWithTag(tag)local a={};for _,o in pairs(objects)do if o.hasTag and o.hasTag(tag)then a[#a+1]=o end end;return a end
function getAllObjects()local a={};for _,o in pairs(objects)do a[#a+1]=o end;return a end
function Vector(x,y,z)return{x=x,y=y,z=z}end
Grid={show_lines=true,snapping=2};Physics={cast=function()return{}end}
skyURL='original-sky';skyName='Original'
Backgrounds={getBackground=function()return skyName end,getCustomURL=function()return skyURL end,setBackground=function(v)skyName=v end,setCustomURL=function(v)skyURL=v end}
Lighting={ambient_intensity=1,light_intensity=1,reflection_intensity=.2}
for _,k in ipairs({'Sky','Equator','Ground'})do Lighting['getAmbient'..k..'Color']=function()return{1,1,1}end;Lighting['setAmbient'..k..'Color']=function()end end
Lighting.getLightColor=function()return{1,1,1}end;Lighting.setLightColor=function()end;Lighting.apply=function()end
function engineObject(guid,x,y,z)
 local o={};o.getGUID=function()return guid end;o.getPosition=function()return{x=x,y=y,z=z}end;o.isDestroyed=function()return false end
 o.setLock=function()end;o.setInvisibleTo=function()end;o.hasTag=function(t)return guid~='b00b00'and t=='LoboMap:1008da'end
 o.destruct=function()objects[guid]=nil end
 o.clearButtons=function()o.buttons={}end;o.createButton=function(p)o.buttons=o.buttons or{};o.buttons[#o.buttons+1]=p end
 o.addContextMenuItem=function(label,callback)o.menu=callback end
 o.getScale=function()return{x=1,y=1,z=1}end
 o.positionToLocal=function(p)return{x=p.x,y=p.y-.85,z=p.z}end
 o.setVectorLines=function(lines)o.lines=lines end
 o.getVectorLines=function()return o.lines or{}end
 o.positionToWorld=function(p)return{x=p.x,y=p.y+.85,z=p.z}end
 o.call=function(k,p)return _G[k](p)end
 objects[guid]=o;return o
end
self=engineObject('c70000',0,.85,0);mat=self
function spawnObjectData(p)
 local o=engineObject('b00b00',90,24,90)
 local env=setmetatable({self=o},{__index=_G})
 o.getVar=function(k)return env[k]end;o.call=function(k,p)return env[k](p)end
 Wait.frames(function()assert(load(p.data.LuaScript,'broker','t',env))();env.onLoad()end,4);brokerEnv=env;return o
end
''')
ctrl=next(o for o in B['ContainedObjects']if o['GUID']=='c70000')
lua.execute("stale=engineObject('bad004',90,24,90);stale.getVar=function(k)if k=='LOBO_UI_BROKER_VERSION'then return 4 end end;vars.LoboMapUIBrokerV4='bad004';UI.loading=true;Wait.frames(function()UI.loading=false end,18)")
lua.execute(ctrl['LuaScript']);lua.execute("onLoad('');pump(35)")
assert lua.globals().objects['bad004'] is None
assert lua.globals().Grid.show_lines is False
assert lua.globals().Grid.snapping==1
assert 'kestrel-day.jpg'in lua.globals().skyURL
assert 'Map Controls'in lua.globals().xml
assert len(lua.globals().self.buttons)==1
assert lua.globals().self.buttons[1].click_function=='loboReopenControls'
assert lua.globals().self.interactable is True
assert len(lua.globals().mat.lines)==0 # DZ controls start independently off.
lua.execute("loboUniversalDeployment0();pump(60)")
assert len(lua.globals().mat.lines)==4
lua.execute("loboUniversalDeployment4();pump(80);loboUniversalDeployment8();pump(100)")
lines=lua.globals().mat.lines;assert len(lines)==12
for idx in range(1,13):
 line=lines[idx];expected=.025 if idx%2 else .015
 assert abs(line.thickness-expected)<1e-8
 depth=[12,16,20][(idx-1)//4]
 sign=-1 if ((idx-1)//2)%2==0 else 1
 for _,p in line.points.items():assert abs(p[1]-sign*(24-depth))<1e-7
lua.execute("loboUniversalDeployment0();pump(100)")
assert len(lua.globals().mat.lines)==8 # +4/+8 survive when base DZ is hidden.
lua.execute("loboUniversalDeployment4();pump(100);loboUniversalDeployment8();pump(100)")
assert len(lua.globals().mat.lines)==0
lua.execute("loboUniversalDeployment0();loboUniversalDeployment4();pump(100)")
# Exercise actual drawer routing into independent, per-player reference charts.
lua.execute("loboDrawerAction({color='White'},nil,'loboMission_c70000_universal_booty');pump(3)")
lua.execute("loboDrawerAction({color='Blue'},nil,'loboMission_c70000_universal_metachemistry');pump(3)")
import xml.etree.ElementTree as ET
ui=ET.fromstring('<UI>'+lua.globals().xml+'</UI>')
booty=ui.find(".//*[@id='loboMission_c70000_universal_chart_booty']")
meta=ui.find(".//*[@id='loboMission_c70000_universal_chart_meta']")
assert booty is not None and booty.get('active')=='true'and booty.get('visibility')=='White'
assert meta is not None and meta.get('active')=='true'and meta.get('visibility')=='Blue'
assert 'ARM +1'in lua.globals().xml and 'PH +3'in lua.globals().xml
lua.execute("loboUniversalReferenceClose({color='White'});pump(3)")
ui=ET.fromstring('<UI>'+lua.globals().xml+'</UI>')
assert ui.find(".//*[@id='loboMission_c70000_universal_chart_booty']").get('active')=='false'
assert ui.find(".//*[@id='loboMission_c70000_universal_chart_meta']").get('visibility')=='Blue'
lua.execute("kestrelMission({color='White'});kestrelMission({color='Blue'});kestrelTab({color='White'},nil,'loboMission_c70000_tab5_White');pump(3)")
assert 'Lunar terrain and building states'in lua.globals().xml
assert 'Data Harvest | Kestrel Lunar Base'in lua.globals().xml
lua.execute("loboChooseBackground(nil,nil,'loboBackground_c70000_night');pump(2)")
assert 'kestrel-night.jpg'in lua.globals().skyURL
saved=json.loads(lua.globals().onSave());assert saved['loboUniversal']=={'0':True,'4':True,'8':False}
lua.execute("brokerEnv.loboDrawerClose({color='White'});pump(2);loboReopenControls(nil,'White');pump(2)")
ui=ET.fromstring('<UI>'+lua.globals().xml+'</UI>');panel=ui.find(".//*[@id='loboMapDrawerV1_panel']");assert 'White'in panel.get('visibility')
lua.execute('onDestroy();pump(2)')
assert lua.globals().skyURL=='original-sky'
assert 'kestrelMission'not in lua.globals().xml
# Execute each actual glazing script while toggling its roof-owner state.
for shell in [o for o in B['ContainedObjects']if 'glass'in o.get('Tags',[])]:
 gl=LuaRuntime(unpack_returned_tuples=True)
 gl.globals().decode=lambda s:gl.table_from(json.loads(s),recursive=True)
 gl.execute("""
 JSON={decode=decode};parentPresent=true;callbacks={};stopped=false
 self={setLock=function()end,setColorTint=function(c)tint=c end,setInvisibleTo=function(c)hidden=c end,setPosition=function(p)position=p end}
 Wait={time=function(fn)callbacks[#callbacks+1]=fn;return 1 end,frames=function(fn)callbacks[#callbacks+1]=fn end,stop=function()stopped=true end}
 function getObjectFromGUID(g)if parentPresent then return {isDestroyed=function()return false end,getPosition=function()return{x=0,y=2,z=0}end}end end
 function pump()for _,fn in ipairs(callbacks)do fn()end end
 """)
 gl.execute(shell['LuaScript']);gl.execute('onLoad();pump()')
 assert abs(gl.globals().position['x']-shell['Transform']['posX'])<1e-6
 assert len(gl.globals().hidden)==0 and gl.globals().tint[4]<.4
 gl.execute('parentPresent=false;pump()');assert gl.globals().position[1]==90 and len(gl.globals().hidden)==12
 gl.execute('parentPresent=true;pump()');assert abs(gl.globals().position['x']-shell['Transform']['posX'])<1e-6
 gl.execute('onDestroy()');assert gl.globals().stopped is True
report={'status':'passed','topLevelObjects':len(B['ContainedObjects']),'uniqueGUIDs':len(ids),'buildings':20,'interiorStates':25,'objectiveClearanceInches':round(objectiveClearance,3),'maxDistanceToCoverInches':round(maxCover,3),'templatePads':layout['templatePads'],'routingRadiusInches':.8,'reachableCells':len(paths[0]),'maximumRenderVertices':maxRenderVertices,'maximumColliderTrianglesPerPart':maxColliderTriangles,'checks':['all exported prefab names validated; no invalid Chip objects or supplied Data-Harvesters','actual glazing scripts park shells outside the board for interior states and restore them for roof-on states','collision rays confirm continuous lunar ground and elevated photovoltaic hardware; no trenches or bridges','six sunken crater bowls, six narrow lips and eighteen higher ridgelines; level building pads and 40 mm paths around landforms','hardware uses metal material; regolith is matte','no terrain overlaps or off-board pieces','objective access and four optional circular-template locations','40 mm base route connectivity','quarter-inch complete building heights','all Lua syntax','actual anchor-owned controller and embedded broker execution; physical recovery button; stale broker upgrade, delayed script load and delayed UI readiness','drawer open / grid off','12-inch DZ boundaries at X=+-12','world stroke widths .025/.015 inches','independent mission tabs','Booty/Metachemistry through actual drawer routing','DZ / +4 / +8 independently toggle at X=+-12/8/4','per-player reference visibility and close','deployment flags persist in onSave','day/night/off environment restoration','changed-state cleanup tags and native loader records'],'limitations':'Live Tabletop Simulator physics and multiplayer playtesting remain pending.'}
(R/'r12/deliverables/VALIDATION.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
