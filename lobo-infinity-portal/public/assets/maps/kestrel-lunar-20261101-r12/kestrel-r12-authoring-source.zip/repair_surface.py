"""Rebuild only lunar terrain; preserve every approved non-terrain object."""
from pathlib import Path
import json,copy,re,math
import numpy as np
import geometry as G
import lunar_landscape as LL
R=Path(__file__).resolve().parents[2];A=R/'r12/assets';D=R/'r12/deliverables';G.ASSET=A;G.MATS={'floor':(0,0,100,100)};G.ATLAS_SIZE=(1448,1086)
URL='https://raw.githubusercontent.com/lobo0705infinity-sketch/LoboInfinityPortal/main/lobo-infinity-portal/public/assets/maps/kestrel-lunar-20261101-r12/'
baseline=json.load(open(Path(__file__).parent/'Base-R11/kestrel-lunar-data-harvest.json'));bag=copy.deepcopy(baseline['ObjectStates'][0]);layout=json.load(open(Path(__file__).parent/'Base-R11/layout.json'))
terrain,height,floors,rims=LL.landscape(layout['footprints'],step=.3)
def box_uv(path):
 lines=path.read_text().splitlines();v=np.array([list(map(float,l.split()[1:]))for l in lines if l.startswith('v ')]);v[:,0]*=-1
 raw_normals=[tuple(map(float,l.split()[1:]))for l in lines if l.startswith('vn ')];normal_lookup={};normal_map=[];normals=[]
 for n in raw_normals:
  if n not in normal_lookup:normal_lookup[n]=len(normals)+1;normals.append(n)
  normal_map.append(normal_lookup[n])
 uv=[];lookup={};faces=[]
 for l in lines:
  if not l.startswith('f '):continue
  t=[p.split('/')for p in l.split()[1:]];ids=[int(p[0])-1 for p in t];ns=[int(p[2])-1 for p in t];q3=v[ids];n=np.cross(q3[1]-q3[0],q3[2]-q3[0]);axis=int(np.argmax(abs(n)));axes=[0,2]if axis==1 else[2,1]if axis==0 else[0,1];out=[]
  for p,i in zip(t,ids):
   q=tuple(round(float(x),9)for x in (v[i,axes]+24)/48)
   assert all(0<=x<=1 for x in q)
   if q not in lookup:lookup[q]=len(uv)+1;uv.append(q)
   out.append(p[0]+'/'+str(lookup[q])+'/'+str(normal_map[int(p[2])-1]))
  faces.append('f '+' '.join(out))
 out=[l for l in lines if not l.startswith(('vt ','vn ','f '))];out.extend('vt %.9f %.9f'%q for q in uv);out.extend('vn %.6f %.6f %.6f'%n for n in normals);out.extend(faces);path.write_text('\n'.join(out)+'\n')
def update(o,m,ground=False):
 fn=o['CustomMesh']['MeshURL'].split('/')[-1];m.write(fn[:-4]);o['CustomMesh'].update(MeshURL=URL+fn,ColliderURL=URL+fn.replace('.obj','-collider.obj'),DiffuseURL=URL+'lunar-regolith-diffuse.jpg',MaterialIndex=0)
 o['ColorDiffuse']={'r':1.0,'g':1.0,'b':1.0};o['CustomMesh']['CustomShader']['SpecularIntensity']=0
 o['Description']='Weathered lunar terrain. Impact bowls sink below grade; low, irregular ejecta lips blend into the dust. Use modeled geometry for movement and cover.'
 if ground:LL.finish_export(A,o,m)
 else:LL.clean_bowl_render(A,o)
 LL.native_obj(A,o);LL.surface_normals(A,o,height);box_uv(A/fn)
ground=[o for o in bag['ContainedObjects']if 'ground-surface'in o.get('Tags',[])];bowl=[o for o in bag['ContainedObjects']if 'crater-bowl'in o.get('Tags',[])];lip=[o for o in bag['ContainedObjects']if 'crater-rim'in o.get('Tags',[])]
for o,m in zip(ground,terrain):update(o,m,True)
for o,m in zip(bowl,floors):update(o,m)
for o,m in zip(lip,rims):update(o,m)
layout.update(landforms=LL.features(height),revision='R12',surfaceMaterial='Fine lunar regolith; world-scale box projection on steep faces',craterStyle='Weathered irregular rim and diffuse ejecta apron; no dark outline')
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,separators=(',',':'))+'\n')
write(A/'kestrel-lunar-data-harvest.json',{'ObjectStates':[bag]});write(A/'layout.json',layout);write(D/'Kestrel-Orbital-Data-Harvest.json',{'ObjectStates':[bag]})
changed={o['GUID']for o in ground+bowl+lip}
assert all(a==b for a,b in zip(baseline['ObjectStates'][0]['ContainedObjects'],bag['ContainedObjects'])if a['GUID']not in changed)
assert baseline['ObjectStates'][0]['LuaScript']==bag['LuaScript']
print('Updated sixteen terrain sections; all buildings, states, controls, objectives and layout preserved')
