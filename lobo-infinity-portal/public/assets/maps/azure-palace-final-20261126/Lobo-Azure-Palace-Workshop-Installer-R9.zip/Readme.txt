AZURE PALACE R9
Crossing Lines | Lobo Infinity Maps

Extract this ZIP and double-click Install.cmd.

To play, open Azure Palace R9 - Crossing Lines - Play Table under Games >
Save & Load. The terrain, console positions and six pieces of resort scatter
are already set up.

To update your existing Steam Workshop collection, open Lobo Maps - Azure
Palace R9 - Workshop Collection. In TTS choose Upload > Workshop Upload >
Update Workshop and select Lobo's Infinity Maps (3719263238). The collection
opens to the catalogue. Azure Palace and Veyra Gate each have their own
Crossing Lines entry. Use the catalogue's pickup button and place the copy
on the Stage to deploy it.

The installer uses new numbered save slots and adds the Azure Palace map bag
and optional furniture to Objects > Saved Objects. For a custom location,
drag your Tabletop Simulator data folder or its Saves folder onto Install.cmd.
