LOBO INFINITY MAPS | WORKSHOP COLLECTION R3

Extract the whole ZIP and double-click Install.cmd.
Open Games > Save & Load > Lobo Maps - MissionGeist R3 - Workshop Collection.

The Workshop save opens on the map catalogue. Choose a map and make a pickup copy. To play, save the copy and drop the bag on the stage in the normal Infinity mod. Map Controls > Mission gives you a copyable Mission Geist link and a private chat copy.

To update the Steam item, load the Workshop Collection save and choose Upload > Workshop Upload > Update Workshop > 3719263238.
This installer creates a new numbered save. Existing saves keep their original contents.

For a game, load the separate "Vanta Customs Yard - Play Table (MissionGeist R2)" save. The map is set up on the normal Infinity table.
