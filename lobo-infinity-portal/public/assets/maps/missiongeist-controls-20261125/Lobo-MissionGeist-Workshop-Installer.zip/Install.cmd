@echo off
setlocal
cd /d "%~dp0"
if exist "Files\payload.zip" goto run
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "Files\Download-Payload.ps1"
if errorlevel 1 (
  pause
  exit /b 1
)
:run
"%~dp0Lobo-MissionGeist-Setup.exe" %*
exit /b %ERRORLEVEL%
