$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$manifest = Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'download-manifest.json') | ConvertFrom-Json
$temp = Join-Path $PSScriptRoot ([Guid]::NewGuid().ToString() + '.tmp')
try {
    $stream = [IO.File]::Open($temp, [IO.FileMode]::CreateNew)
    try {
        $client = New-Object Net.WebClient
        try {
            foreach ($part in $manifest.parts) {
                Write-Host "Downloading $part"
                $bytes = $client.DownloadData($manifest.baseUrl + '/' + $part)
                $stream.Write($bytes, 0, $bytes.Length)
            }
        } finally { $client.Dispose() }
    } finally { $stream.Dispose() }
    if ((Get-FileHash -Algorithm SHA256 -LiteralPath $temp).Hash.ToLowerInvariant() -ne $manifest.sha256) {
        throw 'The downloaded payload failed verification. Run Install.cmd to retry.'
    }
    [IO.File]::Move($temp, (Join-Path $PSScriptRoot 'payload.zip'))
} finally { if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp } }
