Lobo Maps - MissionGeist Controls
Extract the whole ZIP and run Install.cmd. The installer creates a new numbered Tabletop Simulator save and opens the Steam Workshop page.
In TTS, use Games > Save & Load to load the new collection, then Map Controls > Mission. Each player gets a copyable MissionGeist URL and a private chat copy. Use Map Rules for the local terrain rules.
To publish to Steam, use Upload > Workshop Upload > Update Workshop and select the existing Lobo Maps item 3719263238.
Azure Palace and the alternate Top 40 Kestrel Lunar Base are in Objects > Saved Objects > Lobo MissionGeist. The collection includes Veyra Gate. The general collection opens Cloudbreak Array. Map-specific installers open their named map.
