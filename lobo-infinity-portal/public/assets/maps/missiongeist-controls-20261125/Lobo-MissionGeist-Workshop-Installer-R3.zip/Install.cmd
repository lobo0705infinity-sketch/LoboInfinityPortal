@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "Files\Download-Payload.ps1"
if errorlevel 1 (
  pause
  exit /b 1
)
"%~dp0Lobo-MissionGeist-Setup.exe" %*
exit /b %ERRORLEVEL%
