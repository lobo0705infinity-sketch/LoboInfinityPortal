LOBO INFINITY MAPS | WORKSHOP COLLECTION R4

Extract the whole ZIP and double-click Install.cmd.
Open Games > Save & Load > Lobo Maps - MissionGeist R4 - Workshop Collection.

The Workshop save opens on the map catalogue. Choose a map and make a pickup copy. To play, save the copy and drop the bag on the stage in the normal Infinity mod. Map Controls > Mission gives you a copyable Mission Geist link and a private chat copy.

To update the Steam item, load the Workshop Collection save and choose Upload > Workshop Upload > Update Workshop > 3719263238.
This installer creates a new numbered save. Existing saves keep their original contents.

TABLE TOOLS
The current maps load the LT-aware Order Panel and the R6 Infinity Army Spawner beside the board. The installer also provides Lobo Infinity Order Panel R3 in Saved Objects > Lobo MissionGeist for other tables.
