$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$manifest = Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'download-manifest.json') | ConvertFrom-Json
$target = Join-Path $PSScriptRoot 'payload.zip'
if ((Test-Path -LiteralPath $target) -and (Get-FileHash -Algorithm SHA256 -LiteralPath $target).Hash.ToLowerInvariant() -eq $manifest.sha256) { exit 0 }
$temp = Join-Path $PSScriptRoot ([Guid]::NewGuid().ToString() + '.tmp')
try {
    $stream = [IO.File]::Open($temp, [IO.FileMode]::CreateNew)
    try {
        $client = New-Object Net.WebClient
        try {
            foreach ($part in $manifest.parts) {
                Write-Host "Downloading $part"
                $bytes = $client.DownloadData($manifest.baseUrl + '/' + $part)
                $stream.Write($bytes, 0, $bytes.Length)
            }
        } finally { $client.Dispose() }
    } finally { $stream.Dispose() }
    if ((Get-FileHash -Algorithm SHA256 -LiteralPath $temp).Hash.ToLowerInvariant() -ne $manifest.sha256) {
        throw 'Download verification failed. Run Install.cmd to retry.'
    }
    if ([IO.File]::Exists($target)) {
        $backup = Join-Path $PSScriptRoot ([Guid]::NewGuid().ToString() + '.bak')
        [IO.File]::Replace($temp, $target, $backup)
        Remove-Item -LiteralPath $backup
    } else {
        [IO.File]::Move($temp, $target)
    }
} finally { if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp } }
