"""Purpose-built lunar pressure habitats, glass roofs and photovoltaic hardware."""
import math
import numpy as np
from shapely.geometry import Polygon,box
from shapely.ops import triangulate
import geometry as G
import orbital_geometry as O
from lunar_equipment import tube,cabinet,crate
TAU=math.tau

def ring(m,rx,rz,y,h,width=.12,mat='metal',n=32):
 for i in range(n):
  a=i*TAU/n;b=(i+1)*TAU/n
  p=[(r*math.cos(t),yy,s*math.sin(t))for r,s in [(rx,rz),(rx-width,rz-width)]for t in [a,b]for yy in [y,y+h]]
  O.solid(m,p,mat)

def pressure_floor(m,p,y,hatch=None):
 outer=Polygon(p);inner=outer.buffer(-.18,join_style=2)
 hole=box(hatch[0]-.68,hatch[1]-.68,hatch[0]+.68,hatch[1]+.68)if hatch else None
 for shape,mat in [(inner,'floor'),(outer.difference(inner),'metal')]:
  if hole is not None:shape=shape.difference(hole)
  for t in triangulate(shape):
   if shape.buffer(1e-8).covers(t):O.slab(m,list(t.exterior.coords)[:3],y,y+.16,mat)

def curved_wall(m,rx,rz,y,h,door=True,windows=True,n=24,entrances=1):
 for i in range(n):
  a=(i+.0)*TAU/n;b=(i+1)*TAU/n;mid=(a+b)/2
  front=(math.sin(mid)<-.84 and abs(rx*math.cos(mid))<1.12)or(entrances==4 and ((math.sin(mid)>.84 and abs(rx*math.cos(mid))<1.12)or(abs(math.cos(mid))>.84 and abs(rz*math.sin(mid))<1.12)))
  if front and door:levels=[(y+2.16,y+h)]
  elif windows and i%6 in [1,2,3] and not (math.sin(mid)>.5 and math.cos(mid)<0):levels=[(y,y+.85),(y+1.65,y+h)]
  else:levels=[(y,y+h)]
  for lo,hi in levels:
   if hi-lo>.01:O.solid(m,[(r*math.cos(t),yy,s*math.sin(t))for r,s in [(rx,rz),(rx-.16,rz-.16)]for t in [a,b]for yy in [lo,hi]],'wall')
  # Narrow pressure mullions and a continuous lower protection collar.
  if not(front and door):
   tube(m,[(rx*math.cos(a),y,rz*math.sin(a)),((rx-.1)*math.cos(a),y+h,(rz-.1)*math.sin(a))],.035,'silver',n=6)
 ring(m,rx+.055,rz+.055,y+.09,.10,.085,'metal',n)

def interior(m,rx,rz,y,role='lab'):
 # Partitions have door-width gaps; every exposed state retains useful furniture.
 if rx>2:
  m.cuboid((0,y+.85,rz*.44),(.10,1.7,rz*.65),'wall')
  m.cuboid((-rx*.56,y+.8,0),(rx*.40,1.6,.10),'wall')
 if role=='bio':
  for x in [-rx*.47,rx*.47]:
   m.cuboid((x,y+.40,.15),(.72,.64,rz*1.05),'silver')
   m.cuboid((x,y+.75,.15),(.62,.12,rz*1.02),'stone')
   for z in np.linspace(-rz*.35,rz*.5,5):
    tube(m,[(x,y+.8,float(z)),(x,y+1.12,float(z))],.025,'cloth',n=6)
    for side in [-1,1]:O.solid(m,[(x,y+1.07,z),(x+side*.25,y+1.20,z+.04),(x+side*.15,y+1.04,z+.17),(x,y+1.02,z+.05)],'cloth')
 else:
  cabinet(m,-rx*.52,y,rz*.38,.8,1.25,.48,'roof')
  m.cuboid((-rx*.47,y+.40,-rz*.35),(1.10,.80,.62),'metal')
  O.solid(m,[(-rx*.47-.55,y+.83,-rz*.35-.3),(-rx*.47+.55,y+.83,-rz*.35-.3),(-rx*.47-.55,y+1.01,-rz*.35+.25),(-rx*.47+.55,y+1.01,-rz*.35+.25),(-rx*.47-.55,y+.80,-rz*.35+.25),(-rx*.47+.55,y+.80,-rz*.35+.25)],'solar')
  m.cylinder((-rx*.47+.9,y+.25,-rz*.35),.22,.50,'metal',n=12)

def dome(m,g,rx,rz,y,rise,closed=True,door=False,entrances=1):
 # Each glass pane is a real thin convex part, separate from structural ribs.
 bands=7;slices=24
 def pt(t,a,inside=0):return ((rx-inside)*math.cos(t)*math.cos(a),y+(rise-inside)*math.sin(t),(rz-inside)*math.cos(t)*math.sin(a))
 for j in range(bands):
  t0=j*math.pi/2/bands;t1=(j+1)*math.pi/2/bands
  for i in range(slices):
   a=i*TAU/slices;b=(i+1)*TAU/slices
   mid=(a+b)/2
   front=(math.sin(mid)<-.85 and abs(rx*math.cos(mid))<1.10)or(entrances==4 and ((math.sin(mid)>.85 and abs(rx*math.cos(mid))<1.10)or(abs(math.cos(mid))>.85 and abs(rz*math.sin(mid))<1.10)))
   if door and front and y+rise*math.sin(t0)<2.18:continue
   p=[pt(t0,a),pt(t0,b),pt(t1,b),pt(t1,a)]
   # Alternate diagonal ribs form a visibly geodesic pressure framework.
   if closed:
    if i%2==0:tube(m,[p[0],p[3]],.035,'silver',n=6)
    if j%2==0:tube(m,[p[0],p[1]],.032,'metal',n=6)
    if (i+j)%3==0:tube(m,[p[0],p[2]],.024,'silver',n=6)
    if j<bands-1:O.solid(g,p+[pt(t0,a,.035),pt(t0,b,.035),pt(t1,b,.035),pt(t1,a,.035)],'solar')
    else:
     # Top triangles avoid degenerate four-point pole faces.
     O.solid(g,[p[0],p[1],p[2],pt(t0,a,.035),pt(t0,b,.035),pt(t1,b,.035)],'solar')
 if closed:
  m.cylinder((0,y+rise+.035,0),.31,.07,'metal',n=20)
 ring(m,rx+.03,rz+.03,y-.06,.13,.16,'metal')

def solar_panel(m,c,w,d,tilt=18,angle=0):
 # A photovoltaic table with actual cells, backing, frame and support hinges.
 cx,cy,cz=c;aa=math.radians(angle);tt=math.radians(tilt)
 def v(x,y,z):
  yy=y*math.cos(tt)-z*math.sin(tt);zz=y*math.sin(tt)+z*math.cos(tt)
  return (cx+x*math.cos(aa)+zz*math.sin(aa),cy+yy,cz-x*math.sin(aa)+zz*math.cos(aa))
 O.solid(m,[v(x,y,z)for x in [-w/2,w/2]for z in [-d/2,d/2]for y in [-.075,0]],'metal')
 cols=max(2,int(w/.5));rows=max(2,int(d/.5))
 for i in range(cols):
  for j in range(rows):
   x0=-w/2+i*w/cols+.025;x1=-w/2+(i+1)*w/cols-.025;z0=-d/2+j*d/rows+.025;z1=-d/2+(j+1)*d/rows-.025
   O.solid(m,[v(x,y,z)for x in [x0,x1]for z in [z0,z1]for y in [.012,.035]],'solar')
 for x in [-w/2,w/2]:tube(m,[v(x,0,-d/2),v(x,0,d/2)],.04,'silver',n=6)
 for z in [-d/2,d/2]:tube(m,[v(-w/2,0,z),v(w/2,0,z)],.04,'silver',n=6)

def habitat(w,d,floors,state,role):
 m=G.Mesh();glass=G.Mesh();rx=w/2-.22;rz=d/2-.25
 if role in ['Command','Observatory','Biolab']:
  bio=role=='Biolab';levels=floors if state<3 else 1
  for floor in range(levels):
   y=floor*2.5;rrx=rx if floor==0 else rx-.2;rrz=rz if floor==0 else rz-.2
   p=[(rrx*math.cos(i*TAU/32),rrz*math.sin(i*TAU/32))for i in range(32)]
   O.floor(m,p,y,hatch=(rx*.55,rz*.35)if floor else None)
   if floor==0 and not bio:curved_wall(m,rx,rz,y+.12,2.38)
   else:
    # Low opaque shielding plinth; glazing above it keeps the interior visible.
    for i in range(24):
     a=i*TAU/24;b=(i+1)*TAU/24;front=math.sin((a+b)/2)<-.84 and abs(rrx*math.cos((a+b)/2))<1.12
     if not front:O.solid(m,[(r*math.cos(t),yy,s*math.sin(t))for r,s in [(rrx,rrz),(rrx-.15,rrz-.15)]for t in [a,b]for yy in [y+.12,y+.75]],'wall')
   interior(m,rrx,rrz,y+.12,'bio'if bio else'lab')
  top=(floors-1)*2.5+.72
  if state==1:dome(m,glass,rx-.22,rz-.22,top,2.75 if floors>1 else 3.0,door=floors==1)
  if floors>1:
   G.ladder(m,rx*.55,rz*.35,2.7)
   G.ladder(m,-rx*.45,rz+.16,2.8)
  if role=='Command':
   # Cantilevered radiator petals and a crown antenna identify the command hub.
   for i in range(4):
    a=i*TAU/4+.4;x=(rx-.15)*math.cos(a);z=(rz-.15)*math.sin(a)
    m.cuboid((x,1.1,z),(.14,1.9,.6),'metal',angle=math.degrees(a))
  return m,glass
 if role in ['Crew','Workshop']:
  # Complete capsule silhouette, rather than an Earth-like flat wall plus roof.
  roof=state==1;rx=w/2-.24;length=d-.4;spring=1.15;rise=2.15
  p=O.poly(w-.45,d-.30,min(w,d)*.15);O.floor(m,p,0)
  for x in [-rx,rx]:
   for za,zb in [(-length/2,-.65),(.65,length/2)]:m.cuboid((x,.67,(za+zb)/2),(.14,1.10,zb-za),'wall')
   m.cuboid((x,1.10,0),(.14,.16,1.30),'silver')
  if roof:
   for i in range(36):
    a=i*math.pi/36;b=(i+1)*math.pi/36
    for z0,z1 in [(-length/2,length/2)]:
     p=[(rx*math.cos(t),spring+rise*math.sin(t),z)for t in [a,b]for z in [z0,z1]]
     O.solid(m,p+[(x,y-.10,z)for x,y,z in p],'wall')
    for z in np.linspace(-length/2+.1,length/2-.1,6):
     tube(m,[(rx*math.cos(a),spring+rise*math.sin(a)+.04,float(z)),(rx*math.cos(b),spring+rise*math.sin(b)+.04,float(z))],.035,'silver',n=6)
  for z,reverse in [(-length/2,False),(length/2,True)]:
   O.wall(m,(-rx,z),(rx,z),.12,2.05,door=not reverse,viewport=reverse,windowOffset=-.25)
   if roof:
    cap=[(rx*math.cos(i*math.pi/36),spring+rise*math.sin(i*math.pi/36))for i in range(37)]
    shape=Polygon(cap).intersection(box(-rx,2.16,rx,4.0))
    for tri in triangulate(shape):
     if shape.buffer(1e-6).covers(tri):O.solid(m,[(x,y,zz)for x,y in list(tri.exterior.coords)[:3]for zz in [z-.05,z+.05]],'roof')
  interior(m,rx,length/2,.12)
  # Beds and lockers are fixed against the rear, with a clear central route.
  if role=='Crew':
   for x in [-rx*.58,rx*.58]:
    m.cuboid((x,.45,length*.23),(.72,.55,1.65),'metal');m.cuboid((x,.75,length*.23),(.65,.14,1.5),'floor')
  elif roof:
   solar_panel(m,(0,3.65,0),w*.62,d*.62,14)
  G.ladder(m,rx*.35,length/2+.12,3.4)
  if roof:m.cuboid((rx*.35,3.40,length/2-.35),(1.15,.15,.85),'metal')
  return m,glass
 if role=='Lander':
  # A raised, faceted descent module on three independent landing struts.
  bodyx=rx*.76;bodyz=rz*.76;levels=floors if state<3 else 1
  for floor in range(levels):
   y=.42+floor*2.5;lower=1.0 if floor==0 else 1.10;upper=1.10 if floor==0 else .84
   p=[(bodyx*lower*math.cos(i*TAU/8),bodyz*lower*math.sin(i*TAU/8))for i in range(8)]
   pressure_floor(m,p,y,hatch=(bodyx*.46,bodyz*.40)if floor else None)
   for i,(a,b)in enumerate(zip(p,p[1:]+p[:1])):
    O.wall(m,a,b,y+.16,2.14,door=floor==0 and i==5,viewport=floor>0 and i not in [1,2],corner=False)
   # Swept shoulder panels above a lighter lower service ring.
   for i in range(8):
    a=i*TAU/8;b=(i+1)*TAU/8
    O.solid(m,[((bodyx*lower-.24)*math.cos(t),y+2.30,(bodyz*lower-.24)*math.sin(t))for t in [a,b]]+[(bodyx*upper*math.cos(t),y+2.50,bodyz*upper*math.sin(t))for t in [a,b]]+[((bodyx*lower-.31)*math.cos(t),y+2.30,(bodyz*lower-.31)*math.sin(t))for t in [a,b]]+[(bodyx*upper*.96*math.cos(t),y+2.50,bodyz*upper*.96*math.sin(t))for t in [a,b]],'silver')
   interior(m,bodyx,bodyz,y+.16)
  top=.42+floors*2.5
  if state==1:
   O.slab(m,[(bodyx*.84*math.cos(i*TAU/8),bodyz*.84*math.sin(i*TAU/8))for i in range(8)],top,top+.16,'roof')
   m.cuboid((0,top+.08,bodyz-.22),(1.25,.16,1.05),'metal')
   for sign in [-1,1]:solar_panel(m,(sign*.94,top+.42,-.6),1.40,1.10,sign*18,0)
   tube(m,[(0,top+.2,-.7),(0,top+1.15,-.7)],.055,'metal')
  for i in range(3):
   a=i*TAU/3+.3;x=rx*math.cos(a);z=rz*math.sin(a)
   tube(m,[(x*.56,1.65,z*.56),(x,.20,z)],.12,'metal')
   tube(m,[(x*.56,.55,z*.56),(x,.20,z)],.075,'silver')
   m.cylinder((x,.12,z),.30,.18,'metal',n=12)
  G.ladder(m,0,bodyz+.12,top+.35)
  if floors>1:G.ladder(m,bodyx*.46,bodyz*.40,2.9)
  return m,glass
 # A cylindrical service core with pressure windows, not rectangular buildings.
 levels=floors if state<3 else 1
 for floor in range(levels):
  y=floor*2.5;rrx=rx;rrz=rz
  p=[(rrx*math.cos(i*TAU/24),rrz*math.sin(i*TAU/24))for i in range(24)]
  pressure_floor(m,p,y,hatch=(rx*.45,rz*.35)if floor else None)
  curved_wall(m,rrx,rrz,y+.16,2.34)
  interior(m,rrx,rrz,y+.16)
  ring(m,rrx+.065,rrz+.065,y+2.34,.10,.085,'metal',n=24)
 top=floors*2.5
 if state==1:
  O.slab(m,[(rx*math.cos(i*TAU/24),rz*math.sin(i*TAU/24))for i in range(24)],top,top+.16,'roof')
  m.cuboid((-rx*.48,top+.08,rz-.20),(1.25,.16,.95),'metal')
  if role=='Cryo':
   # Layered thermal sunshield, clearly separate from the pressure vessel.
   for i in range(12):
    a=i*TAU/12;b=(i+1)*TAU/12
    O.solid(m,[(rx*.15*math.cos(t),top+.95,rz*.15*math.sin(t))for t in [a,b]]+[(rx*math.cos(t),top+.4,rz*math.sin(t))for t in [a,b]]+[(rx*.15*math.cos(t),top+.90,rz*.15*math.sin(t))for t in [a,b]]+[(rx*math.cos(t),top+.35,rz*math.sin(t))for t in [a,b]],'silver')
   ring(m,rx*.98,rz*.98,top+.18,.055,.28,'silver')
   ring(m,rx*.96,rz*.96,top+.06,.045,.30,'silver')
   for x in [-.65,.65]:m.cylinder((x,top+.6,0),.3,.65,'metal',n=16)
  elif role=='Comms':
   O.dish(m,top+.22)
   for sign in [-1,1]:solar_panel(m,(sign*rx*.6,top+.30,rz*.45),1.35,.8,24,sign*25)
  else:
   # Folded photovoltaic wings occupy the front half; the rear ladder
   # arrival and a 1.25-inch walking lane stay completely clear.
   for sign in [-1,1]:solar_panel(m,(sign*rx*.40,top+.42,-rz*.40),1.35,1.10,sign*18,0)
   tube(m,[(0,top+.15,-rz*.25),(0,top+1.20,-rz*.25)],.075,'metal')
 if role=='Tower':
  for i in range(8):
   a=(i+.5)*TAU/8
   # External fins stop short of door and window routes.
   x=(rx-.1)*math.cos(a);z=(rz-.1)*math.sin(a)
   if z>-.7*rz:m.cuboid((x,top*.48,z),(.09,top*.85,.38),'silver',angle=math.degrees(a))
 if role=='Lander':
  # Splayed landing struts and footpads are within the listed footprint.
  for i in range(3):
   a=i*TAU/3+.2;x=rx*math.cos(a);z=rz*math.sin(a)
   tube(m,[(x*.65,1.4,z*.65),(x,.18,z)],.13,'metal');m.cylinder((x,.12,z),.28,.18,'silver',n=12)
 G.ladder(m,-rx*.48,rz+.15,top+.3)
 if floors>1:G.ladder(m,rx*.45,rz*.35,2.5*(floors-1)+.3)
 return m,glass

def array_bank():
 m=G.Mesh()
 for x in [-1.22,1.22]:
  m.cuboid((x,.12,0),(.55,.24,2.6),'metal')
  for z in [-.8,.8]:tube(m,[(x,.24,z),(x,1.35,z*.65)],.08,'silver')
 solar_panel(m,(0,1.52,0),4.4,2.9,24)
 cabinet(m,0,.15,1.6,1.2,1.10,.45,'wall')
 return m

def campus_dome(w,d,state,role='Campus'):
 """Large four-room research dome with four open pressure entrances."""
 m=G.Mesh();g=G.Mesh();rx=w/2-.22;rz=d/2-.25
 p=[(rx*math.cos(i*TAU/32),rz*math.sin(i*TAU/32))for i in range(32)]
 pressure_floor(m,p,0)
 curved_wall(m,rx,rz,.16,.60,door=True,windows=False,entrances=4)
 if state==1:dome(m,g,rx-.08,rz-.08,.76,3.40,door=True,entrances=4)
 # Four actual airlock openings. The glass, plinth and door frames share the
 # same openings, so neither visual nor collision geometry seals a doorway.
 for a,b in [((-1.14,-rz),(1.14,-rz)),((1.14,rz),(-1.14,rz)),((-rx,1.14),(-rx,-1.14)),((rx,-1.14),(rx,1.14))]:
  O.ring(m,a,b,.16,2.3,0,1.24,1.82,2.12,True)
 # A two-inch-wide cross hallway links all four entrances. Four rooms have
 # real 1.8-inch openings from that hallway, plus lintels above the openings.
 for sx in [-1,1]:
  for sz in [-1,1]:
   end=rz*.78;doorcenter=rz*.49;half=.90
   for lo,hi in [(1.0,doorcenter-half),(doorcenter+half,end)]:
    if hi>lo:m.cuboid((sx,1.12,sz*(lo+hi)/2),(.10,1.92,hi-lo),'wall')
   m.cuboid((sx,2.15,sz*doorcenter),(.10,.20,1.8),'metal')
   m.cuboid((sx*(1+rx*.76)/2,1.12,sz),(rx*.76-1,1.92,.10),'wall')
 # Rear-left greenhouse: planters and seedlings behind a pressure partition.
 for x in [-rx*.64,-rx*.42]:
  m.cuboid((x,.48,rz*.53),(.60,.64,1.45),'silver')
  m.cuboid((x,.85,rz*.53),(.53,.10,1.32),'stone')
  for z in np.linspace(rz*.4,rz*.67,4):
   tube(m,[(x,.90,z),(x,1.18,z)],.025,'cloth',n=6)
   for sign in [-1,1]:O.solid(m,[(x,1.10,z),(x+sign*.17,1.22,z+.05),(x+sign*.12,1.08,z+.17),(x,1.05,z+.06)],'cloth')
 # Rear-right instrument lab: a console, equipment rack and sampling bench.
 cabinet(m,rx*.60,.16,rz*.58,.85,1.30,.55,'roof')
 m.cuboid((rx*.55,.57,rz*.35),(1.15,.82,.62),'metal')
 solar_panel(m,(rx*.55,1.03,rz*.35),1.0,.53,12)
 # Front-left medical room: a bed, pillow, wall cabinet and equipment pedestal.
 m.cuboid((-rx*.55,.46,-rz*.53),(1.05,.60,1.65),'metal')
 m.cuboid((-rx*.55,.82,-rz*.53),(.95,.13,1.55),'wall')
 m.cuboid((-rx*.55,.93,-rz*.68),(.78,.10,.35),'roof')
 cabinet(m,-rx*.74,.16,-rz*.30,.55,1.22,.45,'wall')
 # Front-right briefing room: a round table, work surface and two stools.
 m.cylinder((rx*.56,.56,-rz*.55),.62,.12,'roof',n=24)
 m.cylinder((rx*.56,.34,-rz*.55),.14,.35,'metal',n=12)
 for x in [rx*.39,rx*.73]:m.cylinder((x,.42,-rz*.55),.23,.52,'metal',n=12)
 return m,g

def transit_node(w,d,state):
 m=G.Mesh();g=G.Mesh();rx=w/2-.20;rz=d/2-.20
 p=[(rx*math.cos(i*TAU/24),rz*math.sin(i*TAU/24))for i in range(24)]
 pressure_floor(m,p,0);curved_wall(m,rx,rz,.16,2.34,entrances=4,windows=False)
 for a,b in [((-1.1,-rz),(1.1,-rz)),((1.1,rz),(-1.1,rz)),((-rx,1.1),(-rx,-1.1)),((rx,-1.1),(rx,1.1))]:O.ring(m,a,b,.16,2.34,0,1.24,1.8,2.12,True)
 cabinet(m,-rx*.63,.16,-rz*.63,.45,1.0,.42,'metal')
 cabinet(m,rx*.63,.16,rz*.63,.45,1.0,.42,'wall')
 if state==1:
  O.slab(m,p,2.5,2.66,'roof')
  solar_panel(m,(.6,2.94,-.45),1.5,1.25,16)
  tube(m,[(-.75,2.66,-.5),(-.75,3.35,-.5)],.06,'silver')
 # Ladder on a closed diagonal quadrant, away from all four entrances.
 G.ladder(m,-rx*.60,rz*.90+.12,2.85)
 return m,g
