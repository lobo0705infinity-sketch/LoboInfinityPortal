"""Continuous lunar impact basins and sinuous regolith ridges, in inches."""
import math
from functools import lru_cache
import numpy as np
from shapely.geometry import Point,Polygon,LineString
import geometry as G
import orbital_geometry as O
CRATERS=[{'name': 'Western impact crater', 'center': [-18.7, -8.8], 'radius': 2.45, 'depth': 0.85, 'rim': 0.36, 'breach': 0.35, 'rimWidth': 0.25}, {'name': 'Eastern survey crater', 'center': [19.3, 1.8], 'radius': 2.25, 'depth': 0.8, 'rim': 0.36, 'breach': 3.14159265, 'rimWidth': 0.25}, {'name': 'Northern impact crater', 'center': [-7, 21.4], 'radius': 1.8, 'depth': 0.8, 'rim': 0.3, 'breach': -1.57079633, 'rimWidth': 0.25}, {'name': 'Southern micro-impact crater', 'center': [-11.5, -22], 'radius': 1.4, 'depth': 0.65, 'rim': 0.3, 'breach': 1.2, 'rimWidth': 0.25}, {'name': 'Central survey crater', 'center': [6.7, 5.5], 'radius': 1.5, 'depth': 0.7, 'rim': 0.3, 'breach': -0.6, 'rimWidth': 0.25}, {'name': 'Southeast impact crater', 'center': [21, -11.8], 'radius': 1.35, 'depth': 0.65, 'rim': 0.3, 'breach': 2.2, 'rimWidth': 0.25}]
RIDGES=[{'name': 'Northwest ejecta ridge', 'points': [[-12.7, 7.8], [-11.3, 8.2], [-10.3, 8.7]], 'height': 2.8, 'width': 1.1}, {'name': 'Southern pressure ridge', 'points': [[1.7, -10], [2.5, -9.2], [2.8, -8.2]], 'height': 3.0, 'width': 1.15}, {'name': 'Eastern crater-wall ridge', 'points': [[15.1,9.3],[14.6,10],[14.2,11],[15.4,12.6]], 'height': 2.8, 'width': 1.25}, {'name': 'Western ejecta spine', 'points': [[-22, 8], [-22, 9.6], [-21.3, 11.2]], 'height': 2.6, 'width': 1.0}, {'name': 'Northern rim spine', 'points': [[-13, 21.8], [-11.8, 22.1], [-10, 22.5]], 'height': 3.0, 'width': 1.2}, {'name': 'Southeast ejecta ridge', 'points': [[14, -10.8], [15, -10.3], [16, -10.2]], 'height': 2.5, 'width': 1.1}, {'name': 'Southern apron ridge', 'points': [[4, -22.7], [6, -22.3], [8, -22.5]], 'height': 2.7, 'width': 0.9}, {'name': 'Northeast horizon ridge', 'points': [[13.5, 21.8], [14.5, 21.3], [15.6, 22]], 'height': 2.5, 'width': 0.9}, {'name': 'Southwest perimeter ridge', 'points': [[-22, -23], [-20, -23], [-18.5, -23.1]], 'height': 2.3, 'width': 0.8}, {'name': 'Central highland ridge', 'points': [[2.3, 7.8], [3.1, 8.3], [3.8, 8.7]], 'height': 2.7, 'width': 0.95}, {'name': 'Western crater approach', 'points': [[-22.8, -10], [-22.8, -8.5], [-22.6, -7]], 'height': 2.2, 'width': 0.65}, {'name': 'Eastern perimeter crest', 'points': [[22.8, 11.8], [22.6, 13.2], [22.7, 14.2]], 'height': 2.75, 'width': 0.65}, {'name': 'Northwest apron spine', 'points': [[-22, 13], [-22.8, 14], [-22.9, 15]], 'height': 2.25, 'width': 0.65}, {'name': 'Southern crater ray', 'points': [[-8.6, -22.8], [-7.5, -22.2], [-6, -22.7]], 'height': 2.5, 'width': 0.6}, {'name': 'Southern habitat buttress', 'points': [[-3.8, -19], [-3.2, -17.7], [-2.4, -17]], 'height': 2.75, 'width': 0.8}, {'name': 'Central eastern strata', 'points': [[9.5, 0.8], [10.5, 1], [11.5, 1.8]], 'height': 3.0, 'width': 1.0}, {'name': 'Reclamation highland spur', 'points': [[15.4, 4.7], [16.2, 5.3], [16.8, 6.2]], 'height': 2.75, 'width': 0.8}, {'name': 'Western service highland', 'points': [[-13.5,-1],[-12.5,-.5],[-11.8,.8],[-10.5,1.3],[-9.6,1.9]], 'height': 2.75, 'width': 0.8}]
def smooth(x):x=max(0.,min(1.,x));return x*x*(3-2*x)
TEMPLATE_PADS=[[-12,3],[-3,2],[7.5,1],[14.5,14]]
GRADE=3.25
BOTTOM=1.0

def crater(c,x,z):
 dx=x-c['center'][0];dz=z-c['center'][1];a=math.atan2(dz,dx)
 rough=1+.02*math.sin(3*a)+.012*math.sin(7*a)
 r=math.hypot(dx,dz)/(c['radius']*rough)
 if r>=1.18:return 0.
 bowl=-c['depth']*(1-smooth((r-.42)/.52))
 da=math.atan2(math.sin(a-c['breach']),math.cos(a-c['breach']))
 rim=c['rim']*math.exp(-((r-.98)/(c.get('rimWidth',.25)/c['radius']))**2)*(1-.75*math.exp(-(da/.3)**2))*smooth((1.18-r)/.12)
 return bowl+rim


_RIDGE_CACHE={}
def ridge(c,x,z):
 key=id(c)
 if key not in _RIDGE_CACHE:
  pts=c['points'];seg=[(a,b,math.hypot(b[0]-a[0],b[1]-a[1]))for a,b in zip(pts,pts[1:])];w=c['width'];_RIDGE_CACHE[key]=(min(p[0]for p in pts)-w,max(p[0]for p in pts)+w,min(p[1]for p in pts)-w,max(p[1]for p in pts)+w,seg,sum(v[2]for v in seg))
 x0,x1,z0,z1,segments,total=_RIDGE_CACHE[key]
 if x<x0 or x>x1 or z<z0 or z>z1:return 0.
 along=0.;best=(float('inf'),0.)
 for a,b,length in segments:
  dx=b[0]-a[0];dz=b[1]-a[1];t=max(0,min(1,((x-a[0])*dx+(z-a[1])*dz)/(length*length)));dist=math.hypot(x-a[0]-t*dx,z-a[1]-t*dz)
  if dist<best[0]:best=(dist,(along+t*length)/total)
  along+=length
 dist,t=best;width=c['width']*(.91+.09*math.sin(t*math.pi*3+.4));q=dist/width
 if q>=1:return 0.
 return c['height']*(1-smooth((q-.17)/.83))*(.30+.70*math.sin(math.pi*t)**.65)*(.91+.09*math.sin(t*math.pi*5+.7))

def landscape(footprints,step=.6):
 from shapely.ops import unary_union,triangulate
 pads=[Polygon(p['polygon'])for p in footprints if p['kind']!='building-state'];padUnion=unary_union(pads)
 @lru_cache(maxsize=None)
 def height(x,z):
  ridgeH=max(ridge(c,x,z)for c in RIDGES)
  ridgeH*=1+.025*math.sin(x*3.1+z*.8)*math.sin(z*2.3-x*.5)
  h=sum(crater(c,x,z)for c in CRATERS)+ridgeH
  if abs(h)<1e-9:return 0.
  dist=padUnion.distance(Point(x,z))
  templateDist=min(math.hypot(x-a,z-b)-2.9 for a,b in TEMPLATE_PADS)
  return h*smooth((dist-.90)/.65)*smooth(templateDist/.35)
 dark=[G.Mesh()for _ in CRATERS];rims=[G.Mesh()for _ in CRATERS]
 for m in dark+rims:m.world_texture=True
 ringPolygons=[]
 for c in CRATERS:
  def boundary(offset):
   pts=[]
   for a in np.linspace(0,math.tau,193)[:-1]:
    rough=1+.02*math.sin(3*a)+.012*math.sin(7*a);r=c['radius']*.98*rough+offset;pts.append((c['center'][0]+r*math.cos(a),c['center'][1]+r*math.sin(a)))
   return pts
  ringPolygons.append(Polygon(boundary(.20),[boundary(-.20)]))
 def pieces(tri):
  cx=sum(p[0]for p in tri)/3;cz=sum(p[1]for p in tri)/3
  for i,c in enumerate(CRATERS):
   if all(math.hypot(x-c['center'][0],z-c['center'][1])<c['radius']*.74 for x,z in tri):return [('floor',i,tri)]
   if math.hypot(cx-c['center'][0],cz-c['center'][1])<c['radius']+1:
    poly=Polygon(tri);ring=ringPolygons[i]
    if poly.intersects(ring):
     out=[]
     for kind,shape in [('ground',poly.difference(ring)),('rim',poly.intersection(ring))]:
      for part in (list(shape.geoms)if hasattr(shape,'geoms')else[shape]):
       if part.is_empty or part.area<1e-7:continue
       for t in triangulate(part):
        if t.area>1e-7 and part.buffer(1e-8).covers(t):out.append((kind,i,list(t.exterior.coords)[:3]))
     return out
  return [('ground',None,tri)]
 meshes=[]
 for ix in range(2):
  for iz in range(2):
   m=G.Mesh();m.world_texture=True;cm=G.Mesh();cm.world_texture=True
   count=round(24/step);xs=np.linspace(-24+ix*24,ix*24,count+1);zs=np.linspace(-24+iz*24,iz*24,count+1)
   for a,b in zip(xs,xs[1:]):
    for c,d in zip(zs,zs[1:]):
     for tri in [[(a,c),(b,c),(b,d)],[(a,c),(b,d),(a,d)]]:
      for kind,i,part in pieces(tri):
       target=m if kind=='ground'else(dark if kind=='floor'else rims)[i]
       O.solid(target,[(x,GRADE+height(float(x),float(z)),z)for x,z in part]+[(x,BOTTOM,z)for x,z in part],'floor')
   for c,d in zip(zs,zs[1:]):
    run=None
    for index,(a,b)in enumerate(zip(xs,xs[1:])):
     flat=all(abs(height(float(x),float(z)))<1e-9 for x in [a,b]for z in [c,d])and all(kind=='ground'for tri in [[(a,c),(b,c),(b,d)],[(a,c),(b,d),(a,d)]]for kind,i,part in pieces(tri))
     if flat and run is None:run=a
     if run is not None and(not flat or index==count-1):
      end=b if flat else a;cm.cuboid(((run+end)/2,(BOTTOM+GRADE)/2,(c+d)/2),(end-run,GRADE-BOTTOM,d-c),'floor');run=None
     if not flat:
      for tri in [[(a,c),(b,c),(b,d)],[(a,c),(b,d),(a,d)]]:
       for kind,i,part in pieces(tri):
        if kind=='ground':O.solid(cm,[(x,GRADE+height(float(x),float(z)),z)for x,z in part]+[(x,BOTTOM,z)for x,z in part],'floor')
   m.optimized_collider=cm;meshes.append(m)
 return meshes,height,dark,rims


def clean_bowl_render(asset,o):
 p=asset/o['CustomMesh']['MeshURL'].split('/')[-1];lines=p.read_text().splitlines();v=np.array([list(map(float,l.split()[1:]))for l in lines if l.startswith('v ')]);out=[]
 for l in lines:
  if l.startswith('o '):continue
  if l.startswith('f '):
   q=v[[int(t.split('/')[0])-1 for t in l.split()[1:]]]
   if np.cross(q[1]-q[0],q[2]-q[0])[1]<=1e-8:continue
  out.append(l)
 p.write_text('\n'.join(out)+'\n')

def features(height):
 out=[]
 for c in CRATERS:
  out.append(dict(c,kind='crater',polygon=list(Point(*c['center']).buffer(c['radius']*1.18*1.032,resolution=64).exterior.coords)))
 for c in RIDGES:
  out.append(dict(c,kind='ridge',polygon=list(LineString(c['points']).buffer(c['width'],cap_style=1,join_style=1).exterior.coords)))
 return out


def finish_export(asset,o,m):
 """Strip buried rendering faces and merge only flat collision cells."""
 path=asset/o['CustomMesh']['MeshURL'].split('/')[-1];lines=path.read_text().splitlines();v=np.array([list(map(float,l.split()[1:]))for l in lines if l.startswith('v ')]);out=[]
 for l in lines:
  if l.startswith('o '):continue
  if l.startswith('f '):
   ids=[int(t.split('/')[0])-1 for t in l.split()[1:]];q=v[ids];normal=np.cross(q[1]-q[0],q[2]-q[0])
   top=np.all(q[:,1]>1.01) and normal[1]>1e-8
   bottom=np.all(abs(q[:,1]-1)<1e-7)
   edge=any(np.all(abs(q[:,axis]-edge)<1e-7)for axis in [0,2]for edge in [-24,24])
   if not(top or bottom or edge):continue
  out.append(l)
 path.write_text('\n'.join(out)+'\n')
 temp=m.optimized_collider.write('terrain-collision-temporary')
 (asset/temp.replace('.obj','-collider.obj')).replace(asset/o['CustomMesh']['ColliderURL'].split('/')[-1])
 (asset/temp).unlink()


def native_obj(asset,o):
 """Encode right-handed OBJ vertices for native TTS world-space alignment."""
 for key in ['MeshURL','ColliderURL']:
  p=asset/o['CustomMesh'][key].split('/')[-1];out=['# Kestrel native TTS ground: X reflected for OBJ import; outward faces']
  for l in p.read_text().splitlines():
   if l.startswith('v '):
    x,y,z=map(float,l.split()[1:]);l='v %.6f %.6f %.6f'%(-x,y,z)
   elif l.startswith('f '):l='f '+' '.join(reversed(l.split()[1:]))
   out.append(l)
  temp=p.with_name(p.name+'.native-final');temp.write_text('\n'.join(out)+'\n');temp.replace(p)


def surface_normals(asset,o,height):
 p=asset/o['CustomMesh']['MeshURL'].split('/')[-1];lines=p.read_text().splitlines();v=np.array([list(map(float,l.split()[1:]))for l in lines if l.startswith('v ')]);normals=[]
 for xx,y,z in v:
  x=-xx;dx=(height(float(x+.015),float(z))-height(float(x-.015),float(z)))/.03;dz=(height(float(x),float(z+.015))-height(float(x),float(z-.015)))/.03;n=np.array([dx,1,-dz]);normals.append(n/np.linalg.norm(n))
 out=[l for l in lines if not l.startswith('f ')];out.extend('vn %.6f %.6f %.6f'%tuple(n)for n in normals)
 for l in lines:
  if not l.startswith('f '):continue
  tokens=l.split()[1:];ids=[int(t.split('/')[0])-1 for t in tokens];q=v[ids];n=np.cross(q[1]-q[0],q[2]-q[0])
  if n[1]>1e-9:out.append('f '+' '.join(t+'/'+str(i+1)for t,i in zip(tokens,ids)))
  else:
   n=n/np.linalg.norm(n)if np.linalg.norm(n)>1e-12 else np.array([0,-1,0]);normals.append(n);out.append('vn %.6f %.6f %.6f'%tuple(n));out.append('f '+' '.join(t+'/'+str(len(normals))for t in tokens))
 p.write_text('\n'.join(out)+'\n')
