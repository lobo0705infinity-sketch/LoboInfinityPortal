"""R11: edit the approved native R10 save, retaining its models and controls."""
from pathlib import Path
import json,copy,math,re,shutil
import numpy as np
from shapely.geometry import Polygon,Point
from shapely import affinity
import geometry as G
import lunar_landscape as LL
R=Path(__file__).resolve().parents[2];A=R/'r11/assets';D=R/'r11/deliverables';URL='https://raw.githubusercontent.com/lobo0705infinity-sketch/LoboInfinityPortal/main/lobo-infinity-portal/public/assets/maps/kestrel-lunar-20261101-r11/'
G.ASSET=A;G.ATLAS_SIZE=(1448,1086);G.MATS={'floor':(0,0,100,100)}
old=json.load(open(Path(__file__).parent/'Base-R10/kestrel-lunar-data-harvest.json'))['ObjectStates'][0];bag=copy.deepcopy(old);layout=json.load(open(Path(__file__).parent/'Base-R10/layout.json'))
objects=[o for o in bag['ContainedObjects']if not any(t in o.get('Tags',[])for t in ['ground-surface','crater-bowl','crater-rim'])]
def family(name):return next(o for o in objects if o['Nickname']==name+' | Roof on')
def shell(name):return next(o for o in objects if o['Nickname']==name+' | removable transparent glazing')
def glazing(o,parent,x,z):
 s=o['LuaScript'];s=re.sub(r'local parent=.*',lambda _: 'local parent='+json.dumps(parent),s,count=1)
 s=re.sub(r'local home=JSON.decode\([^\n]+',lambda _: 'local home=JSON.decode('+json.dumps(json.dumps({'x':x,'y':3.25,'z':z}))+')',s,count=1);o['LuaScript']=s
def move(o,x,z):
 o['Transform'].update(posX=x,posZ=z)
 for state in o.get('States',{}).values():move(state,x,z)
def relocate(name,x,z):
 o=family(name);g=shell(name);move(o,x,z);move(g,x,z);glazing(g,o['GUID'],x,z)
 for b in layout['buildings']:
  if b[0]==name:b[1:3]=[x,z]
relocate('Astronomy and navigation dome',9,18.6)
for prefix,x,z in [('Solar power conditioning | server 1',3.3,17.2),('Solar power conditioning | locker 2',4.5,19.7),('Observatory service bay | trolley 2',12.5,22.3)]:
 move(next(o for o in objects if o['Nickname']==prefix),x,z)
for zone in layout['equipmentZones']:
 for i,item in enumerate(zone['items']):
  o=next(o for o in objects if o['Nickname']==zone['name']+' | '+item[0]+' '+str(i+1));item[1:3]=[o['Transform']['posX'],o['Transform']['posZ']]
new=[('Cryogenic sample annex','Medical pressure dome',-17,11.8,.8,.85,'Medical',4.8,4.25),('Solar operations dome','Crew commons dome',.8,13,1,1,'Commons',4.8,4.5),('Robotics calibration dome','Materials analysis dome',-1.4,-5.8,.8,.8,'Research',5.6,4),('Micro-algae culture dome','Hydroponic biosphere',7.1,11.8,.8,.85,'Biolab',4.8,4.25)]
for i,(name,template,x,z,sx,sz,role,w,d)in enumerate(new):
 root=copy.deepcopy(family(template));glass=copy.deepcopy(shell(template));root['GUID']=f'c7a{i}00';glass['GUID']=f'c7a{i}09'
 root['Nickname']=name+' | Roof on';glass['Nickname']=name+' | removable transparent glazing'
 for k,state in root['States'].items():state['GUID']=f'c7a{i}0{k}';state['Nickname']=name+' | Ground floor exposed'
 for o in [root,*root.get('States',{}).values(),glass]:
  o['Transform'].update(posX=x,posZ=z,rotY=0,scaleX=sx,scaleY=1,scaleZ=sz)
 glazing(glass,root['GUID'],x,z);objects.extend([root,glass]);layout['buildings'].append([name,x,z,w,d,1,role,0])
def vertices(o):
 f=A/o['CustomMesh']['MeshURL'].split('/')[-1];v=np.array([list(map(float,l.split()[1:]))for l in f.read_text().splitlines()if l.startswith('v ')])
 t=o['Transform'];v*=np.array([t['scaleX'],t['scaleY'],t['scaleZ']]);return v
footprints=[]
for o in objects:
 if not any(t in o.get('Tags',[])for t in ['building','scatter','solar-array']):continue
 v=vertices(o);t=o['Transform'];p=Polygon(v[:,[0,2]]).convex_hull;p=affinity.rotate(p,-t['rotY'],origin=(0,0));p=affinity.translate(p,t['posX'],t['posZ'])
 footprints.append({'guid':o['GUID'],'name':o['Nickname'],'kind':next(t for t in o['Tags']if t in ['building','scatter','solar-array']),'polygon':list(p.exterior.coords),'height':float(v[:,1].max()-v[:,1].min())})
terrain,height,floors,rims=LL.landscape(footprints,step=.3)
def terrain_object(name,mesh,guid,kind,tint=1.0):
 fn=mesh.write(guid+'-'+re.sub('[^a-z0-9]+','-',name.lower()));o={'GUID':guid,'Name':'Custom_Model','Nickname':name,'Description':'Kestrel lunar regolith. Crater floors are below ground; narrow, low ejecta lips outline them. Use actual geometry for movement and cover.','Transform':dict(posX=0,posY=0,posZ=0,rotX=0,rotY=0,rotZ=0,scaleX=1,scaleY=1,scaleZ=1),'ColorDiffuse':dict(r=tint,g=tint,b=tint),'Locked':True,'Grid':False,'Snap':False,'Hands':False,'Tooltip':True,'DragSelectable':False,'Tags':['LoboMap:1008da','KestrelOrbital',kind,'native-world'],'CustomMesh':{'MeshURL':URL+fn,'ColliderURL':URL+fn.replace('.obj','-collider.obj'),'DiffuseURL':URL+'kestrel-ground.jpg','NormalURL':'','Convex':False,'MaterialIndex':0,'TypeIndex':0,'CastShadows':True,'CustomShader':{'SpecularIntensity':0,'SpecularSharpness':.2}},'LuaScript':'function onLoad() self.setLock(true) end\n','LuaScriptState':'','XmlUI':''};return o
for i,m in enumerate(terrain):
 o=terrain_object('Lunar highlands | quadrant '+str(i+1),m,f'c7b00{i}','ground-surface');LL.finish_export(A,o,m);LL.native_obj(A,o);LL.surface_normals(A,o,height);objects.append(o)
for i,(c,f,r)in enumerate(zip(LL.CRATERS,floors,rims)):
 for typ,m,tint in [('crater-bowl',f,1.0),('crater-rim',r,.45)]:
  o=terrain_object(c['name']+' | '+('sunken bowl'if typ=='crater-bowl'else'narrow rocky lip'),m,f'c7b{1 if typ=="crater-bowl"else 2}0{i}',typ,tint);LL.clean_bowl_render(A,o);LL.native_obj(A,o);LL.surface_normals(A,o,height);objects.append(o)
def urls(o):
 for k,u in o.get('CustomMesh',{}).items():
  if isinstance(u,str)and 'kestrel-lunar-'in u:o['CustomMesh'][k]=URL+u.split('/')[-1]
 o['LuaScript']=o.get('LuaScript','').replace('kestrel-lunar-20261101-r10','kestrel-lunar-20261101-r11')
 for state in o.get('States',{}).values():urls(state)
for o in objects:urls(o)
bag['ContainedObjects']=objects;bag['LuaScript']='\r\n'.join('--'+o['GUID']+','+','.join(f"{o['Transform'][k]:.6f}"for k in ['posX','posY','posZ','rotX','rotY','rotZ'])for o in objects)+'\r\n'
bag['Description']=bag['Description'].replace('Six craters excavated below the surrounding plateau, with shallow ejecta lips; ten connected ridgelines.','Six sunken craters with narrow, dark rocky lips; eighteen higher ridgelines, twenty lunar facilities and thirteen glass domes.')
layout.update(footprints=footprints,landforms=LL.features(height),templatePads=LL.TEMPLATE_PADS,revision='R11',craterLipHeightInches=[c['rim']for c in LL.CRATERS])
def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,separators=(',',':'))+'\n')
write(A/'kestrel-lunar-data-harvest.json',{'ObjectStates':[bag]});write(A/'layout.json',layout);write(D/'Kestrel-Orbital-Data-Harvest.json',{'ObjectStates':[bag]})
used=set()
def collect(o):
 if o.get('CustomMesh'):used.update(o['CustomMesh'][k].split('/')[-1]for k in ['MeshURL','ColliderURL'])
 for state in o.get('States',{}).values():collect(state)
for o in objects:collect(o)
for p in A.glob('*.obj'):
 if p.name not in used:p.unlink()
print(json.dumps({'objects':len(objects),'buildings':sum('building'in o.get('Tags',[])for o in objects),'domes':sum('glass'in o.get('Tags',[])for o in objects),'ridgelines':len(LL.RIDGES),'craters':len(LL.CRATERS)}))
