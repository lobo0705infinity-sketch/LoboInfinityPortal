import math,random
import numpy as np
from scipy.spatial import ConvexHull
class Mesh:
 def __init__(self):self.v=[];self.f=[];self.uv=[];self.groups=[]
 def face(self,points,mat='wall'):
  points=[np.asarray(p,float)for p in points]
  mat=getattr(self,'material_map',{}).get(mat,mat)
  if getattr(self,'world_texture',False):
   start=len(self.v);self.v.extend(points)
   self.uv.extend([((p[0]+24)/48,(p[2]+24)/48)for p in points])
   for i in range(1,len(points)-1):self.f.append((start,start+i,start+i+1))
   return
  # Project real dimensions consistently over adjacent triangles. Clip at tile
  # boundaries so atlas cells repeat without bleeding into a neighboring material.
  normal=np.cross(points[1]-points[0],points[2]-points[0]);drop=int(np.argmax(abs(normal)))
  axes=[i for i in range(3)if i!=drop];tile=1.8 if mat=='lunar'else 3.0 if mat not in ['grille','solar']else 1.4
  def clip(poly,axis,bound,greater):
   out=[]
   for a,b in zip(poly,poly[1:]+poly[:1]):
    va=a[axis]-bound;vb=b[axis]-bound;ina=va>=-1e-8 if greater else va<=1e-8;inb=vb>=-1e-8 if greater else vb<=1e-8
    if ina:out.append(a)
    if ina!=inb:out.append(a+(b-a)*(va/(va-vb)))
   return out
  x0,y0,x1,y1=MATS[mat];aw,ah=ATLAS_SIZE
  lows=[math.floor(min(p[a]for p in points)/tile)for a in axes];highs=[math.floor((max(p[a]for p in points)-1e-8)/tile)for a in axes]
  for u in range(lows[0],max(lows[0],highs[0])+1):
   for v in range(lows[1],max(lows[1],highs[1])+1):
    poly=points[:]
    for ax,k in zip(axes,[u,v]):
     poly=clip(poly,ax,k*tile,True)
     if not poly:break
     poly=clip(poly,ax,(k+1)*tile,False)
     if not poly:break
    if len(poly)<3:continue
    start=len(self.v);self.v.extend(poly)
    self.uv.extend([((x0+(p[axes[0]]/tile-u)*(x1-x0))/aw,1-(y0+(p[axes[1]]/tile-v)*(y1-y0))/ah)for p in poly])
    for i in range(1,len(poly)-1):
     if np.linalg.norm(np.cross(poly[i]-poly[0],poly[i+1]-poly[0]))>1e-10:self.f.append((start,start+i,start+i+1))
 def cuboid(self,c,s,mat='wall',angle=0):
  x,y,z=c;w,h,d=s
  q=np.array([[-w/2,-h/2,-d/2],[w/2,-h/2,-d/2],[w/2,h/2,-d/2],[-w/2,h/2,-d/2],[-w/2,-h/2,d/2],[w/2,-h/2,d/2],[w/2,h/2,d/2],[-w/2,h/2,d/2]])
  a=math.radians(angle);r=np.array([[math.cos(a),0,math.sin(a)],[0,1,0],[-math.sin(a),0,math.cos(a)]])
  q=q@r.T+np.array([x,y,z]);self.groups.append(len(self.f))
  for ids in [(0,3,2,1),(4,5,6,7),(0,4,7,3),(1,2,6,5),(3,7,6,2),(0,1,5,4)]:self.face([q[i]for i in ids],mat)
 def cylinder(self,c,r,h,mat='metal',n=20):
  self.groups.append(len(self.f));x,y,z=c
  lo=[(x+r*math.cos(i*2*math.pi/n),y-h/2,z+r*math.sin(i*2*math.pi/n))for i in range(n)]
  hi=[(x,y+h,z)for x,y,z in lo]
  for i in range(n):j=(i+1)%n;self.face([lo[i],hi[i],hi[j],lo[j]],mat)
  for i in range(1,n-1):self.face([lo[0],lo[i],lo[i+1]],mat);self.face([hi[0],hi[i+1],hi[i]],mat)
 def rock(self,w,d,h,seed):
  rng=random.Random(seed);n=12;self.groups.append(len(self.f));rings=[]
  for y,scale in [(0,1),(h*.15,1.02),(h*.18,.93),(h*.46,.96),(h*.50,.83),(h*.80,.86),(h,.72)]:
   ring=[]
   for i in range(n):
    a=i*2*math.pi/n;cx=math.cos(a);sz=math.sin(a)
    ring.append((math.copysign(abs(cx)**.65,cx)*w/2*scale*(.94+rng.random()*.10),y,math.copysign(abs(sz)**.65,sz)*d/2*scale*(.94+rng.random()*.10)))
   rings.append(ring)
  for a,b in zip(rings,rings[1:]):
   for i in range(n):j=(i+1)%n;self.face([a[i],b[i],b[j],a[j]],'stone')
  for i in range(1,n-1):self.face([rings[-1][0],rings[-1][i+1],rings[-1][i]],'stone');self.face([rings[0][0],rings[0][i],rings[0][i+1]],'stone')
 def write(self,name):
  p=ASSET/(name+'.obj');s=['# Kestrel Orbital; inches; separate convex components']
  # Deduplicate texture vertices before export, rather than emitting one vertex
  # per triangle corner. TTS recommends fewer than 25,000 vertices per model.
  lookup={};verts=[];uvs=[];indices=[]
  for v,uv in zip(self.v,self.uv):
   key=tuple(round(float(x),6)for x in [*v,*uv])
   if key not in lookup:lookup[key]=len(verts);verts.append(v);uvs.append(uv)
   indices.append(lookup[key])
  assert len(verts)<25000,(name,len(verts))
  s.extend('v %.6f %.6f %.6f'%tuple(v) for v in verts)
  s.extend('vt %.6f %.6f'%tuple(v) for v in uvs)
  gs=set(self.groups)
  for k,f in enumerate(self.f):
   if k in gs:s.append('o part_%04d'%k)
   s.append('f '+' '.join(f'{indices[i]+1}/{indices[i]+1}'for i in f))
  p.write_text('\n'.join(s)+'\n')
  # Collider groups are independently convex. Weld positions without UV
  # splits to keep every component under TTS's 255-vertex limit.
  col=[];offset=0;starts=sorted(set(self.groups+[0,len(self.f)]))
  for part,(a,b)in enumerate(zip(starts,starts[1:])):
   if a==b:continue
   col.append('o collider_%04d'%part);lookup={};verts=[];faces=[]
   for face in self.f[a:b]:
    ids=[]
    for j in face:
     key=tuple(round(float(x),6)for x in self.v[j])
     if key not in lookup:lookup[key]=len(verts);verts.append(key)
     ids.append(lookup[key]+offset+1)
    faces.append(ids)
   # Rebuild each already-convex component's hull to remove UV subdivision
   # vertices and coplanar triangles from the physics mesh.
   if len(verts)>=4:
    ar=np.asarray(verts,float);h=ConvexHull(ar);used=sorted(set(h.simplices.flatten()));remap={v:i for i,v in enumerate(used)}
    newfaces=[]
    for tri,eq in zip(h.simplices,h.equations):
     a,b,c=tri
     if np.dot(np.cross(ar[b]-ar[a],ar[c]-ar[a]),eq[:3])<0:b,c=c,b
     newfaces.append([offset+remap[x]+1 for x in [a,b,c]])
    verts=[verts[i]for i in used];faces=newfaces
   assert len(verts)<=255 and len(faces)<=255,(name,part,len(verts),len(faces))
   col.extend('v %.6f %.6f %.6f'%v for v in verts)
   col.extend('f '+' '.join(str(i)for i in f)for f in faces);offset+=len(verts)
  (ASSET/(name+'-collider.obj')).write_text('\n'.join(col)+'\n')
  return p.name

def wall(m,length,height,axis,fixed,y0,door=True):
 """Wall solid intervals explicitly exclude doors and open windows."""
 holes=[]
 if door:holes.append((-0.75,0.75,y0,y0+2.05))
 for sign in [-1,1]:
  mid=sign*(length/2-1.05)
  if abs(mid)>1.4:holes.append((mid-.55,mid+.55,y0+.85,y0+1.7))
 xs=sorted(set([-length/2,length/2]+[p for h in holes for p in h[:2]]))
 for a,b in zip(xs,xs[1:]):
  if b-a<.01:continue
  ranges=[(y0,y0+height)]
  for ha,hb,low,high in holes:
   if a>ha-.001 and b<hb+.001:ranges=[(y0,low),(high,y0+height)]
  for low,high in ranges:
   if high-low<.01:continue
   c=((a+b)/2,(low+high)/2,fixed) if axis=='x' else (fixed,(low+high)/2,(a+b)/2)
   s=(b-a,high-low,.18)if axis=='x'else(.18,high-low,b-a)
   m.cuboid(c,s)
 # Low contrasting concrete skirt, interrupted at the door.
 for a,b in [(-length/2,-.75),(.75,length/2)] if door else [(-length/2,length/2)]:
  c=((a+b)/2,y0+.12,fixed)if axis=='x'else(fixed,y0+.12,(a+b)/2)
  s=(b-a,.22,.20)if axis=='x'else(.20,.22,b-a);m.cuboid(c,s,'concrete')

def ladder(m,x,z,h,side=1):
 for dx in [-.45,.45]:m.cuboid((x+dx,h/2,z),(.075,h,.08),'silver')
 for y in np.arange(.18,h,.30):m.cuboid((x,float(y),z),(.95,.065,.08),'silver')

def building(w,d,floors=1,style='flat',state=1):
 m=Mesh();story=2.25 if style=='bunker'else 2.5;levels=floors if state<3 else 1
 if floors==1:levels=1
 for level in range(levels):
  y=level*story
  if level==0:m.cuboid((0,y+.06,0),(w,.12,d),'floor')
  else:
   # Four floor panels leave a real 1.3 x 1.3 inch ladder hatch.
   hx=w/2-1;hz=-d/2+1;half=.65
   for a,b,c,e in [(-w/2,hx-half,-d/2,d/2),(hx+half,w/2,-d/2,d/2),(hx-half,hx+half,-d/2,hz-half),(hx-half,hx+half,hz+half,d/2)]:
    m.cuboid(((a+b)/2,y+.06,(c+e)/2),(b-a,.12,e-c),'floor')
  wall(m,w,story-.12,'x',-d/2,y+.12,True);wall(m,w,story-.12,'x',d/2,y+.12,False)
  wall(m,d,story-.12,'z',-w/2,y+.12,False);wall(m,d,story-.12,'z',w/2,y+.12,True)
  # Furniture stays at the perimeter, clear of the door-to-door path.
  m.cuboid((-w/2+.5,y+.55,-d/2+1.55),(.65,.85,1.3),'metal')
  m.cuboid((w/2-1.55,y+.55,d/2-.52),(1.3,.85,.65),'roof')
  m.cuboid((-w/2+1.7,y+.85,d/2-.40),(1.1,1.5,.42),'concrete')
  # Window sill lips and lintels do not fill the opening.
  for sign in [-1,1]:
   x=sign*(w/2-1.05)
   if abs(x)>1.4:
    for z in [-d/2,d/2]:m.cuboid((x,y+.95,z),(1.24,.10,.26),'concrete')
 if state==1:
  top=floors*story
  if style=='curved':
   # Segmented barrel vault: a hollow shell, removed in the interior state.
   for i in range(16):
    m.groups.append(len(m.f))
    a=i*math.pi/16;b=(i+1)*math.pi/16
    x1=math.cos(a)*w/2;x2=math.cos(b)*w/2
    y1=top+math.sin(a);y2=top+math.sin(b)
    m.face([(x1,y1,-d/2-.08),(x1,y1,d/2+.08),(x2,y2,d/2+.08),(x2,y2,-d/2-.08)],'roof')
    m.face([(x2,y2-.10,-d/2-.08),(x2,y2-.10,d/2+.08),(x1,y1-.10,d/2+.08),(x1,y1-.10,-d/2-.08)],'roof')
    for z in [-d/2-.08,d/2+.08]:m.face([(x1,y1,z),(x2,y2,z),(x2,y2-.10,z),(x1,y1-.10,z)],'metal')
    for x,y in [(x1,y1),(x2,y2)]:m.face([(x,y,-d/2-.08),(x,y-.10,-d/2-.08),(x,y-.10,d/2+.08),(x,y,d/2+.08)],'metal')
  else:
   m.cuboid((0,top+.08,0),(w+.10,.16,d+.10),'roof')
   for z in [-d/2,d/2]:
    if z<0:
     lx=-w/2+.65
     for a,b in [(-w/2,lx-.55),(lx+.55,w/2)]:
      if b>a:m.cuboid(((a+b)/2,top+.455,z),(b-a,.59,.18),'concrete')
    else:m.cuboid((0,top+.455,z),(w,.59,.18),'concrete')
   for x in [-w/2,w/2]:
    # A ladder opening at one end of the parapet.
    m.cuboid((x,top+.455,.55),(.18,.59,d-1.1),'concrete')
   m.cuboid((-w*.21,top+.40,0),(1.3,.7,.8),'metal')
   m.cuboid((-w*.21,top+.72,0),(1.05,.04,.65),'grille')
   m.cuboid((w*.22,top+.40,d*.20),(1.1,.7,.75),'roof')
 # Exterior ladders survive every state; located away from side door.
 ladder(m,-w/2+.65,-d/2-.22,floors*story+.25)
 if floors==2:
  # Internal ladder goes through a floor hatch at the rear wall.
  # Keep a separate upper floor opening rather than a collision-only hole.
  ladder(m,w/2-1,-d/2+.55,story+.25)
 return m

