"""Detailed base support hardware, exported as compound low-poly collision parts."""
import math
import numpy as np
import geometry as G
from orbital_geometry import solid,slab,poly

def tube(m,points,r,mat='silver',n=10):
 for a,b in zip(points,points[1:]):
  a=np.asarray(a,float);b=np.asarray(b,float);v=b-a;v/=np.linalg.norm(v)
  ref=np.array([0,1,0])if abs(v[1])<.9 else np.array([1,0,0]);u=np.cross(v,ref);u/=np.linalg.norm(u);w=np.cross(v,u)
  solid(m,[p+r*(math.cos(i*math.tau/n)*u+math.sin(i*math.tau/n)*w)for p in [a,b]for i in range(n)],mat)

def cabinet(m,x,y,z,w,h,d,mat='roof'):
 p=[(a+x,b+z)for a,b in poly(w,d,min(w,d)*.10)];slab(m,p,y,y+h,mat)
 for side in [-1,1]:
  for yy in [y+.13,y+h-.13]:m.cuboid((x+side*(w/2-.12),yy,z-d/2-.03),(.075,.075,.055),'silver')
 m.cuboid((x,y+h/2,z-d/2-.025),(w*.75,h*.76,.045),'metal')
 for yy in np.linspace(y+.17,y+h-.17,max(3,int(h/.18))):m.cuboid((x,float(yy),z-d/2-.052),(w*.65,.035,.035),'grille')

def crate(m,x,y,z,w,h,d,mat='cloth'):
 p=[(a+x,b+z)for a,b in poly(w,d,min(w,d)*.10)];slab(m,p,y,y+h,mat)
 for xx in [-w/2+.07,w/2-.07]:
  for zz in [-d/2+.07,d/2-.07]:m.cuboid((x+xx,y+h/2,z+zz),(.12,h+.06,.12),'metal')
 for yy in [y+.08,y+h-.08]:
  for zz in [-d/2-.025,d/2+.025]:m.cuboid((x,yy,z+zz),(w,.10,.055),'silver')
 for xx in [-w*.3,w*.3]:m.cuboid((x+xx,y+h+.025,z),(.10,.05,d),'metal')
 m.cuboid((x,y+h*.60,z-d/2-.06),(.35,.11,.08),'silver')

def tank(m,x,z,r=.62,h=2.6):
 m.cylinder((x,.24+h/2,z),r,h,'silver',n=24)
 for yy in [.25,.25+h]:m.cylinder((x,yy,z),r+.045,.075,'metal',n=24)
 for zz in [-r*.7,r*.7]:m.cuboid((x,.22,z+zz),(r*1.5,.26,.12),'metal')
 tube(m,[(x+r+.06,.45,z),(x+r+.06,h*.72,z),(x+r*.65,h+.25,z),(x,h+.25,z)],.065)
 m.cylinder((x,h+.28,z),.18,.12,'roof',n=12)

def equipment(style):
 m=G.Mesh()
 if style=='coolant':
  m.cuboid((0,.08,0),(3,.16,2.2),'metal')
  for x in [-.8,.8]:tank(m,x,0)
  tube(m,[(-.8,.55,-.72),(0,.55,-.72),(0,.9,-.72),(.8,.9,-.72)],.085)
  cabinet(m,0,.16,.68,.65,.75,.42,'wall')
 elif style=='server':
  m.cuboid((0,.09,0),(2.5,.18,1.5),'metal')
  for x in [-.63,.63]:
   cabinet(m,x,.18,0,1.12,2.76,1.4)
   for yy in [.55,1.25,1.95,2.65]:m.cuboid((x,float(yy),-.77),(.45,.065,.025),'solar')
   tube(m,[(x-.48,.30,.73),(x-.48,2.65,.73),(x+.2,2.65,.73)],.055,'silver')
 elif style=='cargo':
  for x in [-.92,0,.92]:m.cuboid((x,.08,0),(.20,.16,1.55),'metal')
  for z in [-.65,0,.65]:m.cuboid((0,.17,z),(2.6,.12,.14),'silver')
  crate(m,-.64,.23,0,1.12,.78,1.35);crate(m,.64,.23,0,1.12,.78,1.35,'wall');crate(m,.60,1.06,0,1.0,.50,1.2,'roof')
 elif style=='locker':
  m.cuboid((0,.09,0),(2.3,.18,.85),'metal')
  for x in [-.73,0,.73]:
   cabinet(m,x,.18,0,.69,1.57,.8,'wall')
   m.cuboid((x+.19,.94,-.45),(.04,.21,.06),'silver')
 elif style=='barrier':
  # Angled blast-deflector plating, with folded edges and separate feet.
  solid(m,[(-1.5,.12,-.30),(1.5,.12,-.30),(-1.5,.12,.30),(1.5,.12,.30),(-1.5,1.22,-.14),(1.5,1.22,-.14),(-1.5,1.22,.04),(1.5,1.22,.04)],'wall')
  for x in [-1.36,1.36]:
   m.cuboid((x,.10,0),(.25,.20,.85),'metal')
   tube(m,[(x,.2,.25),(x,1.15,-.06)],.055,'silver')
  m.cuboid((0,1.21,-.05),(3,.045,.22),'yellow')
 elif style=='trolley':
  m.cuboid((0,.30,0),(1.85,.16,1.2),'metal')
  crate(m,.25,.4,0,1.12,.76,1.08,'wall')
  tube(m,[(-.87,.35,-.55),(-.87,1.15,-.55),(-.87,1.15,.55),(-.87,.35,.55)],.045)
  for x in [-.7,.7]:
   for z in [-.50,.50]:
    tube(m,[(x-.07,.15,z),(x+.07,.15,z)],.14,'grille',n=12)
 elif style=='reactor':
  slab(m,poly(3.5,3,.4),0,.22,'metal')
  m.cylinder((0,1.66,0),1.16,2.9,'silver',n=32)
  for y in [.35,1.15,2.0,3.08]:m.cylinder((0,y,0),1.22,.10,'metal',n=32)
  for sign in [-1,1]:
   for z in [-.9,.9]:tube(m,[(sign*1.38,.24,z),(sign*1.38,2.9,z),(sign*.65,3.3,z)],.08,'metal')
  for yy in np.linspace(.55,2.75,12):
   for x in [-1.25,1.25]:m.cuboid((x,float(yy),0),(.16,.055,1.65),'grille')
  m.cylinder((0,3.25,0),.7,.18,'roof',n=24)
  cabinet(m,0,.23,-1.25,.9,1.15,.40,'wall')
 return m

def shuttle():
 m=G.Mesh()
 # Cross-sections give the hull a rounded, tapered nose and a broad rear body.
 profile=[(-2.5,1.10,.85,1.75),(-1.7,1.25,.65,2.05),(.8,1.05,.7,1.85),(2.5,.55,.8,1.3),(2.95,.28,.87,1.07)]
 rings=[]
 for z,w,lo,hi in profile:
  rings.append([(x,y,z)for x,y in [(-w*.65,lo),(-w,lo+.22),(-w,hi-.25),(-w*.65,hi),(w*.65,hi),(w,hi-.25),(w,lo+.22),(w*.65,lo)]])
 for a,b in zip(rings,rings[1:]):solid(m,a+b,'wall')
 # Recessed blue-black flight deck, thermal tiles, aft engine bells and landing skids.
 solid(m,[(-.72,1.93,.3),(.72,1.93,.3),(-.45,1.37,2.25),(.45,1.37,2.25),(-.72,1.86,.3),(.72,1.86,.3),(-.45,1.30,2.25),(.45,1.30,2.25)],'solar')
 for sign in [-1,1]:
  m.cuboid((sign*1.60,.92,-1.3),(.65,.85,2.2),'metal')
  for y in [.65,1.15]:tube(m,[(sign*1.6,y,-2.45),(sign*1.6,y,-2.72)],.23,'grille',n=16)
  for z in [-1.55,1.25]:
   tube(m,[(sign*.8,.8,z),(sign*1.35,.20,z)],.075,'silver')
   m.cuboid((sign*1.35,.10,z),(.30,.12,.7),'metal')
 m.cuboid((0,1.8,-2.0),(.14,1.5,.95),'roof')
 for z in [-.7,.1,.9]:m.cuboid((0,.76,z),(2.3,.06,.10),'metal')
 return m
