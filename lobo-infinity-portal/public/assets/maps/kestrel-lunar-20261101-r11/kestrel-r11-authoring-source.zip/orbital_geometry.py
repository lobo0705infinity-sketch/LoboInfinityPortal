"""Pressure-hull architecture. All apertures exist in visual AND collision meshes."""
import math
import numpy as np
from scipy.spatial import ConvexHull
from shapely.geometry import Polygon,box
from shapely.ops import triangulate
import geometry as G

def solid(m,pts,mat='wall'):
 p=np.unique(np.asarray(pts,float),axis=0)
 if len(p)<4:return
 h=ConvexHull(p);m.groups.append(len(m.f))
 for f,eq in zip(h.simplices,h.equations):
  a,b,c=p[f];
  if np.dot(np.cross(b-a,c-a),eq[:3])<0:b,c=c,b
  m.face([a,b,c],mat)

def poly(w,d,c):
 return [(-w/2+c,-d/2),(w/2-c,-d/2),(w/2,-d/2+c),(w/2,d/2-c),(w/2-c,d/2),(-w/2+c,d/2),(-w/2,d/2-c),(-w/2,-d/2+c)]

def habitat_plan(w,d,c,role):
 if role=='Observation Lab':
  return [(-w/2,-d/2),(w/2,-d/2),(w/2,0),(.12*w,0),(.12*w,d/2),(-w/2,d/2)]
 if role=='Data Archive':
  return [(-w*.25,-d/2),(w*.25,-d/2),(w/2,0),(w*.25,d/2),(-w*.25,d/2),(-w/2,0)]
 if role in ['Command and Communications','Cryogenic Lab','Docking Operations']:
  return poly(w,d,min(w,d)*.105)
 return poly(w,d,c)

def slab(m,p,lo,hi,mat='metal'):
 solid(m,[(x,y,z)for x,z in p for y in [lo,hi]],mat)

def floor(m,p,y,hatch=None):
 sh=Polygon(p)
 if hatch:sh=sh.difference(box(hatch[0]-.65,hatch[1]-.65,hatch[0]+.65,hatch[1]+.65))
 for t in triangulate(sh):
  if sh.buffer(1e-8).covers(t):slab(m,list(t.exterior.coords)[:3],y,y+.12,'floor')

def segment(m,a,b,y0,h,u0,u1,lo,hi,mat='wall',thick=.17,taper=.24,offset=0):
 a=np.array(a);b=np.array(b);u=(b-a)/np.linalg.norm(b-a);n=np.array([u[1],-u[0]]);mid=(a+b)/2
 points=[]
 for y in [lo,hi]:
  for x in [u0,u1]:
   for depth in [offset,offset-thick]:
    v=mid+u*x+n*(depth-taper*(y-y0)/h);points.append((v[0],y,v[1]))
 solid(m,points,mat)

def octagon(w,h,c):
 return [(-w/2+c,-h/2),(w/2-c,-h/2),(w/2,-h/2+c),(w/2,h/2-c),(w/2-c,h/2),(-w/2+c,h/2),(-w/2,h/2-c),(-w/2,-h/2+c)]

def ring(m,a,b,y0,h,uc,yc,w,holeH,door=False):
 a=np.array(a);b=np.array(b);u=(b-a)/np.linalg.norm(b-a);n=np.array([u[1],-u[0]]);mid=(a+b)/2
 inner=octagon(w,holeH,.19 if door else .13);outer=octagon(w+.24,holeH+.24,.22 if door else .16)
 for i in range(8):
  j=(i+1)%8;pts=[]
  for xx,yy in [outer[i],outer[j],inner[j],inner[i]]:
   y=yc+yy
   for dep in [.115,-.035]:
    v=mid+u*(uc+xx)+n*(dep-.24*(y-y0)/h);pts.append((v[0],y,v[1]))
  solid(m,pts,'silver'if door else'metal')
 # Dark secondary gasket and high-visibility latch panel beside airlocks.
 if door:
  segment(m,a,b,y0,h,uc+w/2+.14,uc+w/2+.28,yc-.25,yc+.20,'solar',.09,offset=.12)

def wall(m,a,b,y0,h,door=False,viewport=True,windowOffset=0,corner=False):
 L=math.dist(a,b);holes=[]
 if door:holes=[(-.91,.91,y0,y0+2.16)]
 elif viewport and L>1.8:
  ww=min(1.75,L*.45);center=windowOffset*L
  holes=[(center-ww/2-.07,center+ww/2+.07,y0+.91,y0+1.66)]
 xs=sorted(set([-L/2,L/2]+[x for hole in holes for x in hole[:2]]))
 for low,high in zip(xs,xs[1:]):
  if high-low<.0001:continue
  ys=[(y0,y0+h)]
  for left,right,bot,top in holes:
   if low>=left-.0001 and high<=right+.0001:ys=[(y0,bot),(top,y0+h)]
  for bot,top in ys:
   if top-bot>.0001:segment(m,a,b,y0,h,low,high,bot,top,'roof'if corner else'wall')
 if door:ring(m,a,b,y0,h,0,y0+1.08,1.66,2.10,True)
 elif holes:
  left,right,bot,top=holes[0];ring(m,a,b,y0,h,(left+right)/2,(bot+top)/2,right-left-.14,top-bot-.08)
 # Panel joins are recessed strips, rather than masonry courses or sills.
 for sign in [-1,1]:
  u=sign*(L/2-.09);segment(m,a,b,y0,h,u-.055,u+.055,y0,y0+h,'metal',.11,offset=.045)

def roof_cap(m,p,top,gapEdge=4,gapU=0):
 q=[(x*.92,z*.92)for x,z in p]
 if Polygon(p).convex_hull.area-Polygon(p).area<1e-8:
  solid(m,[(x,top,z)for x,z in p]+[(x,top+.28,z)for x,z in q],'roof')
 else:floor(m,p,top)
 for i,(a,b)in enumerate(zip(p,p[1:]+p[:1])):
  L=math.dist(a,b);ranges=[(-L/2+.10,L/2-.10)]
  if i==gapEdge:ranges=[(-L/2+.1,gapU-.58),(gapU+.58,L/2-.1)]
  for left,right in ranges:
   if right>left:segment(m,a,b,top,.65,left,right,top+.22,top+.70,'wall',.15,taper=-.12)

def dish(m,top):
 m.cylinder((0,top+.5,0),.32,.8,'metal')
 for i in range(24):
  a=i*math.tau/24;b=(i+1)*math.tau/24
  pts=[(0,top+.9,0),(1.1*math.cos(a),top+1.40,1.1*math.sin(a)),(1.1*math.cos(b),top+1.40,1.1*math.sin(b))]
  solid(m,pts+[(x,y-.045,z)for x,y,z in pts],'silver')
 m.cuboid((0,top+1.4,0),(.075,.9,.075),'yellow')

def barrel(m,w,d,top):
 for i in range(32):
  a=i*math.pi/32;b=(i+1)*math.pi/32
  x1=math.cos(a)*w/2;x2=math.cos(b)*w/2;y1=top+.9*math.sin(a);y2=top+.9*math.sin(b)
  pts=[(x1,y1,-d/2),(x1,y1,d/2),(x2,y2,d/2),(x2,y2,-d/2)]
  solid(m,pts+[(x,y-.09,z)for x,y,z in pts],'wall')
  for z in [-d/2+.08,0,d/2-.08]:
   solid(m,[(x,y+.04,zz)for x,y,_ in [(x1,y1,0),(x2,y2,0)]for zz in [z-.045,z+.045]]+[(x,y-.02,zz)for x,y,_ in [(x1,y1,0),(x2,y2,0)]for zz in [z-.045,z+.045]],'metal')
 # End pressure plates close the roof shell above the airlock, not the door.
 for z in [-d/2,d/2]:
  arc=[(math.cos(i*math.pi/20)*w/2,top+.9*math.sin(i*math.pi/20),zz)for i in range(21)for zz in [z-.04,z+.04]]
  solid(m,arc,'roof')
 # A flat service spine gives miniatures a real usable roof surface.
 m.cuboid((0,top+.99,0),(2.1,.18,max(1,d-1.2)),'metal')
 for x in [-1.0,1.0]:m.cuboid((x,top+1.28,0),(.12,.42,max(1,d-1.2)),'wall')

def station(w,d,floors,style,state,role):
 m=G.Mesh();c=min(w,d)*(.28 if role in ['Command and Communications','Data Archive','Service Tower']else .22)
 m.material_map=({'wall':'metal','roof':'silver'}if role=='Service Tower'else{'wall':'silver'}if role=='Cryogenic Lab'else{'wall':'cloth'}if role=='Docking Operations'else{})
 levels=floors if state<=2 else max(1,floors-state+2)
 basepoly=habitat_plan(w,d,c,role)
 backIndex=next(i for i,(a,b)in enumerate(zip(basepoly,basepoly[1:]+basepoly[:1]))if abs(a[1]-d/2)<1e-6 and abs(b[1]-d/2)<1e-6)
 ba,bb=basepoly[backIndex],basepoly[(backIndex+1)%len(basepoly)];L=math.dist(ba,bb);ladderx=(ba[0]+bb[0])/2-L*.25
 for level in range(levels):
  y=level*2.5;inset=.10*level;p=habitat_plan(w-2*inset,d-2*inset,c,role)
  hatch=(w/2-c-.6,-d/2+c+.6)if level else None
  floor(m,p,y,hatch)
  # Chunky dark docking collars make the levels read as connected pressure pods.
  for i,(a,b)in enumerate(zip(p,p[1:]+p[:1])):
   corner=abs(a[0]-b[0])>.01 and abs(a[1]-b[1])>.01
   wall(m,a,b,y+.12,2.38,door=level==0 and i in [0,2] and math.dist(a,b)>1.9,viewport=not corner,windowOffset=-.25 if i==backIndex else 0,corner=corner)
   segment(m,a,b,y,2.5,-math.dist(a,b)/2,math.dist(a,b)/2,y+2.34,y+2.43,'metal',.19,taper=.22,offset=.025)
  # Real construction detail stays inside the footprint: sealed service panels,
  # louvered radiators, pressure couplings and a thin protective lower skirt.
  back=d/2-.08
  for xx in [-w*.23,w*.23]:
   m.cuboid((xx,y+.46,back),(.88,.58,.08),'metal')
   for yy in [.23,.35,.47,.59,.71]:m.cuboid((xx,y+yy,back+.045),(.76,.04,.045),'silver')
  for zz in [-d*.20,d*.20]:
   m.cuboid((-w/2+.10,y+.45,zz),(.10,.68,.65),'roof')
   for yy in [.22,.35,.48,.61]:m.cuboid((-w/2+.04,y+yy,zz),(.045,.035,.54),'metal')
  # Sloped workstations and ship storage lockers stay clear of the entrance route.
  m.cuboid((-w*.22,y+.58,d*.20),(.95,.85,.6),'metal')
  solid(m,[(-w*.22-.5,y+.95,d*.2-.35),(-w*.22+.5,y+.95,d*.2-.35),(-w*.22-.5,y+1.18,d*.2+.22),(-w*.22+.5,y+1.18,d*.2+.22),(-w*.22-.5,y+.90,d*.2+.22),(-w*.22+.5,y+.90,d*.2+.22)],'solar')
  m.cuboid((w*.2,y+.5,d*.15),(.7,.75,.55),'roof')
 top=floors*2.5
 curved=role in ['Research Lab Alpha','Crew Airlock','Fabrication Workshop']
 if state==1:
  if curved:barrel(m,w-.12,d-.12,top)
  else:
   roof_cap(m,habitat_plan(w-.2*(floors-1),d-.2*(floors-1),c,role),top,gapEdge=backIndex,gapU=L*.25)
   if role=='Command and Communications':dish(m,top+.28)
   elif role=='Sensor Control':
    m.cylinder((0,top+.70,0),.8,.8,'solar',n=8)
    for x in [-1.1,1.1]:m.cuboid((x,top+.85,0),(.18,1.1,1.3),'silver',angle=45)
   else:
    m.cuboid((.45,top+.55,0),(1.2,.55,.7),'metal')
    for z in [-.24,-.12,0,.12,.24]:m.cuboid((.45,top+.84,z),(1.05,.025,.045),'grille')
    for z in [-.35,0,.35]:m.cuboid((-.75,top+.55,z),(.8,.09,.09),'silver')
    for x in [-1.15,-.4]:m.cuboid((x,top+.38,0),(.07,.45,.9),'metal')
 # Ladder is on a blank part of the rear hull, opposite the entry airlock.
 laddertop=top+(1.1 if curved else .35)
 G.ladder(m,ladderx,d/2+.26,laddertop)
 if curved and state==1:
  # Short rear spine platform connects the ladder to the curved roof's walkway.
  m.cuboid((ladderx,top+1.0,d/2-.3),(1.1,.15,1.15),'metal')
  m.cuboid((ladderx/2,top+1.0,d/2-.55),(abs(ladderx)+1,.15,.75),'metal')
 if floors>1:
  hx=w/2-c-.6;hz=-d/2+c+.6;G.ladder(m,hx,hz,2.5*(floors-1)+.25)
 # Full exported bounds (including hardware) land on quarter-inch values.
 maximum=max(v[1]for v in m.v);target=math.ceil(maximum*4-1e-6)/4
 m.v=[(x,y*target/maximum,z)for x,y,z in m.v]
 return m

def hangar(state):
 m=G.Mesh();w=4.45;spring=1.65;rise=2.35
 for x in [-4.35,4.35]:m.cuboid((x,.8,0),(.35,1.6,6.7),'roof')
 for i in range(32):
  a=i*math.pi/32;b=(i+1)*math.pi/32
  x1=w*math.cos(a);x2=w*math.cos(b);y1=spring+rise*math.sin(a);y2=spring+rise*math.sin(b)
  spans=[(-3.4,3.4)]if state==1 else []
  for l,r in spans:
   solid(m,[(x1,y1,l),(x1,y1,r),(x2,y2,l),(x2,y2,r),(x1,y1-.12,l),(x1,y1-.12,r),(x2,y2-.12,l),(x2,y2-.12,r)],'wall')
  for z in [-3.3,-1.1,1.1,3.3]:
   solid(m,[(x1,y1+.06,zz)for zz in [z-.07,z+.07]]+[(x2,y2+.06,zz)for zz in [z-.07,z+.07]]+[(x1,y1-.05,zz)for zz in [z-.07,z+.07]]+[(x2,y2-.05,zz)for zz in [z-.07,z+.07]],'metal')
 if state==1:
  m.cuboid((0,4.15,0),(2,.20,5.8),'roof')
  for x in [-1.0,1.0]:m.cuboid((x,4.5,0),(.14,.5,5.8),'silver')
 G.ladder(m,0,3.65,4.3)
 if state==1:m.cuboid((0,4.15,3.3),(1.2,.2,.8),'metal')
 h=max(v[1]for v in m.v);t=math.ceil(h*4-1e-6)/4;m.v=[(x,y*t/h,z)for x,y,z in m.v]
 return m
