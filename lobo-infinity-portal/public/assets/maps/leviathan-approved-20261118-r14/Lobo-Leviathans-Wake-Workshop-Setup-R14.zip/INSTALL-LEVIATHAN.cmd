@echo off
setlocal
cd /d "%~dp0"
if not exist "Files" mkdir "Files"
if exist "Files\payload.zip" goto verify
echo Downloading the approved Leviathan R14 package...
curl.exe --fail --location --retry 2 --connect-timeout 30 --output "Files\payload-7ee7b4432495f24f.part1" "https://lobo-infinity-portal.vercel.app/assets/maps/leviathan-approved-20261118-r14/payload-7ee7b4432495f24f.part1"
if errorlevel 1 goto download_failed
curl.exe --fail --location --retry 2 --connect-timeout 30 --output "Files\payload-7ee7b4432495f24f.part2" "https://lobo-infinity-portal.vercel.app/assets/maps/leviathan-approved-20261118-r14/payload-7ee7b4432495f24f.part2"
if errorlevel 1 goto download_failed
curl.exe --fail --location --retry 2 --connect-timeout 30 --output "Files\payload-7ee7b4432495f24f.part3" "https://lobo-infinity-portal.vercel.app/assets/maps/leviathan-approved-20261118-r14/payload-7ee7b4432495f24f.part3"
if errorlevel 1 goto download_failed
copy /b /y "Files\payload-7ee7b4432495f24f.part1"+"Files\payload-7ee7b4432495f24f.part2"+"Files\payload-7ee7b4432495f24f.part3" "Files\payload.zip" >nul
if errorlevel 1 goto download_failed
:verify
certutil -hashfile "Files\payload.zip" SHA256 | find /i "7ee7b4432495f24f17241917592c3d5836485aab87cd3221d0f26348907894c4" >nul
if errorlevel 1 goto verify_failed
del /q "Files\payload-7ee7b4432495f24f.part1" 2>nul
del /q "Files\payload-7ee7b4432495f24f.part2" 2>nul
del /q "Files\payload-7ee7b4432495f24f.part3" 2>nul
"%~dp0Lobo-Leviathan-Setup.exe" %*
exit /b %errorlevel%
:download_failed
echo Download failed. Check your connection and run this installer again.
pause
exit /b 1
:verify_failed
echo Download verification failed. Remove Files\payload.zip and run again.
echo Existing TTS saves have not been changed.
pause
exit /b 1
