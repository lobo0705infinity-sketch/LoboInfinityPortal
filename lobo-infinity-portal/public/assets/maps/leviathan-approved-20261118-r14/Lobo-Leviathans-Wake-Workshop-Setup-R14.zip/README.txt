LEVIATHAN'S WAKE - WORKSHOP SETUP R14
18 November 2026

INSTALL
The portal download fetches the approved package on first run using Windows
curl, then checks its SHA-256 before installing. Keep an internet connection
while installing. No PowerShell is required.

1. Extract the entire ZIP into a new folder.
2. Run INSTALL-LEVIATHAN.cmd.
3. Load Lobo Maps - Leviathans Wake Workshop Update R14 in TTS.
4. Review in TTS, then use Update Workshop > 3719263238 to publish.
The installer also supplies a play-table save and saved-object bags.

R14 APPROVED RELEASE
- The pictured loose rock, additional standalone spawner and red scatter bag
  no longer load automatically. The collection's normal army spawner remains.
- All remaining approved terrain, placements and states are unchanged.
- The scatter saved-object bag remains available for optional use.

RETAINED R13 CABIN EDITS
- First screenshot / west-edge cabin: remove both corner seating groups and
  seal the top opening with a thick finished hull wall.
- Second screenshot / east-edge cabin: seal the top opening only; keep all
  seating and the opposite entrance unchanged.
- Both changes apply in states 1 and 2, with matching wall collision.
- The center cabin is unchanged. No building or scatter was moved or resized.

YOUR APPROVED LAYOUT
TS_Save_443 is the exact position, rotation and scale reference for all 40 retained
building and scatter pieces. Duplicated, enlarged, tilted and off-board pieces
are retained. No scenery has been rearranged. The test army models in the
reference save are not imported into the published map.

STATE ATTACHMENTS
Eight loose details now belong to their host structures. The three rocks on
the ridgeline shelter follow its covered state and disappear in its open state.
Five ground-level details remain attached in both states, including the pod
inside the split hull and the exterior bulwarks/debris. Existing mesh-built
furniture, signs and structural details remain integrated.
Duplicated alternate-state IDs were repaired. Every alternate state now matches
its own building's current placement, including the enlarged pieces.
State information remains in hover text; use 1/2 or the right-click state menu.

CIVILIANS
Only Holden, Naomi, Amos and Alex are placed at the four civilian starting
points, retaining their approved artwork, active poses, figure states and bases.
No additional HVT figures are created or placed on the map. Crew remain movable
and independent of the terrain. Standard table tools remain available.

RETAINED R11 STRUCTURES
R11 pod shells, open hinged hatches, raised signs and hollow collision remain.
The detached cabin's rear doorway and two corner furniture groups stay removed
in both states. The collapsed deck keeps its corrected platform collision.
R13 changes only the two specified cabin mesh/collider pairs in both states.
All other R11 structures and all existing textures remain unchanged.

APPROVED MAP CONTROLS
All 105 map setups retain the standard panel: Close/reopen, Mission, Map Rules
where applicable, Turn 180, deployment Off/Normal/+4/+8, independent bright
rainbow DZ and Exclusion colors, Exclusion Zone, Grid, Quadrants/Scoring Zones,
Day/Night/Off, map-specific options, reference tables, and Clear Table.
Leviathan's Evacuation mission has Exclusion Zone set to N/A.
Building-floor menus stay removed. Rendered control labels use ASCII.
The 48-inch mat, three-inch platform and rainbow G/T spawner controls remain.

INSTALLATION BEHAVIOR
Normal installation uses the approved complete package and creates new numbered
saves. Existing saves and thumbnails remain untouched. No PowerShell is needed.
The optional --source-save route installs this exact Leviathan layout into a
supported older collection while retaining the other map layouts.
Assets use public immutable URLs so the save can load on other computers.

VALIDATION
Automated checks cover exact world transforms, state placement, attachment
ownership, unique state IDs, four crew only, installer behavior and the approved
controls. The complete source archive and validation reports accompany the full release.
Windows executable cross-compiled; native installer logic exercised on Linux.
The portal previews render the current exported battlefield geometry.
Live TTS rendering and physics have not been tested. Review in TTS before
Workshop publication.
