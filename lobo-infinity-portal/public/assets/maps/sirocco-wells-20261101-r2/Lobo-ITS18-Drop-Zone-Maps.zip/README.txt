Extract JSON files to TTS Saves/Saved Objects. Spawn a fresh bag and use the usual deployment spot. Clear Table before changing maps. Includes Sirocco Wells R2 and the latest Canopy Blacksite R4.
