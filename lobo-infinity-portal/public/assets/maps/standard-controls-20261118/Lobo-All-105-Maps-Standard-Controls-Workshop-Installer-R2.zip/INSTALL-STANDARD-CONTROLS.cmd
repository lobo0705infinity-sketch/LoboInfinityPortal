@echo off
cd /d "%~dp0"
"%~dp0Lobo-Standard-Map-Controls-Setup.exe" %*
