LOBO ITS18 — SATELLITE VARIETY EDITION
40 mission setups / 28 terrain layouts.
Individual JSONs are Saved Objects bags for the normal Infinity map deployment spot.
The collection JSON is a game save.
Twelve named Satellite layouts replace nine Azure Circuit and three Tidal Turbines variants. Original event and table credits are retained.
Source credit: tau24 — Infinity Maps: Return to the Satellites (3486064611).
Source assets downloaded and checked; objective coordinates retained.
New previews are footprint diagrams. Live TTS screenshots, physics, line-of-fire and full-army playtesting remain pending.
