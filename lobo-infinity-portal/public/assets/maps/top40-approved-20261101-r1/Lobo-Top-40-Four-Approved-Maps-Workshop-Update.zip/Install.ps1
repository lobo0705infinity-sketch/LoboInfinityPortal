﻿param([string]$TtsRoot = '')
$ErrorActionPreference = 'Stop'
$written = New-Object System.Collections.Generic.List[object]
$backupRoot = $null
try {
    if ([string]::IsNullOrWhiteSpace($TtsRoot)) {
        $TtsRoot = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'My Games\Tabletop Simulator'
    }
    $saveRoot = Join-Path $TtsRoot 'Saves'
    if (-not (Test-Path -LiteralPath $saveRoot -PathType Container)) {
        throw 'Tabletop Simulator Saves was not found. Pass your custom Tabletop Simulator root folder as the first argument to Install.cmd.'
    }
    $bagRoot = Join-Path $saveRoot 'Saved Objects'
    # Assign the parsed JSON array directly. An outer @(... | ConvertFrom-Json)
    # nests the array under Windows PowerShell 5.1 and turns entry.path into Object[].
    $manifestText = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'Install-Manifest.json') -Raw
    $manifest = ConvertFrom-Json -InputObject $manifestText
    if ($null -eq $manifest) { throw 'The installation manifest is empty.' }
    $plan = @()
    foreach ($entry in $manifest) {
        if ($null -eq $entry -or $entry.path -isnot [string] -or $entry.sha256 -isnot [string]) {
            throw 'The installation manifest contains an invalid file entry.'
        }
        $source = Join-Path -Path $PSScriptRoot -ChildPath $entry.path
        if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw ('Package file missing: ' + $entry.path) }
        if ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne $entry.sha256) {
            throw ('Package verification failed: ' + $entry.path)
        }
        $leaf = Split-Path $entry.path -Leaf
        if ($entry.path.StartsWith('Files\')) {
            $destination = Join-Path $saveRoot $leaf
            $backupSubfolder = 'Saves'
        } elseif ($entry.path.StartsWith('Map-Bags\')) {
            # All eight named bags go directly in the MAIN Saved Objects folder.
            $destination = Join-Path $bagRoot $leaf
            $backupSubfolder = 'Saved Objects'
        } else { throw ('Unexpected install path: ' + $entry.path) }
        $plan += [pscustomobject]@{ source=$source; destination=$destination; leaf=$leaf; sha256=$entry.sha256; backupSubfolder=$backupSubfolder }
    }
    $null = New-Item -ItemType Directory -Path $bagRoot -Force
    $backupRoot = Join-Path $TtsRoot ('Lobo Map Backups\Top40-Approved-Maps-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
    foreach ($item in $plan) {
        $backup = $null
        if (Test-Path -LiteralPath $item.destination -PathType Leaf) {
            $dir = Join-Path $backupRoot $item.backupSubfolder
            $null = New-Item -ItemType Directory -Path $dir -Force
            $backup = Join-Path $dir $item.leaf
            Copy-Item -LiteralPath $item.destination -Destination $backup -Force
            if ((Get-FileHash -LiteralPath $backup -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath $item.destination -Algorithm SHA256).Hash) {
                throw ('Backup verification failed: ' + $item.destination)
            }
        }
        $record = [pscustomobject]@{ destination=$item.destination; backup=$backup }
        $written.Add($record)
        Copy-Item -LiteralPath $item.source -Destination $item.destination -Force
        if ((Get-FileHash -LiteralPath $item.destination -Algorithm SHA256).Hash -ne $item.sha256) {
            throw ('Installed file verification failed: ' + $item.destination)
        }
    }
    Write-Host 'Installed: four approved Top 40 round bags and four matching general mission bags.' -ForegroundColor Green
    Write-Host 'All eight bags are in the MAIN Objects > Saved Objects folder.' -ForegroundColor Green
    Write-Host ''
    Write-Host 'To update your existing Workshop item:'
    Write-Host "1. In TTS open Games > Save & Load > Lobo's Infinity Maps - Approved Top 40 Maps R1"
    Write-Host '2. Check the TOP 40 and GENERAL tabs.'
    Write-Host "3. Workshop Upload > Update Workshop > item 3719263238 (Lobo's Infinity Maps)."
    Write-Host 'The general collection remains 40 maps; Aurora VII remains 49 setups; Top 40 has four approved maps.'
    Write-Host 'Clear Table before deploying a new bag in the normal Infinity mod.'
    Write-Host 'Existing separately saved or already deployed bags do not update automatically.'
    Write-Host 'This installer does not publish to Steam or change portal round assignments.'
    exit 0
} catch {
    $failure = $_.Exception.Message
    for ($i=$written.Count-1; $i -ge 0; $i--) {
        $record = $written[$i]
        try {
            if ($record.backup) {
                Copy-Item -LiteralPath $record.backup -Destination $record.destination -Force
            } elseif (Test-Path -LiteralPath $record.destination -PathType Leaf) {
                Remove-Item -LiteralPath $record.destination -Force
            }
        } catch {
            Write-Host ('Automatic restore could not complete for: ' + $record.destination) -ForegroundColor Yellow
            if ($backupRoot) { Write-Host ('Backups: ' + $backupRoot) -ForegroundColor Yellow }
        }
    }
    Write-Host ('Installation failed: ' + $failure) -ForegroundColor Red
    Write-Host ('At installer line: ' + $_.InvocationInfo.ScriptLineNumber) -ForegroundColor Yellow
    exit 1
}
