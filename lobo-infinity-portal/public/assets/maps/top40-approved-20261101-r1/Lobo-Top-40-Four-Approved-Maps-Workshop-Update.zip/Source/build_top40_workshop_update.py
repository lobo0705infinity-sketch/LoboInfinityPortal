from pathlib import Path
import json,copy,re,hashlib,collections,shutil,datetime,zipfile,textwrap
from lupa import LuaRuntime
from PIL import Image,ImageDraw,ImageFont
R=Path('/workspace/scratch/4f99de7356f9');O=R/'workshop-update-output';S=O/'Source'
base=json.load(open(R/'workshop-update-latest.json'));live=json.load(open(R/'workshop-update-live.json'))
collection=copy.deepcopy(base);by={o['GUID']:o for o in collection['ObjectStates']};published={o['GUID']:o for o in live['ObjectStates']}
frost=json.load(open(R/'frostline-approved/Map-Bags/Frostline-Relay-Superiority-R3.json'))['ObjectStates'][0]

def walk(o):
 yield o
 for key in ['ContainedObjects','ChildObjects']:
  for q in o.get(key,[]):yield from walk(q)
 for q in o.get('States',{}).values():yield from walk(q)
used={o['GUID'] for b in collection['ObjectStates'] for o in walk(b) if 'GUID'in o}
def newguid(label):
 i=0
 while True:
  g=hashlib.sha256(('LoboTop40ApprovedR1:'+label+':'+str(i)).encode()).hexdigest()[:6]
  if g not in used:used.add(g);return g
  i+=1

def transform_strings(v,fn,key=None):
 if isinstance(v,dict):return {fn(k) if isinstance(k,str) else k:transform_strings(q,fn,k) for k,q in v.items()}
 if isinstance(v,list):return [transform_strings(q,fn,key) for q in v]
 if isinstance(v,str):return fn(v)
 return v

remaps={}
def clone_map(src,key,rootguid=None,tag_replacements=None):
 m={o['GUID']:newguid(key+':'+o['GUID']) for o in walk(src) if 'GUID'in o}
 if rootguid:m[src['GUID']]=rootguid
 # IDs occur in loader records, controller config, JSON-in-Lua, UI targets and state tables.
 pattern=re.compile(r'(?<![0-9a-fA-F])('+ '|'.join(sorted(m,key=len,reverse=True))+r')(?![0-9a-fA-F])')
 def change(s):
  s=pattern.sub(lambda hit:m[hit[0]],s)
  for a,b in (tag_replacements or {}).items():s=s.replace(a,b)
  return s
 out=transform_strings(copy.deepcopy(src),change);remaps[key]=m
 return out

# Recover the approved three maps from the actual published Workshop, retaining shelf locations.
for g in ['8100c6','810340','100135','ca7100']:
 approved=copy.deepcopy(published[g]);approved['Transform']=copy.deepcopy(by[g]['Transform'])
 idx=collection['ObjectStates'].index(by[g]);collection['ObjectStates'][idx]=approved;by[g]=approved

# The attached Frostline is authoritative. Its entire component payload is retained unchanged.
general_frost=copy.deepcopy(frost);general_frost['GUID']='100f50';general_frost['Transform']=copy.deepcopy(by['100f50']['Transform'])
general_frost['Nickname']='SET_ITS18 Superiority — Frostline Relay'
general_frost['Description']='Superiority | Frostline Relay\nApproved attached Furnished Interiors R3 with lettering-only fix.\nGeneral mission collection: one of the two Superiority maps.\nMatching tournament entry: Lobo\'s Top 40 Winners Round 2 Map.\n\n'+frost.get('Description','')
idx=collection['ObjectStates'].index(by['100f50']);collection['ObjectStates'][idx]=general_frost;by['100f50']=general_frost
by['8100c6']['Nickname']='SET_ITS18 Corporate Appropriation — Asterion Research Campus'
by['810340']['Nickname']='SET_ITS18 The Dig — Old Quarter Excavation'
by['100135']['Nickname']='SET_ITS18 Annihilation — Canopy Blacksite'

# Four tournament entries, with separate object identities and independent cleanup ownership.
events=[dict(general='8100c6',event='ca7100',branch='Winners',round=1,mission='Corporate Appropriation',terrain='Asterion Research Campus',theme='Research campus'),
 dict(general='100f50',event=None,branch='Winners',round=2,mission='Superiority',terrain='Frostline Relay',theme='Alpine snow'),
 dict(general='810340',event=None,branch='Winners',round=4,mission='The Dig',terrain='Old Quarter Excavation',theme='Urban excavation'),
 dict(general='100135',event=None,branch='Losers',round=1,mission='Annihilation',terrain='Canopy Blacksite',theme='Jungle blacksite')]
for i,e in enumerate(events):
 if e['event']:
  b=by[e['event']]
 else:
  tag_changes={}
  if e['general']=='100f50':tag_changes={'LoboMap:FrostlineRelay':'LoboMap:Top40FrostlineRelay','LoboFrostlineTrees':'LoboTop40FrostlineTrees'}
  elif e['general']=='810340':tag_changes={'LoboOldQuarterR1':'LoboTop40OldQuarterR1'}
  elif e['general']=='100135':tag_changes={'LoboMap:CanopyBlacksite':'LoboMap:Top40CanopyBlacksite','LoboCanopyTrees':'LoboTop40CanopyTrees'}
  b=clone_map(by[e['general']],e['terrain'],tag_replacements=tag_changes);e['event']=b['GUID']
  collection['ObjectStates'].append(b);by[b['GUID']]=b
 e['label']=f"Lobo's Top 40 {e['branch']} Round {e['round']} Map"
 b['Nickname']='SET_'+e['label']
 b['Description']=e['label']+'\n'+e['terrain']+' | '+e['mission']+' | 300 points\nApproved tournament map; identical terrain, mission controls and backgrounds to the matching general map.\n\n'+b.get('Description','')
 b['Transform']=dict(posX=-57.,posY=1.065,posZ=14.-i*12,rotX=0.,rotY=0.,rotZ=0.,scaleX=1.,scaleY=1.,scaleZ=1.)
 e['source_sha256']=hashlib.sha256(json.dumps(by[e['general']]['ContainedObjects'],sort_keys=True,ensure_ascii=False).encode()).hexdigest()

L=LuaRuntime(unpack_returned_tuples=True)
items=L.execute(base['LuaScript']+'\nreturn ITEMS')
def py(v):
 if hasattr(v,'items'):
  d={k:py(q)for k,q in v.items()}
  return [d[k]for k in sorted(d)]if d and all(isinstance(k,int)for k in d)else d
 return v
catalog=py(items);catalogby={i['guid']:i for i in catalog}
for e in events:
 b=by[e['general']];d=catalogby[e['general']];d.update(title=e['terrain'],mission=e['mission'],theme=e['theme'],source_name=b['Nickname'],category='missions')
 for g in [e['general'],e['event']]:
  b=by[g];home={axis:b['Transform']['pos'+axis.upper()]for axis in 'xyz'}
  if g==e['general']:d['home']=home
  else:
   row=dict(guid=g,title=e['label'],mission=e['mission'],theme=e['terrain'],source_name=b['Nickname'],category='top40',home=home,round=e['round'],bracket=e['branch'])
   if g in catalogby:catalogby[g].update(row)
   else:catalog.append(row);catalogby[g]=row

def lua(v):
 if v is None:return 'nil'
 if isinstance(v,bool):return 'true'if v else'false'
 if isinstance(v,(int,float)):return repr(v)
 if isinstance(v,str):return json.dumps(v,ensure_ascii=False)
 if isinstance(v,list):return '{'+','.join(lua(q)for q in v)+'}'
 return '{'+','.join('['+lua(k)+']='+lua(q)for k,q in v.items())+'}'
script=re.sub(r'^local ITEMS = .*$',lambda _: 'local ITEMS = '+lua(catalog),base['LuaScript'],count=1,flags=re.M)
script=script.replace("local UI_STATE = {category='all'", "local UI_STATE = {category='top40'")
script=script.replace("ipairs({'all','missions','campaign'})", "ipairs({'all','top40','missions','campaign'})")
script=script.replace("UI.setAttribute('loboName'..slot,'text',item.title)","UI.setAttribute('loboName'..slot,'text',item.title)\n            UI.setAttribute('loboName'..slot,'fontSize',item.category=='top40' and '12' or '15')\n            UI.setAttribute('loboMeta'..slot,'fontSize',item.category=='top40' and '10' or '11')")
script=script.replace("if a.category~=b.category then return a.category=='missions' end", "if a.category~=b.category then local rank={top40=1,missions=2,campaign=3};return (rank[a.category] or 9)<(rank[b.category] or 9) end")
# Keep future loaded tournament bags out of the general/campaign counts.
needle="            item.home=object.getPosition()"
script=script.replace(needle,"            if name:sub(1,18)==\"SET_Lobo's Top 40 \" then item.category='top40';item.title=name:sub(5) end\n"+needle)
collection['LuaScript']=script
xml=base['XmlUI']
xml=re.sub(r'>\d+ MAPS / \d+ ITS18 / \d+ AURORA VII<','>93 MAPS / 40 GENERAL / 49 AURORA VII / 4 TOP 40<',xml,count=1)
needle='  <Button id="loboTab_missions"'
xml=xml.replace(needle,'  <Button id="loboTab_top40" onClick="loboCategory(top40)" color="#233241" textColor="#ffffff" fontSize="11">TOP 40</Button>\n'+needle)
xml=xml.replace('>ITS18</Button>','>GENERAL</Button>')
collection['XmlUI']=xml
collection['SaveName']="Lobo's Infinity Maps - Approved Top 40 Maps R1"
collection['Note']='93 setups: 40 general ITS18 maps (two per mission), 49 Aurora VII setups, and four approved Top 40 round maps. Frostline Relay is the attached Furnished R3 lettering-fix version, replacing general Superiority Meridian Blocks. Top 40: Winners 1 Asterion; Winners 2 Frostline; Winners 4 Old Quarter; Losers 1 Canopy. Other map payloads are preserved from the latest Current Maps installer; the approved Asterion, Old Quarter and Canopy payloads were recovered from the published Workshop.'
collection['Date']='11/1/2026';collection['EpochTime']=int(datetime.datetime.now(datetime.timezone.utc).timestamp())
collection['LuaScriptState']=''
save=O/'Files/Lobo-Top-40-Approved-Maps-Workshop-Update.json'
save.write_text(json.dumps(collection,ensure_ascii=False,separators=(',',':')))

outputs=[]
for e in events:
 for kind,g,label in [('general',e['general'],f"ITS18-{e['mission'].replace(' ','-')}-{e['terrain'].replace(' ','-')}"),('top40',e['event'],f"Lobos-Top-40-{e['branch']}-Round-{e['round']}-Map")]:
  b=copy.deepcopy(by[g]);b['Transform'].update(posX=0,posY=2,posZ=0,rotX=0,rotY=0,rotZ=0)
  filename=label+'.json';obj={'SaveName':b['Nickname'].removeprefix('SET_'),'ObjectStates':[b]}
  (O/'Map-Bags'/filename).write_text(json.dumps(obj,ensure_ascii=False,separators=(',',':')))
  outputs.append(dict(path='Map-Bags/'+filename,guid=g,kind=kind,terrain=e['terrain'],mission=e['mission'],label=by[g]['Nickname']))
  # Exact text thumbnails, generated as label cards (no terrain-preview substitutions).
  im=Image.new('RGB',(512,512),(15,27,38));draw=ImageDraw.Draw(im)
  regular='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';bold='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
  font=lambda size:ImageFont.truetype(bold,size)
  draw.rectangle((0,0,512,14),fill=(202,87,43)if kind=='top40'else(50,131,146))
  draw.text((30,40),"LOBO'S TOP 40"if kind=='top40'else'GENERAL · ITS18',font=font(31),fill=(246,236,213))
  title=(e['branch']+'\nROUND '+str(e['round'])+' MAP')if kind=='top40'else e['terrain']
  lines=[]
  for line in title.splitlines():lines.extend(textwrap.wrap(line,22))
  draw.multiline_text((30,115),'\n'.join(lines),font=font(32),fill=(255,255,255),spacing=12)
  draw.line((30,310,482,310),fill=(74,103,120),width=2)
  draw.multiline_text((30,338),'\n'.join(textwrap.wrap(e['terrain'],29)),font=font(23),fill=(153,202,214),spacing=7)
  draw.multiline_text((30,420),'\n'.join(textwrap.wrap(e['mission'],27)),font=font(22),fill=(240,190,121),spacing=6)
  im.save(O/'Map-Bags'/filename.replace('.json','.png'))
# Collection thumbnail uses the four-map overview as an exact label card.
im=Image.new('RGB',(512,512),(15,27,38));d=ImageDraw.Draw(im)
d.rectangle((0,0,512,14),fill=(202,87,43));d.text((26,40),"LOBO'S INFINITY MAPS",font=font(29),fill='white');d.text((26,100),'APPROVED TOP 40',font=font(27),fill=(240,190,121));d.text((26,140),'WORKSHOP UPDATE',font=font(27),fill=(240,190,121))
for i,e in enumerate(events):d.text((26,215+i*57),('W'if e['branch']=='Winners'else'L')+str(e['round'])+' · '+e['terrain'],font=font(21),fill=(190,218,226))
d.text((26,460),'40 GENERAL  /  49 AURORA  /  4 TOP 40',font=font(16),fill='white');im.save(save.with_suffix('.png'))
# Pin provenance and record each new clone mapping for verification and future synchronized updates.
(S/'map-pairs.json').write_text(json.dumps(events,ensure_ascii=False,indent=2));(S/'clone-guid-maps.json').write_text(json.dumps(remaps,indent=2));(S/'saved-object-index.json').write_text(json.dumps(outputs,ensure_ascii=False,indent=2));(S/'catalogue.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2))
shutil.copy2(R/'stage-reference.lua',S/'original_stage.lua')
shutil.copy2(R/'workshop-update-live-metadata.json',S/'approved-source-workshop-metadata.json')
shutil.copy2(R/'frostline-approved/LETTERING-FIX.txt',S/'Frostline-Lettering-Fix.txt')
(S/'sources.json').write_text(json.dumps(dict(publishedWorkshopId='3719263238',publishedSourceUpdated=json.load(open(R/'workshop-update-live-metadata.json'))['response']['publishedfiledetails'][0]['time_updated'],baseInstallerVersion=49,baseInstallerSHA256=hashlib.sha256((R/'update-latest/Lobo-Workshop-Current-Maps-and-Rules-Installer.zip').read_bytes()).hexdigest(),approvedAttachment='Frostline-Relay-Superiority-Installer (2).zip',approvedAttachmentSHA256=hashlib.sha256((R/'upload/Frostline-Relay-Superiority-Installer (2).zip').read_bytes()).hexdigest(),freshLiveTTSTested=False),indent=2))
# Data equality and identity verification.
assert general_frost['ContainedObjects']==frost['ContainedObjects']
assert general_frost['LuaScript']==frost['LuaScript']
for g in ['8100c6','810340','100135','ca7100']:
 assert by[g]['ContainedObjects']==published[g]['ContainedObjects']
 assert by[g]['LuaScript']==published[g]['LuaScript']
changed={'8100c6','810340','100135','ca7100','100f50'}
for before in base['ObjectStates']:
 if before['GUID']not in changed:assert by[before['GUID']]==before,before['GUID']
counts=collections.Counter(i['category']for i in catalog);assert counts==dict(missions=40,campaign=49,top40=4),counts
allids=[o['GUID']for b in collection['ObjectStates']for o in walk(b)if 'GUID'in o]
baseline=collections.Counter(o['GUID']for b in base['ObjectStates']for o in walk(b)if 'GUID'in o)
newdups=[(g,n)for g,n in collections.Counter(allids).items()if n>1 and n>baseline[g]];assert not newdups,newdups
(S/'structure-validation.json').write_text(json.dumps(dict(setups=sum(o.get('Name')=='Bag'for o in collection['ObjectStates']),categories=dict(counts),unchangedOtherRootObjects=len(base['ObjectStates'])-len(changed),approvedThreePayloadsPreserved=True,approvedCampusTournamentPayloadPreserved=True,frostlineAttachmentPayloadPreserved=True,newGUIDCollisions=newdups,existingUnrelatedDuplicateIDs={g:n for g,n in baseline.items()if n>1},liveTTSTested=False),indent=2))
print('Built',save,';',counts,'; unchanged roots',len(base['ObjectStates'])-len(changed));print('Event GUIDs',[(e['label'],e['event'])for e in events])
