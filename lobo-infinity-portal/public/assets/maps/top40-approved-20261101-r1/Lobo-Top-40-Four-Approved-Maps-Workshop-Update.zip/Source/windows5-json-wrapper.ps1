param([string]$Installer,[string]$TtsRoot)
# Windows PowerShell 5.1's ConvertFrom-Json emits a JSON array as one pipeline object.
# Reproduce that output contract on the available PowerShell 7 runtime.
function global:ConvertFrom-Json {
    param([Parameter(ValueFromPipeline=$true)][string]$InputObject)
    process {
        $parsed = Microsoft.PowerShell.Utility\ConvertFrom-Json -InputObject $InputObject
        Write-Output -NoEnumerate $parsed
    }
}
& $Installer -TtsRoot $TtsRoot
exit $LASTEXITCODE
