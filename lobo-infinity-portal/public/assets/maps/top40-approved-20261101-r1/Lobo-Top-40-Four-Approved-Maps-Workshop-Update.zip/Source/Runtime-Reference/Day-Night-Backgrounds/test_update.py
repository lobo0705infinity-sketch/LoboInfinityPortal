from pathlib import Path
import json,copy,re,xml.etree.ElementTree as ET,collections,zipfile,math
from lupa import LuaRuntime
import numpy as np

ROOT=Path(__file__).resolve().parent
PKG=ROOT/'package'
data=json.loads((PKG/'Files/Lobo-Workshop-Current-Maps-and-Rules.json').read_text())
rows=json.loads((PKG/'Source/Day-Night-Backgrounds/maps.json').read_text())
oldcontrollers=json.loads((PKG/'Source/Map-UI-Lifecycle/controllers.json').read_text())
newcontrollers=json.loads((PKG/'Source/Day-Night-Backgrounds/controllers.json').read_text())
controllers=oldcontrollers+[c for c in newcontrollers if c['controller'] not in {r['controller'] for r in rows}]
bgs={r['bag']:r for r in rows}
bags={b['GUID']:b for b in data['ObjectStates'] if b.get('Nickname','').startswith('SET_')}

# Reuse the prior package's scheduler and asynchronous UI simulation.
source=(PKG/'Source/Deployment-Line-Contrast/test_lifecycle.py').read_text()
harness=source[source.index('L=LuaRuntime'):source.index('# Compile all changed controller scripts')]
exec(harness)
L.execute('''
backgroundName='Custom';backgroundURL='https://example.test/original.jpg';backgroundChanges={};lightApplies=0
Backgrounds={getBackground=function() return backgroundName end,getCustomURL=function() return backgroundURL end,
 setCustomURL=function(url) backgroundName='Custom';backgroundURL=url;backgroundChanges[#backgroundChanges+1]=url;return true end,
 setBackground=function(name) backgroundName=name;backgroundURL=nil;backgroundChanges[#backgroundChanges+1]=name;return true end}
Lighting={ambient_type=1,ambient_intensity=.7,light_intensity=.85,reflection_intensity=.5,lut_index=2,lut_contribution=.3,lut_url='https://example.test/lut.png'}
local colors={sky={.1,.2,.3},equator={.2,.3,.4},ground={.3,.4,.5},light={.9,.8,.7}}
Lighting.getAmbientSkyColor=function() return colors.sky end
Lighting.getAmbientEquatorColor=function() return colors.equator end
Lighting.getAmbientGroundColor=function() return colors.ground end
Lighting.getLightColor=function() return colors.light end
Lighting.setAmbientSkyColor=function(c) colors.sky=c end
Lighting.setAmbientEquatorColor=function(c) colors.equator=c end
Lighting.setAmbientGroundColor=function(c) colors.ground=c end
Lighting.setLightColor=function(c) colors.light=c end
Lighting.apply=function() lightApplies=lightApplies+1 end
function lightSnapshot()
 return {ambient_type=Lighting.ambient_type,ambient_intensity=Lighting.ambient_intensity,light_intensity=Lighting.light_intensity,
 reflection_intensity=Lighting.reflection_intensity,lut_index=Lighting.lut_index,lut_contribution=Lighting.lut_contribution,lut_url=Lighting.lut_url,
 sky=colors.sky,equator=colors.equator,ground=colors.ground,light=colors.light}
end
local originalMakeObject=makeObject
function makeObject(d)
 local o=originalMakeObject(d)
 o.getScale=function() local t=d.Transform or {};return Vector(t.scaleX or 1,t.scaleY or 1,t.scaleZ or 1) end
 return o
end
''')
compile=L.eval('function(s) local f,e=load(s);return f~=nil,e end')
count=0
def walk(o):
 yield o
 for x in o.get('ContainedObjects',[]):yield from walk(x)
 for x in o.get('States',{}).values():yield from walk(x)
for b in bags.values():
 for o in walk(b):
  s=o.get('LuaScript','')
  if 'LOBO MAP BACKGROUND CONTROLS' in s or 'LOBO CONTRAST DEPLOYMENT LINES V2' in s or 'LoboMapUIBrokerV3' in s:
   ok,error=compile(s.replace('!=','~='));assert ok,(b['Nickname'],o['GUID'],error);count+=1
broker=(PKG/'Source/Day-Night-Backgrounds/ui_broker.lua').read_text()
ok,error=compile(broker);assert ok,error
baseline=plain(G.lightSnapshot())
def loaded(bagid,run_existing=False,saved=None):
 b=bags[bagid];records={}
 for line in b['LuaScript'].splitlines():
  if re.match(r'^--[a-f0-9]{6},',line):
   guid,*v=line[2:].split(',');records[guid]=list(map(float,v))
 for d in b['ContainedObjects']:
  obj=G.makeObject(table(d))
  if d['GUID'] in records:obj.setPosition(table(records[d['GUID']][:3]))
 r=bgs[bagid]
 selected=[]
 if run_existing:
  existing=next((c for c in controllers if c['bag']==bagid),None)
  if existing and any(d['GUID']==existing['controller'] for d in b['ContainedObjects']):selected.append(existing['controller'])
 selected.append(r['controller'])
 objects=[]
 for guid in selected:
  d=next(x for x in b['ContainedObjects'] if x['GUID']==guid)
  o=G.getObjectFromGUID(guid);G.runScript(o,d['LuaScript']);o.env.onLoad(saved or '');objects.append(o)
 return objects[-1],objects
def clear(bagid,first='anchor'):
 r=bgs[bagid]
 G.destroy(r['anchor'] if first=='anchor' else r['controller'])
 for d in bags[bagid]['ContainedObjects']:G.destroy(d['GUID'])
def assertRestored():
 assert G.backgroundURL=='https://example.test/original.jpg',G.backgroundURL
 assert plain(G.lightSnapshot())==baseline,(plain(G.lightSnapshot()),baseline)
 G.assertNoMapUI()

# Day/Night/Off and both Clear Table destruction orders on every actual map.
for i,r in enumerate(rows):
 o,loaded_objects=loaded(r['bag'],True);G.advance(75)
 assert G.backgroundURL.endswith(r['background']+'-day.jpg'),r
 assert G.Lighting.ambient_type==2
 G.assertLiveTargets()
 for mode,suffix in [('night',r['background']+'-night.jpg'),('off','background-off.jpg'),('day',r['background']+'-day.jpg')]:
  o.env.loboChooseBackground(table({'color':'White'}),None,'loboBackground_'+r['controller']+'_'+mode)
  G.advance(8);assert G.backgroundURL.endswith(suffix),(r,mode,G.backgroundURL)
 if len(loaded_objects)>1:
  e=loaded_objects[0].env;player=table({'color':'White'})
  if e.loboMissionToggle:e.loboMissionToggle(player)
  elif e.loboTop40ToggleMission:e.loboTop40ToggleMission(player,None,None)
  elif e.loboSwitchbackToggleMission:e.loboSwitchbackToggleMission(player,None,None)
  if e.loboDeploymentToggle:e.loboDeploymentToggle(player)
  elif e.loboTop40ToggleDeployment:e.loboTop40ToggleDeployment(player,None,None)
  elif e.loboSwitchbackToggleDeployment:e.loboSwitchbackToggleDeployment(player,None,None)
  G.advance(1)
 clear(r['bag'],'anchor' if i%2==0 else 'controller');G.advance(75);assertRestored()
assert G.spawnCount==1,('duplicate shared UI/background service',G.spawnCount)

# Save/reload in Night and Off retains the original environment for later cleanup.
for mode in ['night','off']:
 r=rows[0];o,_=loaded(r['bag']);G.advance(75)
 o.env.loboChooseBackground(table({'color':'White'}),None,'loboBackground_'+r['controller']+'_'+mode);G.advance(8)
 saved=o.env.onSave();state=json.loads(saved);assert state['mode']==mode
 clear(r['bag']);G.advance(75);assertRestored()
 o,_=loaded(r['bag'],saved=saved);G.advance(75)
 assert (mode=='night' and G.backgroundURL.endswith('-night.jpg')) or (mode=='off' and G.backgroundURL.endswith('background-off.jpg'))
 clear(r['bag']);G.advance(75);assertRestored()

# Built-in starting backgrounds also restore without a Custom URL.
G.Backgrounds.setBackground('Museum')
r=rows[1];loaded(r['bag']);G.advance(75);clear(r['bag']);G.advance(75)
assert G.backgroundName=='Museum' and G.backgroundURL is None
G.Backgrounds.setCustomURL('https://example.test/original.jpg')

# Clear during startup and while a UI write is in flight, then load another map.
for case in ['boot','UI-loading','night-switch']:
 a,b=rows[0],rows[-1];o,_=loaded(a['bag'],True)
 if case=='UI-loading':
  for _ in range(150):
   G.advance(1)
   if G.UI.loading:break
  else:raise AssertionError('UI mount did not occur')
 elif case=='night-switch':
  G.advance(75);o.env.loboChooseBackground(table({'color':'White'}),None,'loboBackground_'+a['controller']+'_night')
 clear(a['bag']);loaded(b['bag'],True);G.advance(150);G.assertLiveTargets()
 assert G.backgroundURL.endswith(b['background']+'-day.jpg')
 clear(b['bag']);G.advance(75);assertRestored()

# Real overlay rendering helper: unchanged centerline X/Z under rotation/scale,
# wider outline, brighter center, empty and destroyed target handling.
draw=L.execute((ROOT/'contrast_lines.lua').read_text()+'\nreturn loboContrastDraw')
angle=.47;rot=np.array([[math.cos(angle),-math.sin(angle),0],[math.sin(angle),math.cos(angle),0],[0,0,1.]])
M=rot@np.diag([24.,.5,24.]);inv=np.linalg.inv(M);origin=np.array([2.,1.,-4.])
def vec(p):return np.array([p['x'] if p['x'] is not None else p[1],p['y'] if p['y'] is not None else p[2],p['z'] if p['z'] is not None else p[3]],float)
def lt(v):return table({'x':float(v[0]),'y':float(v[1]),'z':float(v[2])})
captured=[]
target=table({'isDestroyed':lambda:False,'positionToWorld':lambda p:lt(M@vec(p)+origin),'positionToLocal':lambda p:lt(inv@(vec(p)-origin)),'setVectorLines':lambda lines:captured.append(lines)})
line=table({'points':[[-.5,.1,-1],[-.5,.1,1]],'color':[.2,.65,1],'thickness':.015})
draw(target,table([line]));out=captured[-1];assert len(out)==2
border,core=out[1],out[2]
assert abs(core['thickness']-.065)<1e-10 and abs(border['thickness']-.15)<1e-10
assert core['color'][2]>.65 and core['color'][3]==1
for i in [1,2]:
 a=M@vec(line['points'][i])+origin;b=M@vec(core['points'][i])+origin
 assert np.allclose(b-a,[0,.004,0],atol=1e-12)
 assert all(border['points'][i][j]==line['points'][i][j] for j in [1,2,3])
draw(target,table([]));assert len(captured[-1])==0
n=len(captured);target['isDestroyed']=lambda:True;draw(target,table([line]));assert len(captured)==n

# Byte-level geometry and line-definition preservation against the source ZIP.
with zipfile.ZipFile(ROOT/'current/Lobo-Workshop-Current-Maps-and-Rules-Installer.zip') as z:
 original=json.loads(z.read('Files/Lobo-Workshop-Current-Maps-and-Rules.json'))
def strip(x):
 if isinstance(x,dict):
  if 'LoboBackgroundController' in x.get('Tags',[]):return None
  return {k:strip(v) for k,v in x.items() if k!='LuaScript'}
 if isinstance(x,list):return [v for item in x if (v:=strip(item)) is not None]
 return x
assert strip(data)==strip(original)
originalbags={x['GUID']:x for x in original['ObjectStates'] if x.get('Nickname','').startswith('SET_')}
for bid,b in bags.items():
 old={x['GUID']:x for x in walk(originalbags[bid])}
 for o in walk(b):
  if o['GUID'] not in old:continue
  a=old[o['GUID']].get('LuaScript','');c=o.get('LuaScript','')
  def normalize(s):
   s=re.sub(r'-- BEGIN LOBO CONTRAST DEPLOYMENT LINES V[12].*?-- END LOBO CONTRAST DEPLOYMENT LINES V[12]','',s,flags=re.S)
   s=re.sub(r'-- BEGIN LOBO MAP UI LIFECYCLE V2.*?-- END LOBO MAP UI LIFECYCLE V2 ADAPTER','',s,flags=re.S)
   s=re.sub(r'-- BEGIN LOBO MAP UI LIFECYCLE V2 EVENTS.*?-- END LOBO MAP UI LIFECYCLE V2 EVENTS','',s,flags=re.S)
   s=re.sub(r'loboContrastDraw\((self|mat),\s*',lambda m:m[1]+'.setVectorLines(',s)
   s=re.sub(r'\r?\n--'+bgs[bid]['controller']+r',0,-20,0,0,0,0\r?\n?','',s)
   return s.strip()
  assert normalize(a)==normalize(c),('Unexpected source-line or rule mutation',bid,o['GUID'])

result={'maps_tested':len(rows),'modified_Lua_scripts_compile':count,'day_night_off_each_map':True,
 'both_clear_orders':True,'mission_panels_and_pending_deployment_overlays_clear':True,'background_and_all_lighting_restored':True,'save_reload_night_and_off':True,
 'built_in_background_restore':True,'clear_during_boot_and_UI_load':True,'rapid_map_switch':True,
 'unrelated_UI_preserved':True,'background_services_spawned':G.spawnCount,
 'scenery_objectives_states_colliders_grids_unchanged':True,'exact_deployment_exclusion_line_definitions_preserved':True,
 'world_XZ_centerlines_preserved':True,'minimum_core_width':.065,'minimum_outline_width':.15,
 'live_TTS_tested':False}
(PKG/'Source/Day-Night-Backgrounds/validation.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
