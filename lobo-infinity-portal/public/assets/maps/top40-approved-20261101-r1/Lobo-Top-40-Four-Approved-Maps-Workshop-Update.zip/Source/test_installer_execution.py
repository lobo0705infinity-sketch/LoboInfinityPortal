from pathlib import Path
import json,subprocess,hashlib,shutil,zipfile
R=Path('/workspace/scratch/4f99de7356f9');P=R/'workshop-update-output';T=R/'installer-fix-tests';PW='/tmp/lobo-map-installer-pwsh/pwsh'
manifest=json.load(open(P/'Install-Manifest.json'))
def target(root,row):
 parts=row['path'].replace('\\','/').split('/');return root/'Saves'/('Saved Objects'if parts[0]=='Map-Bags'else '')/parts[-1]
def run(root,emulate=False,installer=P/'Install.ps1'):
 cmd=[PW,'-NoLogo','-NoProfile','-NonInteractive','-File']
 if emulate:cmd += [str(T/'windows5-json-wrapper.ps1'),'-Installer',str(installer),'-TtsRoot',str(root)]
 else:cmd += [str(installer),'-TtsRoot',str(root)]
 p=subprocess.run(cmd,capture_output=True,text=True)
 return dict(code=p.returncode,stdout=p.stdout,stderr=p.stderr)
def verify(root):
 for row in manifest:
  f=target(root,row);assert f.is_file(),str(f)
  assert hashlib.sha256(f.read_bytes()).hexdigest().upper()==row['sha256'],str(f)
 assert len(list((root/'Saves/Saved Objects').glob('*.json')))==8
 assert len(list((root/'Saves/Saved Objects').glob('*.png')))==8
results=[]
for mode in [False,True]:
 root=T/('TTS Windows5-style [spaces]'if mode else'TTS Current [spaces]')
 if root.exists():shutil.rmtree(root)
 (root/'Saves').mkdir(parents=True)
 r=run(root,mode);print('Fresh',mode,r['code'],r['stdout'][-900:],r['stderr']);assert r['code']==0,r
 verify(root)
 # Confirm overwriting creates backups and an unrelated saved object survives.
 changed=target(root,manifest[0]);changed.write_bytes(b'previous user save')
 sentinel=root/'Saves/Saved Objects/Unrelated.json';sentinel.write_text('unrelated')
 r=run(root,mode);print('Repeat',mode,r['code']);assert r['code']==0,r
 assert sentinel.read_text()=='unrelated';sentinel.unlink();verify(root)
 backups=list((root/'Lobo Map Backups').rglob(changed.name));assert any(f.read_bytes()==b'previous user save'for f in backups)
 results.append(dict(runtime='PowerShell 7 with Windows 5.1 array-output emulation'if mode else'PowerShell 7',freshInstall=True,reinstall=True,backupRetainsPreviousFile=True,all18FileHashesMatch=True,eightBagsInMainSavedObjects=True,unrelatedFilePreserved=True))
# Reject a damaged payload before copying any files.
bad=T/'damaged-package';bad.mkdir(exist_ok=True)
shutil.copy2(P/'Install.ps1',bad/'Install.ps1');shutil.copy2(P/'Install-Manifest.json',bad/'Install-Manifest.json')
(bad/'Files').mkdir(exist_ok=True);(bad/'Files'/manifest[0]['path'].split('\\')[-1]).write_text('damaged')
root=T/'TTS Failed Install';(root/'Saves').mkdir(parents=True,exist_ok=True)
r=run(root,True,bad/'Install.ps1');assert r['code']==1 and 'Package verification failed' in r['stdout'],r
assert not list((root/'Saves').rglob('*.json'))
report=dict(checks=results,corruptPackageRejectedBeforeChanges=True,mapDataChanged=False,actualWindowsRuntimeTested=False)
(P/'Source/installer-execution-validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
