from pathlib import Path
import json,urllib.request,concurrent.futures,hashlib,urllib.parse
R=Path('/workspace/scratch/4f99de7356f9');j=json.load(open(R/'frostline-approved/Map-Bags/Frostline-Relay-Superiority-R3.json'))['ObjectStates'][0]
models={x['file'] for x in json.load(open(R/'frostline-approved/Source/lettering-fix-validation.json'))['models']}
def walk(o):
 yield o
 for q in o.get('States',{}).values():yield from walk(q)
urls={o.get('CustomMesh',{}).get('MeshURL')for v in j['ContainedObjects']for o in walk(v)if Path(urllib.parse.urlsplit(o.get('CustomMesh',{}).get('MeshURL','')).path).name in models}
assert len(urls)==18,len(urls)
def verify(url):
 name=Path(urllib.parse.urlsplit(url).path).name
 expected=hashlib.sha256((R/'frostline-approved/Assets'/name).read_bytes()).hexdigest()
 with urllib.request.urlopen(url,timeout=25)as response:actual=hashlib.sha256(response.read()).hexdigest();status=response.status
 assert actual==expected,(name,expected,actual)
 return dict(file=name,status=status,sha256=actual,attachmentBytesMatch=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=8)as pool:rows=list(pool.map(verify,sorted(urls)))
(R/'workshop-update-output/Source/frostline-fixed-assets-verification.json').write_text(json.dumps(dict(modelsVerified=len(rows),allMatchAttachment=True,models=rows),indent=2))
print('All 18 hosted lettering-fixed building models match the attachment byte for byte.')
