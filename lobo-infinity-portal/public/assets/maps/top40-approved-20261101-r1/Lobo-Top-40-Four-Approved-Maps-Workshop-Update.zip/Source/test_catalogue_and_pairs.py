from pathlib import Path
import json,re,collections,xml.etree.ElementTree as ET
from lupa import LuaRuntime
R=Path(__file__).resolve().parents[1]
c=json.load(open(R/'Files/Lobo-Top-40-Approved-Maps-Workshop-Update.json'))
source=json.load(open(R/'Source/catalogue.json'));pairs=json.load(open(R/'Source/map-pairs.json'))
index=json.load(open(R/'Source/saved-object-index.json'));guidmaps=json.load(open(R/'Source/clone-guid-maps.json'))
by={o['GUID']:o for o in c['ObjectStates']}
xml=ET.fromstring('<root>'+c['XmlUI']+'</root>');xmlids={q.attrib['id']for q in xml.iter()if'id'in q.attrib}
L=LuaRuntime(unpack_returned_tuples=True);G=L.globals()
def table(v):
 if isinstance(v,dict):return L.table_from({k:table(q)for k,q in v.items()})
 if isinstance(v,list):return L.table_from([table(q)for q in v])
 return v
G.pyDecode=lambda s:table(json.loads(s))
G.pyXMLIds=table(list(xmlids))
G.pyData=table(c['ObjectStates'])
L.execute('''
attrs={};nodes={};objects={}
for _,id in ipairs(pyXMLIds)do nodes[id]=true end
UI={setAttribute=function(id,k,v) assert(nodes[id],'missing catalogue UI ID: '..id);attrs[id..':'..k]=v end}
for _,data in ipairs(pyData)do
 local o={type=data.Name,guid=data.GUID}
 o.getName=function()return data.Nickname or ''end
 o.getDescription=function()return data.Description or ''end
 o.getGUID=function()return data.GUID end
 o.getPosition=function()local t=data.Transform;return{x=t.posX,y=t.posY,z=t.posZ}end
 objects[data.GUID]=o
end
function getAllObjects()local t={};for _,o in pairs(objects)do t[#t+1]=o end;return t end
function getObjectFromGUID(g)return objects[g]end
Wait={frames=function(f,n)f()end}
Backgrounds={setCustomURL=function()end}
''')
returned=L.execute(c['LuaScript']+'\nreturn {items=function()return ITEMS end,rebuild=rebuildCatalogue,filter=filtered}')
G.onLoad()
assert G.attrs['loboCount:text'].startswith('4 results'),G.attrs['loboCount:text']
counts={}
for category,n in [('missions',40),('campaign',49),('top40',4),('all',93)]:
 G.loboCategory(None,category,None);actual=len(returned['filter']());assert actual==n,(category,actual,n);counts[category]=actual
G.loboCategory(None,'top40',None);G.loboSearch(None,'Frostline Relay',None);assert len(returned['filter']())==1
G.loboSearch(None,'',None);G.loboCategory(None,'missions',None);G.loboSearch(None,'Frostline Relay',None);assert len(returned['filter']())==1
G.loboSearch(None,'',None)
# Simulate a pickup bag: it must never become a 41st general map or a fifth tournament map.
pickup=L.eval('function()return {type="Bag",getGUID=function()return"fffffe"end,getName=function()return"SET_Lobo\'s Top 40 Winners Round 2 Map"end,getDescription=function()return"PICKUP COPY: for saving"end,getPosition=function()return{x=8,y=2,z=-37}end}end')()
G.objects['fffffe']=pickup;returned['rebuild']();G.loboCategory(None,'all',None);assert len(returned['filter']())==93
compiled=0
def walk(o):
 yield o
 for v in o.get('States',{}).values():yield from walk(v)
 for key in ['ContainedObjects','ChildObjects']:
  for v in o.get(key,[]):yield from walk(v)
compile=L.eval('function(s)local f,e=load(s);return f~=nil,e end')
for row in index:
 bag=by[row['guid']]
 standalone=json.load(open(R/row['path']))['ObjectStates'][0]
 for key in ['LuaScript','ContainedObjects','Nickname','Description']:assert standalone.get(key)==bag.get(key),(row['label'],key)
 for o in walk(bag):
  s=o.get('LuaScript','')
  if s:
   ok,error=compile(s.replace('!=','~='));assert ok,(row['label'],o['GUID'],error);compiled+=1
# Invert event identifiers and ownership tags to compare the complete cloned payload.
# Campus was already duplicated by the approved Workshop and is compared by meshes, placements and names.
def assets_and_placement(bag):
 placements={row[2:].split(',')[0]:list(map(float,row[9:].split(',')))for row in bag['LuaScript'].splitlines()if re.match(r'^--[0-9a-f]{6},',row)}
 def one(o):
  return dict(name=None if 'LoboBackgroundController' in o.get('Tags',[]) else o.get('Nickname'),type=o.get('Name'),model=o.get('CustomMesh'),assetbundle=o.get('CustomAssetbundle'),image=o.get('CustomImage'),scale=[o['Transform']['scale'+a]for a in'XYZ'],pose=placements.get(o['GUID']),states={k:one(v)for k,v in o.get('States',{}).items()})
 return [one(o)for o in bag['ContainedObjects']]
for pair in pairs:
 a,b=by[pair['general']],by[pair['event']]
 assert assets_and_placement(a)==assets_and_placement(b),pair['terrain']
 if pair['terrain']!='Asterion Research Campus':
  inverse={v:k for k,v in guidmaps[pair['terrain']].items()}
  p=re.compile(r'(?<![0-9a-fA-F])('+ '|'.join(inverse)+r')(?![0-9a-fA-F])')
  tags={'LoboMap:Top40FrostlineRelay':'LoboMap:FrostlineRelay','LoboTop40FrostlineTrees':'LoboFrostlineTrees','LoboTop40OldQuarterR1':'LoboOldQuarterR1','LoboMap:Top40CanopyBlacksite':'LoboMap:CanopyBlacksite','LoboTop40CanopyTrees':'LoboCanopyTrees'}
  def undo(v):
   if isinstance(v,dict):return {undo(k):undo(q)for k,q in v.items()}
   if isinstance(v,list):return [undo(q)for q in v]
   if isinstance(v,str):
    v=p.sub(lambda hit:inverse[hit[0]],v)
    for x,y in tags.items():v=v.replace(x,y)
    return v
   return v
  assert undo(b['ContainedObjects'])==a['ContainedObjects'],pair['terrain']+' component parity'
  assert undo(b['LuaScript'])==a['LuaScript'],pair['terrain']+' loader parity'
result=dict(categoryCounts=counts,pickupCopiesExcluded=True,searchReturnsBothSections=True,compiledMapScripts=compiled,pairsWithIdenticalTerrain=4,clonedControlPayloadsEquivalent=True,standaloneBagsMatchCollection=8,xmlValid=True,liveTTSTested=False)
(R/'Source/catalogue-and-pairs-validation.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
