@echo off
setlocal
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Lobo-Order-Panel.ps1" %*
set "installerResult=%ERRORLEVEL%"
pause
exit /b %installerResult%
