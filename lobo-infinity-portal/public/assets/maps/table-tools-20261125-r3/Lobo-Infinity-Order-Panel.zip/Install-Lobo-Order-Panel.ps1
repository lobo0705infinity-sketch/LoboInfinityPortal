[CmdletBinding()]
param([string]$SaveFolder)

$ErrorActionPreference = 'Stop'
$assetName = 'Lobo-Infinity-Order-Panel.json'

try {
    $source = Join-Path $PSScriptRoot $assetName
    $save = Get-Content -LiteralPath $source -Raw -Encoding UTF8 | ConvertFrom-Json
    if (@($save.ObjectStates).Count -ne 1 -or
        $save.ObjectStates[0].Nickname -ne 'Lobo Infinity Order Panel R3' -or
        $save.ObjectStates[0].LuaScript -notmatch 'function onLoad\(') {
        throw 'Extract the entire installer ZIP and try again.'
    }

    if (-not $SaveFolder) {
        $docs = [Environment]::GetFolderPath('MyDocuments')
        if ($docs) {
            $standard = Join-Path $docs 'My Games/Tabletop Simulator/Saves'
            if (Test-Path -LiteralPath $standard -PathType Container) { $SaveFolder = $standard }
        }
    }
    if (-not $SaveFolder) {
        $SaveFolder = Read-Host 'Enter your Tabletop Simulator data folder, Saves folder, or Saved Objects folder'
    }
    if (-not $SaveFolder) { throw 'A Tabletop Simulator save location is required.' }

    $folder = Get-Item -LiteralPath ($SaveFolder.Trim().Trim('"'))
    if (-not $folder.PSIsContainer) { throw 'Choose a folder.' }
    if ($folder.Name -eq 'Saved Objects') {
        $destination = $folder.FullName
    } elseif ($folder.Name -eq 'Saves') {
        $destination = Join-Path $folder.FullName 'Saved Objects'
    } else {
        $saves = Join-Path $folder.FullName 'Saves'
        if (-not (Test-Path -LiteralPath $saves -PathType Container)) {
            throw 'Choose the active Tabletop Simulator data folder or its Saves folder.'
        }
        $destination = Join-Path $saves 'Saved Objects'
    }

    [void][IO.Directory]::CreateDirectory($destination)
    $target = Join-Path $destination $assetName
    $temp = Join-Path $destination ('.lobo-order-' + [guid]::NewGuid().ToString('N') + '.tmp')
    try {
        [IO.File]::Copy($source, $temp)
        if ([IO.File]::Exists($target)) {
            [IO.File]::Replace($temp, $target, [System.Management.Automation.Language.NullString]::Value)
        } else {
            [IO.File]::Move($temp, $target)
        }
    } finally {
        if ([IO.File]::Exists($temp)) { [IO.File]::Delete($temp) }
    }
    Write-Host "Installed Lobo Infinity Order Panel R3 to $destination"
    Write-Host 'In TTS, open Objects > Saved Objects and drop Lobo Infinity Order Panel R3 beside the table. Remove the old panel object and save the game.'
} catch {
    Write-Host $_.Exception.Message
    exit 1
}
