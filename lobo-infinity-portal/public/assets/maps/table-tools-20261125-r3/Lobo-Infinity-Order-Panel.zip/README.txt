Lobo Infinity Order Panel R3

Add it to a table
1. Extract the ZIP and run Install-Lobo-Order-Panel.cmd on the host's Windows PC.
   For a custom TTS location, drag the data folder, Saves folder or Saved Objects
   folder onto the CMD. On any platform you can also copy the included
   Lobo-Infinity-Order-Panel.json into the game's Saves/Saved Objects folder.
2. In Tabletop Simulator, open Objects > Saved Objects and drop Lobo Infinity
   Order Panel R3 on a spare part of the table. Reopen the object browser if it
   was already open. The shared readout appears in the upper-right corner.
3. To keep the panel with this table, save the game with the object present.
   Players who join see it automatically. Delete the object to remove it.

Updating an open table
Drop the R3 object from Saved Objects. It takes over the existing readout.
Remove the older order-panel object, then save your table to keep R3.

Read the panel
The color on the physical TURN marker selects the player's order tray. Both
first-player settings work. On tables that use TTS Turns and omit the marker,
the current Red or Blue TTS turn selects the tray.

Place Impetuous, Tactical Awareness, Regular, Irregular and LT orders on the
numbered halves of the active player's Infinity tray. The center of each
token determines its group. Group 1 and Group 2 each have a row. The Total
row adds the groups by order type. The header shows all remaining orders.

Flip an individual token face down to spend one. Flip it face up to restore
one. To spend one order from a TTS stack, pull one tile off and flip it.
Moving a face-up token across the divider transfers it to the other group.
Lieutenant orders in the center LT slots are included in the LT total and
the header as "LT in center". Place one on a numbered half to assign it to
that group. Flipping an LT order works in either location. Command Tokens
are a separate resource.

The object reads the standard Infinity red/blue turn marker and the split
order trays from the N4/N5 Infinity TTS room. A waiting message identifies
a missing active tray or turn marker. All artwork and UI used by this
controller are built into TTS. It works independently of the tape measure.
