from pathlib import Path
import json,re,struct
from lupa import LuaRuntime
R=Path(__file__).resolve().parents[1]
save=json.load(open(R/'Files/Lobo-Workshop-Current-Maps-and-Rules.json'))
by={o['GUID']:o for o in save['ObjectStates']}
index=json.load(open(R/'Source/saved-object-index.json'))
stage=(R/'Source/original_stage.lua').read_text().replace('!=','~=')
results=[]
for row in index:
 bag=by[row['guid']];roots=bag['ContainedObjects']
 records={l[2:8]:list(map(float,l[9:].split(',')))for l in bag['LuaScript'].splitlines()if re.match(r'^--[a-f0-9]{6},',l)}
 controller=next(o for o in roots if 'local universalConfig='in o.get('LuaScript',''))
 config=json.loads(json.loads(re.search(r'^local universalConfig=JSON.decode\((.*)\)$',controller['LuaScript'],re.M)[1]))
 anchor=next(o for o in roots if o['GUID']==config['mat'])
 for mode in ['default','1','2','3','4']:
  L=LuaRuntime(unpack_returned_tuples=True);G=L.globals()
  G.f32=lambda x:struct.unpack('f',struct.pack('f',float(x)))[0]
  G.decode=lambda s:L.table_from(json.loads(s),recursive=True)
  G.entryData=L.table_from([dict(guid=o['GUID'],name=o['Nickname'],tags=o.get('Tags',[]))for o in roots],recursive=True)
  G.placement=bag['LuaScript'];G.anchorScript=anchor.get('LuaScript','');G.anchorGUID=anchor['GUID']
  L.execute('''
registry={};vars={hld=0};JSON={decode=decode};UI={};Wait={stop=function()end}
Global={getVar=function(k)return vars[k]end,setVar=function(k,v)vars[k]=v end}
function broadcastToAll()end
function getObjectFromGUID(g)return registry[g]end
function getAllObjects()local a={};for _,o in pairs(registry)do a[#a+1]=o end;return a end
function getObjectsWithTag(t)local a={};for _,o in pairs(registry)do if o.hasTag(t)then a[#a+1]=o end end;return a end
function object(g,n,p,r,tags)
 local o={guid=g,name='Custom_Model',p=p or{0,3,0},r=r or{0,0,0},resting=true}
 o.getGUID=function()return o.guid end;o.getName=function()return n end;o.setName=function(v)n=v end
 o.getPosition=function()return o.p end;o.setPosition=function(v)o.p={f32(v[1]),f32(v[2]),f32(v[3])}end
 o.getRotation=function()return o.r end;o.setRotation=function(v)o.r={f32(v[1]),f32(v[2]),f32(v[3])}end
 o.lock=function()end;o.unlock=function()end;o.setScale=function()end;o.setLock=function()end
 o.hasTag=function(t)for _,v in ipairs(tags or{})do if v==t then return true end end;return false end
 o.isDestroyed=function()return registry[o.guid]==nil end
 o.destruct=function()registry[o.guid]=nil;if o.cleanup then o.cleanup()end end
 registry[g]=o;return o
end
self={guid='2d647a',getPosition=function()return{30,1,0}end,call=function(k)return _G[k]()end}
incoming=object('incoming','SET_Combined',{90,90,90});incoming.name='Bag'
incoming.getLuaScript=function()return placement end;incoming.getObjects=function()return entryData end
incoming.takeObject=function(t)
 local e;for _,v in ipairs(entryData)do if v.guid==t.guid then e=v end end;assert(e)
 local o=object(t.guid,e.name,t.position,t.rotation,e.tags)
 if t.guid==anchorGUID then local env=setmetatable({self=o},{__index=_G});assert(load(anchorScript,'ground','t',env))();o.cleanup=env.onDestroy end
 if t.callback then _G[t.callback](o)end
end
''')
  L.execute(stage)
  L.execute("cb=nil;zz=0;bb=nil;sid=nil;onCollisionEnter({collision_object=incoming});assert(vars.hld==1);for i=1,4000 do update();if cb==nil and vars.hld==0 then break end end;assert(cb==nil and vars.hld==0,'Stage remained busy')")
  for o in roots:
   current=G.registry[o['GUID']];assert current is not None,(row['name'],o['GUID'])
   for j in range(1,4):
    assert abs(current.p[j]-records[o['GUID']][j-1])<.0005,(row['name'],o['GUID'],'position')
    assert abs(current.r[j]-records[o['GUID']][j+2])<.0005,(row['name'],o['GUID'],'rotation')
   if mode in o.get('States',{}):
    G.oldGUID=o['GUID'];G.newGUID=o['States'][mode]['GUID']
    L.execute('local o=registry[oldGUID];assert(not registry[newGUID]);registry[oldGUID]=nil;o.guid=newGUID;registry[newGUID]=o')
  if row['kind']=='campaign':
   # Clear after moving the upper deck to its access position.
   L.execute("for _,o in pairs(registry)do if o.hasTag('NereidDeck2')then o.p[1]=o.p[1]+58 end end")
  L.execute("sentinel=object('sentinel','Unrelated miniature',{0,3,0});btnTrash();assert(bb==nil);assert(registry.sentinel==sentinel);registry.sentinel=nil")
  # Controllers may intentionally live outside the stage bounds. The actual
  # controller lifecycle is tested separately; every physical on-table object
  # and all tagged parts of a lifted Nereid deck must be cleared here.
  for g,o in G.registry.items():
   if g=='incoming':continue
   assert not(abs(o.p[1])<44 and abs(o.p[2])<26 and abs(o.p[3])<26),(row['name'],mode,'on-table residue',g)
   if row['kind']=='campaign':assert not o.hasTag('NereidDeck2'),(row['name'],'lift residue',g)
  results.append(dict(map=row['name'],state=mode,deploy=True,busyFlagReleased=True,transforms=True,clearTable=True))
(R/'Source/stage-validation.json').write_text(json.dumps(dict(cases=len(results),allPassed=True,nativeTTSTested=False,results=results),indent=2))
print('Original Stage deploy, busy flag, transforms and Clear Table:',len(results),'cases passed')
