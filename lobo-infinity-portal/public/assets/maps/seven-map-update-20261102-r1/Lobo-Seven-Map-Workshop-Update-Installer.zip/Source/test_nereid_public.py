from test_controls import *
b=bags[-1];o=loadbag(b);c=configs[b['GUID']]
root='loboMission_'+o.getGUID()+'_nereid'
click(button('Map Reference'));G.advance(15)
assert find(root+'_White')['attributes']['active']=='true'
assert find(root+'_Red')['attributes']['active']=='false'
o.env.nereidMissionOpen(table({'color':'Red'}));G.advance(15)
for tab in range(1,4):
 o.env.nereidMissionTab(table({'color':'White'}),None,root+'_White_tab_'+str(tab));G.advance(12)
 assert find(root+'_White')['attributes']['active']=='true'
o.env.nereidMissionClose(table({'color':'White'}));G.advance(12)
assert find(root+'_White')['attributes']['active']=='false'
assert find(root+'_Red')['attributes']['active']=='true'
click(button('Map Rules'));G.advance(15)
panel=find(root+'_White')
def values(nodes):
 out=[]
 for _,n in nodes.items():
  if n['value']:out.append(n['value'])
  if n['children']:out+=values(n['children'])
 return out
assert any('NO AERIAL:'in text for text in values(panel['children']))
assert not any('Vault Below'in text or 'Network Links'in text for text in values(G.UI.roots))
L.execute('''
function testFigure(g,x,y,z,locked)
 local o=makeObject({GUID=g,Nickname=g,Transform={posX=x,posY=y,posZ=z},Tags={}})
 o.setPosition(Vector(x,y,z));o.setLock(locked)
 o.getLock=function()return o.locked end
 o.getBounds=function()local p=o.getPosition();return{center=Vector(p.x,p.y,p.z),size=Vector(1,1.5,1)}end
 return o
end
upperUnit=testFigure('ffff01',0,6,10,false)
lowerUnit=testFigure('ffff02',0,2,10,false)
otherUnit=testFigure('ffff03',100,6,10,true)
''')
G.advance(45)
click(button('Upper Deck: LIFT'));G.advance(8)
assert abs(G.upperUnit.getPosition().x-58)<.001
assert abs(G.lowerUnit.getPosition().x)<.001 and G.otherUnit.getPosition().x==100
assert not G.upperUnit.locked and G.otherUnit.locked
assert json.loads(o.env.onSave())['nereidDeckLifted']is True
click(button('Upper Deck: STACK'));G.advance(8)
assert abs(G.upperUnit.getPosition().x)<.001 and not G.upperUnit.locked
o.env.nereidDeckLift();G.advance(1)
clearbag(b,c['mat'])
assert abs(G.upperUnit.getPosition().x)<.001 and not G.upperUnit.locked
(ROOT/'Source/nereid-public-validation.json').write_text(json.dumps(dict(publicReferenceTabs=3,mapRulesNoAerial=True,perPlayerPanels=True,deckLiftAndStack=True,clearRestoresCarriedFigures=True,futureMissionNotPublished=True,nativeTTSTested=False),indent=2))
print('Nereid public reference, deck lift/stack and figure cleanup passed')
