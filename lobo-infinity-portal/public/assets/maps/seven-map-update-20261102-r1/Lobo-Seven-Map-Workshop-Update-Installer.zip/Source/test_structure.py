from pathlib import Path
import json,re,collections,hashlib
from lupa import LuaRuntime
R=Path(__file__).resolve().parents[1]
save=json.load(open(R/'Files/Lobo-Workshop-Current-Maps-and-Rules.json'))
by={o['GUID']:o for o in save['ObjectStates']}
index=json.load(open(R/'Source/saved-object-index.json'))
pairs=json.load(open(R/'Source/map-pairs.json'))
def walk(o):
 yield o
 for k in ['ContainedObjects','ChildObjects']:
  for q in o.get(k,[]):yield from walk(q)
 for q in o.get('States',{}).values():yield from walk(q)
def transform(v,fn):
 if isinstance(v,dict):return {fn(k):transform(q,fn)for k,q in v.items()}
 if isinstance(v,list):return [transform(q,fn)for q in v]
 return fn(v)if isinstance(v,str)else v
L=LuaRuntime(unpack_returned_tuples=True);compile=L.eval('function(s)local f,e=load(s);return f~=nil,e end')
scripts=0
for row in index:
 b=by[row['guid']];standalone=json.load(open(R/row['path']))['ObjectStates'][0]
 for k in ['Nickname','Description','LuaScript','ContainedObjects']:assert b.get(k)==standalone.get(k)
 assert b['LuaScript'].endswith('\r\n')and not re.search(r'(?<!\r)\n',b['LuaScript'])
 records={l[2:8]:l[9:].split(',')for l in b['LuaScript'].splitlines()if re.match(r'^--[a-f0-9]{6},',l)}
 assert all(o['GUID']in records for o in b['ContainedObjects'])
 for o in walk(b):
  if o.get('LuaScript'):
   ok,e=compile(o['LuaScript'].replace('!=','~='));assert ok,(row['name'],o['GUID'],e);scripts+=1
for p in pairs:
 a,b=by[p['general']],by[p['event']]
 inverse={v:k for k,v in p['guidMap'].items()}
 pattern=re.compile(r'(?<![0-9a-fA-F])('+'|'.join(inverse)+r')(?![0-9a-fA-F])')
 def undo(s):
  parts=re.split(r'(https?://[^\s\"\'<>\\]+)',s)
  for i in range(0,len(parts),2):
   parts[i]=pattern.sub(lambda m:inverse[m[0]],parts[i])
   for x,y in p['tagMap'].items():parts[i]=parts[i].replace(y,x)
  return ''.join(parts)
 assert transform(b['ContainedObjects'],undo)==a['ContainedObjects'],p['name']+' component parity'
 assert undo(b['LuaScript'])==a['LuaScript'],p['name']+' loader parity'
 for x,y in zip(walk(a),walk(b)):
  for key in ['CustomMesh','CustomImage','CustomAssetbundle']:assert x.get(key)==y.get(key),(p['name'],'asset URL changed')
# The seven updated families, including all states and attachments, have no
# duplicate runtime identities. The unrelated legacy collection is untouched.
ids=[o['GUID']for row in index for o in walk(by[row['guid']])]
dups={g:n for g,n in collections.Counter(ids).items()if n>1};assert not dups,dups
n=by[index[-1]['guid']];text=json.dumps(n)
for secret in ['Vault Below','Precursor Nodes','Analyze the Network','Network Links','GM preview']:assert secret not in text,secret
assert len(n['ContainedObjects'])==48
assert all(not any(t in o.get('Tags',[])for t in ['NereidObjective','NereidMovableMission'])for o in n['ContainedObjects'])
k=by['1008da'];ground=next(o for o in k['ContainedObjects']if o['GUID']=='c70000')
assert not re.search(r'self\.createButton\([^\n]*MAP CONTROLS',ground['LuaScript'])
result=dict(namedBags=13,synchronizedGeneralTop40Pairs=6,compiledScripts=scripts,allImmutableAssetURLsPreserved=True,noDuplicateGUIDsInUpdatedFamilies=True,standaloneCollectionParity=True,nereidPublicTerrainOnly=True,kestrelBoardControlsButtonRemoved=True,nativeTTSTested=False)
(R/'Source/structure-validation.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
