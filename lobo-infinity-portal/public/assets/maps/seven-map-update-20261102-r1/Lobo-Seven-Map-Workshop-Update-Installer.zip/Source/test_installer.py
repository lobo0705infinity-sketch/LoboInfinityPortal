from pathlib import Path
import json,subprocess,tempfile,hashlib,shutil
R=Path(__file__).resolve().parents[1];BASE=R.parent
PS=BASE.parent/'r14/tools/pwsh'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest().upper()
def run(package,tts,ok=True):
 p=subprocess.run([str(PS),'-NoProfile','-NonInteractive','-File',str(package/'Install.ps1'),'-TtsRoot',str(tts)],capture_output=True,text=True,timeout=60)
 assert (p.returncode==0)==ok,p.stdout+p.stderr
 return p
def target(tts,e):
 prefix,name=e['path'].replace('\\','/').split('/')
 folder={'Files':'','Saved-Objects':'Saved Objects','Map-Bags':'Saved Objects/Lobo Workshop - Current Maps'}[prefix]
 return tts/'Saves'/folder/name
results=[]
with tempfile.TemporaryDirectory(prefix='lobo-seven-map-test-')as tmp:
 T=Path(tmp)
 for package in [R,BASE/'full-collection']:
  manifest=json.load(open(package/'Install-Manifest.json'))
  tts=T/("Jake's Custom TTS "+package.name);(tts/'Saves').mkdir(parents=True)
  run(package,tts)
  assert all(sha(target(tts,e))==e['sha256']for e in manifest)
  assert len(list((tts/'Saves/Saved Objects').glob('Lobos Top 40 *.json')))==6
  assert len(list((tts/'Saves/Saved Objects').glob('Nereid Deep - Azure Coast R7.json')))==1
  assert json.load(open(tts/'Saves/Lobo-Workshop-Current-Maps-and-Rules.json'))['SaveName']=="Lobo's Infinity Maps - Seven Map Update R1"
  # Replace every target with distinct previous bytes; every one must survive
  # in a verified backup when the same installer runs again.
  previous={}
  for i,e in enumerate(manifest):
   p=target(tts,e);p.write_bytes(('previous-file-'+str(i)).encode());previous[p.relative_to(tts).as_posix()]=p.read_bytes()
  saved=tts/'Saves/Saved Objects'
  legacy=saved/'1008da.json';legacy.write_text(json.dumps(dict(ObjectStates=[dict(GUID='1008da',Nickname='SET_ITS18 Data Harvest — Kestrel Lunar Base')])));legacy.with_suffix('.png').write_bytes(b'old-thumbnail')
  sentinel=saved/'100135.json';sentinel.write_text(json.dumps(dict(ObjectStates=[dict(GUID='abcdef',Nickname='My personal scenery')])));sentinelBytes=sentinel.read_bytes()
  outbreak=saved/'100e3e.json';outbreak.write_text(json.dumps(dict(ObjectStates=[dict(GUID='100e3e',Nickname='SET_ITS18 Outbreak - Nereid Deep R3')])));outbreakBytes=outbreak.read_bytes()
  run(package,tts)
  assert all(sha(target(tts,e))==e['sha256']for e in manifest)
  backups=sorted((tts/'Lobo Map Backups').iterdir(),key=lambda p:p.stat().st_mtime_ns)
  for rel,data in previous.items():assert(backups[-1]/'Replaced'/Path(rel).relative_to('Saves')).read_bytes()==data,rel
  assert not legacy.exists()and not legacy.with_suffix('.png').exists()
  assert sentinel.read_bytes()==sentinelBytes and outbreak.read_bytes()==outbreakBytes
  assert list((backups[-1]/'Previous-GUID-Copies').rglob('1008da.json'))
  results.append(dict(package=package.name,freshInstall=True,reinstall=True,filesVerified=len(manifest),allExistingTargetsBackedUp=True,legacyGUIDRetired=True,unrelatedMapsPreserved=True))
 # Bad package data fails before any user file is modified.
 damaged=T/'damaged';shutil.copytree(R,damaged,ignore=shutil.ignore_patterns('__pycache__'))
 p=damaged/'Files/Lobo-Workshop-Current-Maps-and-Rules.json';p.write_bytes(p.read_bytes()+b'CORRUPT')
 tts=T/'Unchanged';(tts/'Saves').mkdir(parents=True);personal=tts/'Saves/personal.json';personal.write_bytes(b'untouched')
 run(damaged,tts,False);assert personal.read_bytes()==b'untouched';assert not(tts/'Lobo Map Backups').exists()
 # Target-folder conflicts are caught before backups or writes.
 blocked=T/'Blocked';(blocked/'Saves/Lobo-Workshop-Current-Maps-and-Rules.json').mkdir(parents=True)
 run(R,blocked,False);assert not(blocked/'Lobo Map Backups').exists()
 assert b'\r\n'in(R/'Install.cmd').read_bytes()and b'\\r\\n'not in(R/'Install.cmd').read_bytes()
out=dict(powerShellVersion=subprocess.check_output([str(PS),'-NoProfile','-Command','$PSVersionTable.PSVersion.ToString()'],text=True).strip(),runs=results,corruptPackageBlockedBeforeWrites=True,targetFolderConflictBlockedBeforeWrites=True,cmdHasNativeCRLF=True,nativeWindowsTested=False)
(R/'Source/installer-validation.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
