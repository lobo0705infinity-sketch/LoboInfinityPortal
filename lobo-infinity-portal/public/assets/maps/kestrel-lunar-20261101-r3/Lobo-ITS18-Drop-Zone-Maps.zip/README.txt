LOBO ITS18 - CURRENT MAPS
40 mission setups / 29 terrain layouts.
Kestrel Lunar Base replaces Concrete Labyrinth for Data Harvest; Sirocco Wells replaces Palisade Depot for Provisioning.
Individual JSON files are Saved Objects bags for the Infinity map deployment stage. The collection JSON is a game save.
Kestrel includes regolith ground, Lunar Day (Earth and Sun), Lunar Night (Earth and stars), Booty, Metachemistry and independent DZ/+4/+8 guides.
Live TTS physics and multiplayer playtesting remain pending. Steam publishing uses Update Workshop in TTS.
