"""Ray-check the actual opaque geometry, entrances, material and native states."""
from pathlib import Path
import json,math
import numpy as np
R=Path(__file__).resolve().parents[2];A=R/'r13/assets';B=json.load(open(A/'kestrel-lunar-data-harvest.json'))['ObjectStates'][0]
def triangles(o,key='ColliderURL'):
 lines=(A/o['CustomMesh'][key].split('/')[-1]).read_text().splitlines();v=np.array([list(map(float,l.split()[1:]))for l in lines if l.startswith('v ')]);f=[[int(t.split('/')[0])-1 for t in l.split()[1:]]for l in lines if l.startswith('f ')];return v[np.array(f)]
def hits(q,a,b):
 a=np.array(a,float);d=np.array(b,float)-a;e1=q[:,1]-q[:,0];e2=q[:,2]-q[:,0];p=np.cross(d,e2);det=np.einsum('ij,ij->i',e1,p);ok=abs(det)>1e-9;inv=np.divide(1.,det,out=np.zeros_like(det),where=ok);t=a-q[:,0];u=np.einsum('ij,ij->i',t,p)*inv;vvec=np.cross(t,e1);v=np.einsum('j,ij->i',d,vvec)*inv;travel=np.einsum('ij,ij->i',e2,vvec)*inv;return travel[ok&(u>=-1e-8)&(v>=-1e-8)&(u+v<=1+1e-8)&(travel>1e-6)&(travel<1-1e-6)]
large=[o for o in B['ContainedObjects']if o['Nickname'].startswith(('Selene operations','Copernicus expedition'))];assert len(large)==2;results=[]
for o in large:
 q=triangles(o);render=triangles(o,'MeshURL');glass=triangles(o['ChildObjects'][0]);assert abs(render[:,:,0].max()-render[:,:,0].min()-8.25087)<1e-5
 assert abs(render[:,:,1].max()-5.5)<1e-6
 # Four separate entrances admit a forty-millimeter base along the cross hall.
 for x,z in [(0,-1),(0,1),(-1,0),(1,0)]:
  for offset in [-.79,0,.79]:
   a=[x*4.5+z*offset,1.1,z*4.5+x*offset];b=[x*1.25+z*offset,1.1,z*1.25+x*offset]
   assert len(hits(q,a,b))==0,(o['Nickname'],'opaque doorway blocked',a)
   assert len(hits(glass,a,b))==0,(o['Nickname'],'glass doorway blocked',a)
 # Transparent glazing is excluded: opaque walls must actually block sightlines.
 rays=0
 for offset in [-2.5,-1.5,1.5,2.5]:
  for a,b in [([offset,1.3,-6],[offset,1.3,6]),([-6,1.3,offset],[6,1.3,offset])]:
   assert len(hits(q,a,b))>=2,(o['Nickname'],'unblocked hull sightline',offset);rays+=1
 # The very center stays an open, two-inch cross hallway.
 for offset in [-.79,0,.79]:
  assert len(hits(q,[offset,1.1,-4.5],[offset,1.1,4.5]))==0
  assert len(hits(q,[-4.5,1.1,offset],[4.5,1.1,offset]))==0
 results.append({'building':o['Nickname'].split(' | ')[0],'pressureHullDiameterInches':8.0,'heightInches':5.5,'entrances':4,'clearCrossHallInches':2,'blockedOpaqueSightlineSamples':rays})
# World-sized box UVs remain bounded on every regraded terrain triangle.
stretch=1.;faces=0
for o in B['ContainedObjects']:
 if not any(t in o.get('Tags',[])for t in ['ground-surface','crater-bowl','crater-rim']):continue
 lines=(A/o['CustomMesh']['MeshURL'].split('/')[-1]).read_text().splitlines();v=np.array([list(map(float,l.split()[1:]))for l in lines if l.startswith('v ')]);uv=np.array([list(map(float,l.split()[1:]))for l in lines if l.startswith('vt ')]);assert uv.min()>=0 and uv.max()<=1
 for l in lines:
  if not l.startswith('f '):continue
  ids=[t.split('/')for t in l.split()[1:]];p=v[[int(t[0])-1 for t in ids]];t=uv[[int(t[1])-1 for t in ids]]*48;faces+=1
  for j,k in [(0,1),(1,2),(2,0)]:
   d=np.linalg.norm(p[j]-p[k]);u=np.linalg.norm(t[j]-t[k]);assert u>1e-7 or d<1e-6
   if u>1e-7:stretch=max(stretch,float(d/u))
assert stretch<math.sqrt(3)+.001
report={'status':'passed','additionalLargeDomes':results,'terrainUVMaximumStretch':round(stretch,4),'terrainFacesChecked':faces,'nativeGlassStates':'Highest building state owns local ChildObjects glazing; lower floor/frame states have none. No independent glass payloads.','limits':'Geometry checks use exported meshes; live TTS playtesting pending.'}
(R/'r13/deliverables/DOME-VALIDATION.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
