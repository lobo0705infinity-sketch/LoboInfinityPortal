"""World-sized dominant-plane UV projection for native lunar terrain meshes."""
import numpy as np
def box_uv(path):
 lines=path.read_text().splitlines();v=np.array([list(map(float,l.split()[1:]))for l in lines if l.startswith('v ')]);v[:,0]*=-1
 raw_normals=[tuple(map(float,l.split()[1:]))for l in lines if l.startswith('vn ')];normal_lookup={};normal_map=[];normals=[]
 for n in raw_normals:
  if n not in normal_lookup:normal_lookup[n]=len(normals)+1;normals.append(n)
  normal_map.append(normal_lookup[n])
 uv=[];lookup={};faces=[]
 for l in lines:
  if not l.startswith('f '):continue
  t=[p.split('/')for p in l.split()[1:]];ids=[int(p[0])-1 for p in t];ns=[int(p[2])-1 for p in t];q3=v[ids];n=np.cross(q3[1]-q3[0],q3[2]-q3[0]);axis=int(np.argmax(abs(n)));axes=[0,2]if axis==1 else[2,1]if axis==0 else[0,1];out=[]
  for p,i in zip(t,ids):
   q=tuple(round(float(x),9)for x in (v[i,axes]+24)/48)
   assert all(0<=x<=1 for x in q)
   if q not in lookup:lookup[q]=len(uv)+1;uv.append(q)
   out.append(p[0]+'/'+str(lookup[q])+'/'+str(normal_map[int(p[2])-1]))
  faces.append('f '+' '.join(out))
 out=[l for l in lines if not l.startswith(('vt ','vn ','f '))];out.extend('vt %.9f %.9f'%q for q in uv);out.extend('vn %.6f %.6f %.6f'%n for n in normals);out.extend(faces);path.write_text('\n'.join(out)+'\n')
