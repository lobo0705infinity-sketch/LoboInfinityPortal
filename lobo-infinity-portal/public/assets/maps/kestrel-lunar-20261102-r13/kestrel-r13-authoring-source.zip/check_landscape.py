from pathlib import Path
import json,math,numpy as np
from shapely.geometry import Polygon
R=Path(__file__).resolve().parents[2];A=R/'r13/assets';B=json.load(open(A/'kestrel-lunar-data-harvest.json'))['ObjectStates'][0];L=json.load(open(A/'layout.json'));GRADE=L['baseY']
def top(o,key):
 lines=(A/o['CustomMesh'][key].split('/')[-1]).read_text().splitlines();v=np.array([list(map(float,l.split()[1:]))for l in lines if l.startswith('v ')]);v[:,0]*=-1;q=[]
 for l in lines:
  if l.startswith('f '):
   p=v[[int(t.split('/')[0])-1 for t in reversed(l.split()[1:])]]
   if np.cross(p[1]-p[0],p[2]-p[0])[1]>1e-7:q.append(p)
 return np.array(q)
def at(q,x,z):
 u=q[:,1][:,[0,2]]-q[:,0][:,[0,2]];v=q[:,2][:,[0,2]]-q[:,0][:,[0,2]];d=u[:,0]*v[:,1]-u[:,1]*v[:,0];p=np.array([x,z])-q[:,0][:,[0,2]];a=(p[:,0]*v[:,1]-p[:,1]*v[:,0])/d;b=(u[:,0]*p[:,1]-u[:,1]*p[:,0])/d;ok=(a>=-1e-6)&(b>=-1e-6)&(a+b<=1+1e-6)
 assert np.any(ok),('terrain gap',x,z)
 return max((q[:,0,1]+a*(q[:,1,1]-q[:,0,1])+b*(q[:,2,1]-q[:,0,1]))[ok])
terrain=[o for o in B['ContainedObjects']if 'ground-surface'in o.get('Tags',[])or 'crater-bowl'in o.get('Tags',[])or 'crater-rim'in o.get('Tags',[])];assert len(terrain)==16
v=np.concatenate([top(o,'MeshURL')for o in terrain]);p=np.concatenate([top(o,'ColliderURL')for o in terrain])
for q in [v,p]:assert abs(np.cross(q[:,1]-q[:,0],q[:,2]-q[:,0])[:,1].sum()/2-2304)<.005,'duplicate flat surface or ground gap'
for o in terrain:
 if 'crater-bowl'in o['Tags']:
  q=top(o,'MeshURL');assert q[:,:,1].max()<GRADE-.03,'crater rises above surrounding ground';assert q[:,:,1].min()>2.0,'crater floor can be hidden by old table level'
for x in np.linspace(-23.7,23.7,19):
 for z in np.linspace(-23.7,23.7,19):assert abs(at(v,x,z)-at(p,x,z))<1e-5
craters=[c for c in L['landforms']if c['kind']=='crater'];ridges=[c for c in L['landforms']if c['kind']=='ridge'];assert len(craters)==6 and len(ridges)==18;depths=[];lips=[]
for c in craters:
 x,z=c['center'];floor=at(v,x,z);assert GRADE-floor>c['depth']*.8;depths.append(round(GRADE-floor,3))
 ring=[at(v,x+c['radius']*.98*math.cos(a),z+c['radius']*.98*math.sin(a))for a in np.linspace(0,math.tau,64)];assert max(ring)-GRADE<.41;assert max(ring)>GRADE+.12;lips.append(round(max(ring)-GRADE,3))
 for rr in [.0,.3,.5,.75,1.0,1.15]:
  for a in np.linspace(0,math.tau,24):
   xx=x+c['radius']*rr*math.cos(a);zz=z+c['radius']*rr*math.sin(a);assert abs(at(v,xx,zz)-at(p,xx,zz))<1e-5
for o in L['footprints']:
 if o['kind']=='building-state':continue
 poly=Polygon(o['polygon'])
 for x,z in list(poly.exterior.coords)+[(poly.centroid.x,poly.centroid.y)]:assert abs(at(v,x,z)-GRADE)<.025,(o['name'],'uneven pad')
peaks=[]
for c in ridges:
 maximum=max(at(v,*(np.array(a)+t*(np.array(b)-np.array(a))))-GRADE for a,b in zip(c['points'],c['points'][1:])for t in np.linspace(0,1,21));print('RIDGE',c['name'],round(maximum,2));assert maximum>1.0,(c['name'],'flattened ridge');peaks.append(round(maximum,2))
for x,z in L['templatePads']:
 for a in np.linspace(0,math.tau,24):assert abs(at(v,x+2.5*math.cos(a),z+2.5*math.sin(a))-GRADE)<.01
anchor=next(o for o in B['ContainedObjects']if o['GUID']=='c70000');assert anchor['Transform']['posY']+1.35>GRADE;assert 'local y=3.275'in anchor['LuaScript']
report={'status':'passed','craters':6,'ridgelines':18,'plateauWorldY':GRADE,'craterDepthBelowPlateauInches':depths,'maximumEjectaLipAbovePlateauInches':lips,'checks':['actual depressions below surrounding surface','six narrow low lips partition terrain without coplanar overlays or hidden flat crater planes','native OBJ render/collision surfaces agree','twenty-two facilities, fifteen integrated domes and higher ridgelines','level facility and template pads','physical recovery button and deployment fallback above new grade'],'limits':'Native TTS playtesting remains pending.'};(R/'r13/deliverables/LANDSCAPE-VALIDATION.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
