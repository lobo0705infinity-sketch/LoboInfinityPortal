"""R13: varied orientation, two large LOS domes, native glazed building states."""
from pathlib import Path
import json,copy,math,re,sys
import numpy as np
from shapely.geometry import Polygon,Point,box
from shapely import affinity
from PIL import Image
import geometry as G
import lunar_architecture as LA
import lunar_landscape as LL
R=Path(__file__).resolve().parents[2];A=R/'r13/assets';D=R/'r13/deliverables'
URL='https://raw.githubusercontent.com/lobo0705infinity-sketch/LoboInfinityPortal/main/lobo-infinity-portal/public/assets/maps/kestrel-lunar-20261102-r13/'
bag=copy.deepcopy(json.load(open(Path(__file__).parent/'Base-R12/kestrel-lunar-data-harvest.json'))['ObjectStates'][0]);L=json.load(open(Path(__file__).parent/'Base-R12/layout.json'))
objects=bag['ContainedObjects'];G.ASSET=A;G.ATLAS_SIZE=Image.open(A/'station-materials.jpg').size;w,h=G.ATLAS_SIZE
keys=['wall','stone','roof','metal','concrete','floor','silver','rust','solar','grille','cloth','yellow'];G.MATS={k:((i%4)*w/4+4,(i//4)*h/3+4,(i%4+1)*w/4-4,(i//4+1)*h/3-4)for i,k in enumerate(keys)}
def family(n):return next(o for o in objects if o['Nickname'].split(' | ')[0]==n and 'building'in o.get('Tags',[]))
def shell(n):return next(o for o in objects if o['Nickname']==n+' | removable transparent glazing')
def place(o,x,z,a):
 o['Transform'].update(posX=x,posZ=z,rotY=a)
 for v in o.get('States',{}).values():place(v,x,z,a)
def facility(n,x,z,a):
 place(family(n),x,z,a)
 try:place(shell(n),x,z,a)
 except StopIteration:pass
 for b in L['buildings']:
  if b[0]==n:b[1:3]=[x,z];b[7]=a
# Fixed seeded-style mixture: orientations remain stable across reloads.
angles={'Command observatory':45,'Hydroponic biosphere':135,'Astronomy and navigation dome':270,'Materials analysis dome':270,'Medical pressure dome':225,'Central research biosphere':135,'Oxygen reclamation dome':315,'Volatile sampling dome':180,'Crew commons dome':90,'Cryogenic sample annex':270,'Solar operations dome':225,'Robotics calibration dome':45,'Micro-algae culture dome':0}
for n,a in angles.items():
 o=family(n);facility(n,o['Transform']['posX'],o['Transform']['posZ'],a)
facility('Astronomy and navigation dome',8.5,19.4,270)
facility('Medical pressure dome',-17.5,4.9,225)
facility('Oxygen reclamation dome',13,-9.5,315)
facility('Micro-algae culture dome',5.8,-10,0)
yard=[('Lander receiving yard | cargo 1',6,-22,0),('Lander receiving yard | cargo 2',9,-22,0),('Lander receiving yard | trolley 3',12,-22,0),('Lander receiving yard | locker 4',13.7,-22,90)]
for n,x,z,a in yard:place(next(o for o in objects if o['Nickname']==n),x,z,a)
for zone in L['equipmentZones']:
 for i,item in enumerate(zone['items']):
  o=next(o for o in objects if o['Nickname']==zone['name']+' | '+item[0]+' '+str(i+1));item[1:4]=[o['Transform']['posX'],o['Transform']['posZ'],o['Transform']['rotY']]
template=copy.deepcopy(family('Central research biosphere'));gtemplate=copy.deepcopy(shell('Central research biosphere'))
newdomes=[('Selene operations biosphere',13,5.8,45),('Copernicus expedition biosphere',7.1,11.8,225)]
for i,(n,x,z,a)in enumerate(newdomes):
 # Campus interior uses a 2-inch clear cross hall, four rooms and four doors.
 # Taller pressure shielding blocks low horizontal sightlines below glazing.
 old=LA.curved_wall;olddome=LA.dome
 def wall(m,rx,rz,y,h,**kw):return old(m,rx,rz,y,1.84,**kw)
 def dome(m,g,rx,rz,y,rise,**kw):return olddome(m,g,rx,rz,2.0,3.40,**kw)
 LA.curved_wall=wall;LA.dome=dome
 meshes={s:LA.campus_dome(8.44,8.50,s)for s in [1,2]}
 LA.curved_wall=old;LA.dome=olddome
 height=max(v[1]for v in meshes[1][0].v);factor=5.5/height
 for pair in meshes.values():
  for m in pair:m.v=[np.array([v[0],v[1]*factor,v[2]])for v in m.v]
 floorfactor=2.5/max(v[1]for v in meshes[2][0].v)
 meshes[2][0].v=[np.array([v[0],v[1]*floorfactor,v[2]])for v in meshes[2][0].v]
 root=copy.deepcopy(template);root.pop('States');root['GUID']=f'c7c{i}00';root['Nickname']=n+' | Roof on';root['Transform'].update(posX=x,posZ=z,rotY=a,scaleX=1,scaleY=1,scaleZ=1)
 def model(o,m,label):
  fn=m.write(o['GUID']+'-'+label);o['CustomMesh'].update(MeshURL=URL+fn,ColliderURL=URL+fn.replace('.obj','-collider.obj'));return o
 model(root,meshes[1][0],'pressure-frame');root['Description']='Height (base to top): 5.50 in\n8.00-inch pressure hull; four furnished rooms; four entrances and a 2-inch central cross hall. Opaque shielding and room bulkheads block line of fire; use actual geometry.'
 opened=copy.deepcopy(root);opened['GUID']=f'c7c{i}01';opened['Nickname']=n+' | Ground floor exposed';opened['Description']=opened['Description'].replace('5.50','2.50');opened['Tags']=[t for t in opened['Tags']if t!='building']+['building-state'];model(opened,meshes[2][0],'ground-floor');root['States']={'2':opened}
 glass=copy.deepcopy(gtemplate);glass['GUID']=f'c7c{i}09';glass['Nickname']=n+' | removable transparent glazing';glass['Transform']=copy.deepcopy(root['Transform']);model(glass,meshes[1][1],'glazing')
 objects.extend([root,glass]);L['buildings'].append([n,x,z,8,8,1,'Campus',a])
# Native ChildObjects are rigid local attachments; all existing approved examples
# use local child transforms. Only the highest (complete) state owns the glass.
state_manifest=[]
for i,o in enumerate([v for v in objects if 'building'in v.get('Tags',[])]):
 n=o['Nickname'].split(' | ')[0];oldstates=o.pop('States',{});floors=sorted(oldstates.values(),key=lambda v:0 if 'Ground floor'in v['Nickname']or 'roof removed'in v['Nickname']else 1)
 try:g=shell(n)
 except StopIteration:g=None
 if g:
  frame=copy.deepcopy(o);frame['GUID']=f'c7d{i:03x}';frame['Nickname']=n+' | Roof frame, glass off';frame['Tags']=[t for t in frame['Tags']if t!='building']+['building-state']
  floors.append(frame)
  o['Nickname']=n+' | Complete glazed dome'
  g=copy.deepcopy(g);g['Nickname']=n+' | integrated glazing';g['Transform']={k:(1 if k.startswith('scale')else 0)for k in g['Transform']};g['LuaScript']='';g['LuaScriptState']='';g['Tooltip']=False;g['DragSelectable']=False;g['Tags']=['LoboMap:1008da','KestrelOrbital','glass','integrated-glazing'];o['ChildObjects']=[g]
 highest=len(floors)+1;o['States']={str(k):v for k,v in enumerate(floors,1)}
 for v in [o,*floors]:
  labels=[f'{j}: '+('ground floor'if j==1 else 'upper floor'if len(floors)>1 and j==2 and not g else 'roof frame, glass off'if g and j==len(floors)else'upper floor')for j in range(1,highest)]
  labels.append(f'{highest}: '+('complete glazed dome'if g else'roof on'))
  v['Description']=re.sub(r'\nStates:[^\n]*','',v['Description'])+'\nStates: '+'; '.join(labels)+'.'
  v['LuaScript']='function onLoad() self.setLock(true) end\n'
 state_manifest.append({'name':n,'guid':o['GUID'],'defaultState':highest,'stateIds':list(range(1,highest+1)),'glazedState':highest if g else None,'rotationDegrees':o['Transform']['rotY']})
objects=[o for o in objects if 'glass'not in o.get('Tags',[])]
def footprint(o):
 v=np.array([list(map(float,l.split()[1:]))for l in (A/o['CustomMesh']['MeshURL'].split('/')[-1]).read_text().splitlines()if l.startswith('v ')]);t=o['Transform'];v*=np.array([t['scaleX'],t['scaleY'],t['scaleZ']]);p=Polygon(v[:,[0,2]]).convex_hull;p=affinity.rotate(p,-t['rotY'],origin=(0,0));p=affinity.translate(p,t['posX'],t['posZ']);return dict(guid=o['GUID'],name=o['Nickname'],kind=next(t for t in o['Tags']if t in ['building','scatter','solar-array']),polygon=list(p.exterior.coords),height=float(v[:,1].max()-v[:,1].min()))
L['footprints']=[footprint(o)for o in objects if any(t in o.get('Tags',[])for t in ['building','scatter','solar-array'])]
if '--layout-only'in sys.argv:
 (A/'layout.json').write_text(json.dumps(L));(A/'kestrel-lunar-data-harvest.json').write_text(json.dumps({'ObjectStates':[dict(bag,ContainedObjects=objects)]}));print('layout prepared');exit()
# Re-grade terrain pads around the revised buildings, retaining the approved
# R12 lunar material, weathered craters, and all eighteen ridgelines.
LL.RIDGES[6]['points']=[[1.7,-23],[2.7,-22.8],[3.8,-23]]
LL.RIDGES[2]['points']=[[15.6,10.5],[15.4,11.6],[16.1,12.7]]
LL.RIDGES[5]['points']=[[16.3,-12.3],[17.2,-11.8],[18,-11.4]]
LL.RIDGES[9].update(name='Northern service ridge',points=[[-15.2,19.2],[-14.6,19.7],[-14,20]])
LL.RIDGES[15].update(name='Northern station strata',points=[[-4.3,18.6],[-3.3,18.9],[-2.8,18.1]],width=.6)
LL.RIDGES[16]['points']=[[18.9,5.6],[20,6.1],[21.2,5.8]]
terrain,height,bowls,rims=LL.landscape(L['footprints'],step=.3)
from terrain_projection import box_uv
def terrain_update(o,m,ground=False):
 fn=o['CustomMesh']['MeshURL'].split('/')[-1];m.write(fn[:-4]);o['CustomMesh'].update(MeshURL=URL+fn,ColliderURL=URL+fn.replace('.obj','-collider.obj'),DiffuseURL=URL+'lunar-regolith-diffuse.jpg');o['ColorDiffuse']={'r':1.,'g':1.,'b':1.}
 if ground:LL.finish_export(A,o,m)
 else:LL.clean_bowl_render(A,o)
 LL.native_obj(A,o);LL.surface_normals(A,o,height);box_uv(A/fn)
for tag,meshes in [('ground-surface',terrain),('crater-bowl',bowls),('crater-rim',rims)]:
 for o,m in zip([v for v in objects if tag in v.get('Tags',[])],meshes):terrain_update(o,m,tag=='ground-surface')
def urls(v):
 if isinstance(v,dict):
  for k,u in v.items():
   if isinstance(u,str)and 'https://raw.githubusercontent.com/lobo0705infinity-sketch/LoboInfinityPortal/main/lobo-infinity-portal/public/assets/maps/kestrel-lunar-'in u:
    if k.endswith('URL'):v[k]=URL+u.split('/')[-1]
    elif k=='LuaScript':v[k]=re.sub(r'kestrel-lunar-\d{8}-r\d+', 'kestrel-lunar-20261102-r13',u)
   else:urls(u)
 elif isinstance(v,list):
  for x in v:urls(x)
bag['ContainedObjects']=objects;urls(bag)
anchor=next(o for o in objects if o['GUID']=='c70000');anchor['LuaScript']=anchor['LuaScript'].replace('Number keys expose building interiors and floors.','Number keys: 1 ground floor; 2 upper floor on two-story buildings. The highest state restores the complete building, including integrated glass. The preceding dome state keeps the roof frame with glass off.')
bag['LuaScript']='\r\n'.join('--'+o['GUID']+','+','.join(f"{o['Transform'][k]:.6f}"for k in ['posX','posY','posZ','rotX','rotY','rotZ'])for o in objects)+'\r\n'
bag['Description']='Kestrel Lunar Base R13 — Data Harvest. Twenty-two facilities, fifteen integrated glass domes, including two additional 8-inch four-room biospheres. Varied dome orientation. State 1 ground floor; higher floors in order; complete glass dome is the highest state. Six weathered sunken craters, eighteen high ridgelines, 2-by-3 solar field, organized service yards. Booty, Metachemistry, DZ/+4/+8, day/night Earth and Sun backgrounds. Live TTS playtesting pending.'
L.update(landforms=LL.features(height),revision='R13',buildingStates=state_manifest,largeDomeHullDiameterInches=8.0,integratedGlassDomes=15)
for p,v in [(A/'layout.json',L),(A/'kestrel-lunar-data-harvest.json',{'ObjectStates':[bag]}),(D/'Kestrel-Orbital-Data-Harvest.json',{'ObjectStates':[bag]})]:p.write_text(json.dumps(v,ensure_ascii=False,separators=(',',':'))+'\n')
print(json.dumps({'objects':len(objects),'buildings':len(state_manifest),'glassAttachments':sum(bool(o.get('ChildObjects'))for o in objects if 'building'in o.get('Tags',[])),'orientations':sorted(set(s['rotationDegrees']for s in state_manifest))}))
