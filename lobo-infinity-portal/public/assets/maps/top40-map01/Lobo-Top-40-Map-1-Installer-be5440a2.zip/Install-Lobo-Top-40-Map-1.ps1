﻿$ErrorActionPreference = 'Stop'
try {
    $source = Join-Path $PSScriptRoot 'Objects\Lobo-Top-40-Map-1-Bag.json'
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) {
        throw 'Map file not found. Extract the entire ZIP before running INSTALL.cmd.'
    }
    $expectedHash = 'BE5440A248338D39443BCE045F2C8B212A08DF3F33BD6D689969CF41D943FB0D'
    if ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne $expectedHash) {
        throw 'Map file verification failed. Extract a fresh copy of the installer ZIP.'
    }
    $null = Get-Content -LiteralPath $source -Raw -Encoding UTF8 | ConvertFrom-Json
    $documents = [Environment]::GetFolderPath('MyDocuments')
    if ([string]::IsNullOrWhiteSpace($documents)) {
        throw 'Windows Documents folder could not be found.'
    }
    $ttsRoot = Join-Path $documents 'My Games\Tabletop Simulator'
    $saves = Join-Path $ttsRoot 'Saves\Saved Objects'
    $destinationFolder = Join-Path $saves 'Lobo Top 40'
    $destination = Join-Path $destinationFolder 'Lobo-Top-40-Map-1-Bag.json'
    $null = New-Item -ItemType Directory -Path $destinationFolder -Force
    if (Test-Path -LiteralPath $destination) {
        $backupFolder = Join-Path $ttsRoot 'Lobo Map Backups'
        $null = New-Item -ItemType Directory -Path $backupFolder -Force
        $backupName = 'Lobo-Top-40-Map-1-Bag-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff') + '.json'
        Copy-Item -LiteralPath $destination -Destination (Join-Path $backupFolder $backupName)
        Write-Host 'Previous installed version backed up.'
    }
    Copy-Item -LiteralPath $source -Destination $destination -Force
    if ((Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash -ne $expectedHash) {
        throw 'Installed map verification failed.'
    }
    Write-Host ''
    Write-Host "Installed bag: Lobo's Top 40 Map #1 - Corporate Appropriation" -ForegroundColor Green
    Write-Host "Location: $destination"
    Write-Host ''
    Write-Host 'In TTS, open Objects > Saved Objects > Lobo Top 40, then spawn the Map #1 bag.'
    Write-Host 'Clear Table, then drop the bag onto Place bags here to deploy it.'
    Write-Host 'Deployment and Mission buttons appear at the top after deployment.'
    exit 0
} catch {
    Write-Host ''
    Write-Host ('Installation failed: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
