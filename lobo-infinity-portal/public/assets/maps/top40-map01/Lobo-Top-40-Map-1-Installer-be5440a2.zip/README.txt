LOBO'S TOP 40 MAP #1 - DEPLOYABLE BAG INSTALLER

1. Extract the entire ZIP.
2. Double-click INSTALL.cmd.
3. In your Infinity TTS table, open Objects > Saved Objects > Lobo Top 40.
4. Spawn the bag named SET_Lobo's Top 40 Map #1.
5. Clear Table, then drop the bag onto the standard Place bags here loader.

This is a native SET_ map bag containing all 76 terrain and objective objects.
It uses your latest layout, including the added planters and building states.
Deployment and Mission controls travel with the mat and appear at screen top.
Deployment shows thin forward boundaries only; exclusion borders are dashed.
The six mission tabs include all scenario rules and the complete Panoply Chart.
They do not require replacing the table's Global script or loading a full save.
Clear Table removes the controls with the mat.

Installed file:
Documents\My Games\Tabletop Simulator\Saves\Saved Objects\Lobo Top 40\Lobo-Top-40-Map-1-Bag.json
The installer uses Windows' configured Documents location.
Previous copies of this bag are backed up under Tabletop Simulator\Lobo Map Backups.

If installing manually, copy Objects\Lobo-Top-40-Map-1-Bag.json into that Saved Objects folder.

JSON, scripts and native loader placement records validated outside TTS.
In-game appearance has not been tested inside TTS.
