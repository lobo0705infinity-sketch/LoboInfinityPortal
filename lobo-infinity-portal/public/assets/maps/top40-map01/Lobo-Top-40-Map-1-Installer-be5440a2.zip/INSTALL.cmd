@echo off
setlocal
cd /d "%~dp0"
echo Installing Lobo's Top 40 Map #1...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Lobo-Top-40-Map-1.ps1"
set "InstallResult=%ERRORLEVEL%"
echo.
pause
exit /b %InstallResult%
