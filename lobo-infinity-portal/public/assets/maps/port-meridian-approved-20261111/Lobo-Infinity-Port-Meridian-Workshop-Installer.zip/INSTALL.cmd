@echo off
setlocal
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Workshop.ps1" %*
set "result=%ERRORLEVEL%"
echo.
pause
exit /b %result%
