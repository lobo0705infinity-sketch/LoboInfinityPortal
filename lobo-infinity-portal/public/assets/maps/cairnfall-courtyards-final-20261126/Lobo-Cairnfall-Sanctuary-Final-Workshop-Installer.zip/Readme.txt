﻿Cairnfall Sanctuary — Courtyards Final
Approved by Lobo for ITS18 Battleground and Top 40 Losers Round 4 on November 26, 2026.

1. Extract this entire ZIP and run Install.cmd. If TTS saves are in a custom location, drag the Tabletop Simulator or Saves folder onto Install.cmd.
2. Open Games > Save & Load in Tabletop Simulator.
3. To play Cairnfall immediately, load Cairnfall Sanctuary - Courtyards Final - Battleground - Play Table.
4. To update subscribers, open Lobo Maps - Cairnfall Sanctuary Final - Workshop Collection. Then choose Upload > Workshop Upload > Update Workshop and select Lobo's Infinity Maps (3719263238).

The collection opens its map catalogue. Both Cairnfall entries use the approved layout. The installer creates two new numbered saves and a folder under Objects > Saved Objects containing both standalone map bags.
