Saltwick Floodgate | Working Harbour R4
Area of Interest | Final release, November 26, 2026

Extract the entire ZIP to a folder, then run Install.cmd. For a custom TTS data location, drag your Tabletop Simulator folder onto Install.cmd. The installer also recognizes the Saves folder. It adds new save slots and a Saltwick Stage bag under Objects > Saved Objects.

To play immediately, open Games > Save & Load and select
Saltwick Floodgate - Working Harbour R4 - Area of Interest - Play Table.

To update Lobo's existing Infinity Maps Workshop item, open
Lobo Maps - Saltwick Floodgate R4 - Workshop Collection.
Select Upload > Workshop Upload > Update Workshop and choose the existing item. Its Steam Workshop ID is 3719263238.

The catalogue includes the approved Saltwick layout under both ITS18 Area Of Interest and Lobo's Top 40 Winners Round 5. Select a bag from the catalogue and drop its pickup copy on the Stage.
