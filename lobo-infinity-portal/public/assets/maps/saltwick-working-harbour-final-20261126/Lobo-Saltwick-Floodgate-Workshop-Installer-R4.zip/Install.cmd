@echo off
"%~dp0Lobo-Saltwick-Floodgate-Setup.exe" %*
