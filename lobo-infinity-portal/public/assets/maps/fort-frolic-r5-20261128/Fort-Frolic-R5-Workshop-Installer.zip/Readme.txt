﻿FORT FROLIC
ITS Season 18 Double Bind

Extract the entire ZIP, then double-click INSTALL.cmd. For a custom Tabletop Simulator data folder, drag the folder or its Saves folder onto INSTALL.cmd.

PUBLISH THE COLLECTION
In Games > Save & Load, open Lobo Maps - Fort Frolic R5 - Workshop Collection. Its catalogue has 110 setups. Under Missions, search for Fort Frolic to locate the original or make a pickup copy. Choose Upload > Workshop Upload > Update Workshop and select Lobo's Infinity Maps, item 3719263238.

PLAY THE APPROVED TABLE
In Games > Save & Load, open Fort Frolic R5 - Double Bind - Play Table. You can also load Fort Frolic R5 - Double Bind through Objects > Saved Objects > Lobo - Infinity Maps on the normal Infinity table.

The three mission antennas follow the centerline of the Lower Atrium. The middle antenna stands on the brass sun. All fourteen buildings with removable roofs start roof-on. State 1 opens the interior. State 2 restores the roof.

The payload contains the approved Fort Frolic layout from TS_Save_469. The installer checks the bundled files before copying them. Running it again recognizes the same saves.
