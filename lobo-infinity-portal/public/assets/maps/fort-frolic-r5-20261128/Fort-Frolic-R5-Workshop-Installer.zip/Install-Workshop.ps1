﻿param([Parameter(Position = 0)][string]$TtsDirectory)
$ErrorActionPreference = 'Stop'
$collection = @{ Title='Lobo Maps - Fort Frolic R5 - Workshop Collection'; File='Workshop-Collection.json'; Hash='36ca6dd842fe0fa90caeca08d267e2c7d5675d98b7f480c0163ee96f7dcc91f0'; Preview='Workshop-Preview.png'; PreviewHash='6cfe81a77f4ea3b698dd52161f83ce3003ada96223ef38ea3553b55d9ab14be4' }
$play = @{ Title='Fort Frolic R5 - Double Bind - Play Table'; File='Play-Table.json'; Hash='7c3cbc4d9be76b48efd654daaf9a84d866856ec1aae5a075332b614c4e6c6185'; Preview='Fort-Frolic-Preview.png'; PreviewHash='3c8a873290b7da720d1c71ce5a12666a68926d974c9d9e5595810971adfe1e9f' }
$bag = @{ Label='Fort Frolic R5 - Double Bind'; File='Fort-Frolic.json'; Hash='6c2f5b1caccd998ee8e6722003ad3220d703772f1e7191351e9b0c2fc32beafd'; Preview='Fort-Frolic-Preview.png'; PreviewHash='3c8a873290b7da720d1c71ce5a12666a68926d974c9d9e5595810971adfe1e9f'; Folder='Lobo - Infinity Maps' }
$mutex = $null
$ownsMutex = $false

function Get-SavesDirectory([string]$customDirectory) {
    if ($customDirectory) {
        $root = (Get-Item -LiteralPath $customDirectory).FullName
        if (-not [IO.Directory]::Exists($root)) { throw 'Drag the Tabletop Simulator data folder or its Saves folder onto INSTALL.cmd.' }
        if ((Split-Path -Path $root -Leaf) -ieq 'Saves') { return $root }
    } else {
        $docs = [Environment]::GetFolderPath([Environment+SpecialFolder]::MyDocuments)
        $candidates = @()
        if ($docs) { $candidates += (Join-Path $docs 'My Games/Tabletop Simulator') }
        if ($env:USERPROFILE) { $candidates += (Join-Path $env:USERPROFILE 'Documents/My Games/Tabletop Simulator') }
        if ($env:OneDrive) { $candidates += (Join-Path $env:OneDrive 'Documents/My Games/Tabletop Simulator') }
        $root = $candidates | Where-Object { [IO.Directory]::Exists((Join-Path $_ 'Saves')) } | Select-Object -First 1
        if (-not $root) { $root = $candidates | Where-Object { [IO.Directory]::Exists($_) } | Select-Object -First 1 }
        if (-not $root -and $docs) { $root = Join-Path $docs 'My Games/Tabletop Simulator' }
        if (-not $root) { throw 'Could not locate your Tabletop Simulator data. Drag its data folder or Saves folder onto INSTALL.cmd.' }
    }
    return [IO.Directory]::CreateDirectory((Join-Path $root 'Saves')).FullName
}

function Assert-Hash([string]$file, [string]$expected) {
    if ((Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash -ine $expected) {
        throw ('Checksum failed for ' + (Split-Path $file -Leaf) + '. Extract a fresh copy of the installer ZIP.')
    }
}

function Install-SavedMap([string]$saves, [string]$files, $map) {
    $savedObjects = Join-Path $saves 'Saved Objects'
    $folder = [IO.Directory]::CreateDirectory((Join-Path $savedObjects $map.Folder)).FullName
    $source = Join-Path $files $map.File
    $thumbnail = Join-Path $files $map.Preview
    for ($number = 0; ; $number++) {
        $stem = if ($number -eq 0) { $map.Label } else { $map.Label + ' (' + $number + ')' }
        $dest = Join-Path $folder ($stem + '.json')
        $image = Join-Path $folder ($stem + '.png')
        if ([IO.File]::Exists($dest)) {
            if ((Get-FileHash -LiteralPath $dest -Algorithm SHA256).Hash -ine $map.Hash) { continue }
            if (-not [IO.File]::Exists($image)) { [IO.File]::Copy($thumbnail, $image, $false) }
            return
        }
        if ([IO.File]::Exists($image)) { continue }
        $temp = Join-Path $folder ([Guid]::NewGuid().ToString('N') + '.installing')
        $tempImage = Join-Path $folder ([Guid]::NewGuid().ToString('N') + '.installing')
        $madeImage = $false
        try {
            [IO.File]::Copy($source, $temp)
            [IO.File]::Copy($thumbnail, $tempImage)
            Assert-Hash $temp $map.Hash
            Assert-Hash $tempImage $map.PreviewHash
            [IO.File]::Move($tempImage, $image)
            $madeImage = $true
            [IO.File]::Move($temp, $dest)
            return
        } catch {
            if ($madeImage -and [IO.File]::Exists($image)) { [IO.File]::Delete($image) }
            throw
        } finally {
            foreach ($staged in @($temp, $tempImage)) {
                if ([IO.File]::Exists($staged)) { [IO.File]::Delete($staged) }
            }
        }
    }
}


function Install-NumberedSave([string]$saves,[string]$files,$entry) {
    $source = Join-Path $files $entry.File
    $picture = Join-Path $files $entry.Preview
    $size = (Get-Item -LiteralPath $source).Length
    $number = [long]1
    foreach ($candidate in (Get-ChildItem -LiteralPath $saves -File -Filter 'TS_Save_*')) {
        if ($candidate.Name -notmatch '^TS_Save_(\d+)\.(json|png)$') { continue }
        $number = [Math]::Max($number, [long]$Matches[1] + 1)
        if ($candidate.Extension -ine '.json' -or $candidate.Length -ne $size) { continue }
        if ((Get-FileHash -LiteralPath $candidate.FullName -Algorithm SHA256).Hash -ieq $entry.Hash) {
            $existingPicture = [IO.Path]::ChangeExtension($candidate.FullName,'.png')
            if (-not [IO.File]::Exists($existingPicture)) { [IO.File]::Copy($picture,$existingPicture,$false) }
            return $candidate.FullName
        }
    }
    $tempSave = Join-Path $saves ([Guid]::NewGuid().ToString('N')+'.installing')
    $tempImage = Join-Path $saves ([Guid]::NewGuid().ToString('N')+'.installing')
    try {
        [IO.File]::Copy($source,$tempSave)
        [IO.File]::Copy($picture,$tempImage)
        Assert-Hash $tempSave $entry.Hash
        Assert-Hash $tempImage $entry.PreviewHash
        while ($true) {
            $stem=Join-Path $saves ('TS_Save_'+$number)
            $number++
            $target=$stem+'.json'
            $thumbnail=$stem+'.png'
            if ([IO.File]::Exists($target) -or [IO.File]::Exists($thumbnail)) { continue }
            try { [IO.File]::Move($tempImage,$thumbnail) } catch [IO.IOException] {
                if ([IO.File]::Exists($thumbnail)) { continue }
                throw
            }
            try { [IO.File]::Move($tempSave,$target) } catch {
                [IO.File]::Move($thumbnail,$tempImage)
                if ([IO.File]::Exists($target)) { continue }
                throw
            }
            return $target
        }
    } finally {
        foreach ($tempFile in @($tempSave,$tempImage)) {
            if ([IO.File]::Exists($tempFile)) { [IO.File]::Delete($tempFile) }
        }
    }
}
try {
    $files = Join-Path $PSScriptRoot 'Files'
    foreach ($entry in @($collection,$play,$bag)) {
        Assert-Hash (Join-Path $files $entry.File) $entry.Hash
        Assert-Hash (Join-Path $files $entry.Preview) $entry.PreviewHash
    }
    $saves=Get-SavesDirectory $TtsDirectory
    $mutex=New-Object System.Threading.Mutex($false,'LoboInfinityWorkshopInstall')
    try { $ownsMutex=$mutex.WaitOne(60000) } catch [System.Threading.AbandonedMutexException] { $ownsMutex=$true }
    if (-not $ownsMutex) { throw 'Another map installation is still running. Let it finish and try again.' }
    $workshopSave=Install-NumberedSave $saves $files $collection
    $playSave=Install-NumberedSave $saves $files $play
    Install-SavedMap $saves $files $bag
    Write-Host ("Workshop collection: "+$collection.Title+"  ["+$workshopSave+"]") -ForegroundColor Green
    Write-Host ("Play table: "+$play.Title+"  ["+$playSave+"]")
    Write-Host 'In TTS, load the Workshop collection. Choose Upload > Workshop Upload > Update Workshop > 3719263238.'
    if ([Environment]::OSVersion.Platform -eq [PlatformID]::Win32NT) {
        try { Start-Process 'https://steamcommunity.com/sharedfiles/filedetails/?id=3719263238' } catch { Write-Host 'Workshop item 3719263238.' }
    }
    exit 0
} catch {
    Write-Host ('Installation failed. '+$_.Exception.Message) -ForegroundColor Red
    exit 1
} finally {
    if ($ownsMutex) { $mutex.ReleaseMutex() }
    if ($mutex) { $mutex.Dispose() }
}
