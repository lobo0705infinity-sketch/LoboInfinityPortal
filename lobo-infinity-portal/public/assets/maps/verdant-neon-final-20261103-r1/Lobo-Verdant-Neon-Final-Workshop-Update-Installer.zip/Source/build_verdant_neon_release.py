from pathlib import Path
import json, copy, re, hashlib, struct, zipfile, shutil, os
from lupa import LuaRuntime
from PIL import Image

ROOT=Path(__file__).resolve().parent
APP=ROOT/'portal-update/lobo-infinity-portal'
OUT=ROOT/'release-verdant-neon'
REV='verdant-neon-final-20261103-r1'
PUBLIC=APP/'public/assets/maps'/REV
PUBLIC.mkdir(parents=True,exist_ok=True)
def read(p): return json.loads(Path(p).read_text())
def write(p,v):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 p.write_text(json.dumps(v,ensure_ascii=False,separators=(',',':'))+'\n')
def walk(o):
 yield o
 for k in ['ContainedObjects','ChildObjects']:
  for q in o.get(k,[]):yield from walk(q)
 for q in o.get('States',{}).values():yield from walk(q)
def rewrite(v,fn):
 if isinstance(v,dict):return {fn(k):rewrite(q,fn)for k,q in v.items()}
 if isinstance(v,list):return [rewrite(q,fn)for q in v]
 return fn(v)if isinstance(v,str)else v
def lua(v):
 if isinstance(v,dict):return '{'+','.join('['+json.dumps(k)+']='+lua(q)for k,q in v.items())+'}'
 if isinstance(v,list):return '{'+','.join(lua(q)for q in v)+'}'
 if isinstance(v,str):return json.dumps(v,ensure_ascii=False)
 if isinstance(v,bool):return str(v).lower()
 if v is None:return 'nil'
 return repr(v)
def manifest(roots):
 rows=[]
 for o in roots:
  for q in [o,*o.get('States',{}).values()]:
   t=q['Transform'];v=[t[k]for k in ['posX','posY','posZ','rotX','rotY','rotZ']]
   v[3:]=[struct.unpack('f',struct.pack('f',x))[0]for x in v[3:]]
   rows.append('--'+q['GUID']+','+','.join(format(x,'.17g')for x in v))
 return '\r\n'.join(rows)+'\r\n'

baseline=read(ROOT/'published-workshop-decoded.json')
collection=copy.deepcopy(baseline)
by={o['GUID']:o for o in collection['ObjectStates']}
used={o['GUID']for b in collection['ObjectStates']for o in walk(b)if o.get('GUID')}
seq=0xe80000
def fresh():
 global seq
 while f'{seq:06x}'in used:seq+=1
 s=f'{seq:06x}';seq+=1;used.add(s);return s

configs=[
 dict(key='verdant',name='Verdant Exchange',mission='Uplink Center',source=ROOT/'verdant-final/Map-Bags/Verdant-Exchange-Uplink-Center-FINAL.json',slug='uplink-center-2',general='1010b1',event='03c892',label="Lobo's Top 40 Winners Round 3 Map",bracket='Winners',round=3,roundKey='winners-3',tag='LoboMap:VerdantExchangeR1',oldName='Dustline Outpost',theme='Botanical Research Campus'),
 dict(key='neon',name='Neon Shogunate',mission='Double Bind',source=ROOT/'compact-installer/SavedObjects/Neon-Shogunate-Double-Bind-Top40-Final.json',slug='double-bind-1',general='100993',event='ff1100',label="Lobo's Top 40 Final Map",bracket='Grand Final',round=1,roundKey='grand-final',tag='LoboMap:NeonShogunateR4',oldName='Tidal Turbines',theme='Moonlit Neon City')
]
assert 'ff1100' not in used;used.add('ff1100')
records=[];pairs=[]
for cfg in configs:
 source=read(cfg['source']);original=source['ObjectStates'][0]
 for kind,guid in [('general',cfg['general']),('top40',cfg['event'])]:
  ids={o['GUID']:fresh()for o in walk(original)if o.get('GUID')};ids[original['GUID']]=guid
  tag=cfg['tag']+('GeneralFinal'if kind=='general'else'Top40Final')
  pat=re.compile(r'(?<![0-9a-fA-F])('+'|'.join(ids)+r')(?![0-9a-fA-F])')
  def fn(s):
   parts=re.split(r'(https?://[^\s\"\'<>\\]+)',s)
   for i in range(0,len(parts),2):parts[i]=pat.sub(lambda m:ids[m[0]],parts[i]).replace(cfg['tag'],tag)
   return ''.join(parts)
  bag=rewrite(original,fn)
  # Packed objects intentionally sit off-table until the native Stage loads them.
  # The approved comment manifest holds their actual deployment transforms.
  bag['LuaScript']=fn(original['LuaScript'])
  label='ITS18 '+cfg['mission']+' — '+cfg['name']if kind=='general'else cfg['label']
  bag.update(GUID=guid,Nickname='SET_'+label,Description=cfg['name']+' | '+cfg['mission']+' | Approved final layout.\n'+('Latest user-edited TS_Save_42 layout.'if cfg['key']=='verdant'else'Official Lobo Top 40 Double Bind final.')+'\nDrop on STAGE > DROP BAGS HERE. Use Stage CLEAR TABLE for cleanup.\n'+('General-pool map.'if kind=='general'else cfg['label'])+'\n'+original.get('Description',''),LuaScriptState='',XmlUI='')
  if guid in by:
   bag['Transform']=copy.deepcopy(by[guid]['Transform'])
   collection['ObjectStates'][collection['ObjectStates'].index(by[guid])]=bag
  else:
   bag['Transform']=dict(posX=38,posY=1.065,posZ=-30.6,rotX=0,rotY=0,rotZ=0,scaleX=1,scaleY=1,scaleZ=1)
   collection['ObjectStates'].append(bag)
  by[guid]=bag
  filename=cfg['slug']+'.json'if kind=='general'else('Lobos-Top-40-Winners-Round-3-Map.json'if cfg['key']=='verdant'else'Lobos-Top-40-Final-Map.json')
  wrapper=copy.deepcopy(source);wrapper['SaveName']=label;wrapper['ObjectStates']=[copy.deepcopy(bag)]
  wrapper['ObjectStates'][0]['Transform']=dict(posX=0,posY=1,posZ=0,rotX=0,rotY=0,rotZ=0,scaleX=1,scaleY=1,scaleZ=1)
  write(PUBLIC/filename,wrapper)
  friendly=(cfg['name'].replace(' ','-')+'-'+cfg['mission'].replace(' ','-')+'-FINAL'if kind=='general'else filename[:-5])+'.json'
  shutil.copy2(PUBLIC/filename,OUT/'Map-Bags'/friendly)
  records.append(dict(guid=guid,name=cfg['name'],kind=kind,download='/assets/maps/'+REV+'/'+filename,sha256=hashlib.sha256((PUBLIC/filename).read_bytes()).hexdigest(),objects=len(bag['ContainedObjects']),installerFile=friendly))
  pairs.append(dict(name=cfg['name'],kind=kind,guid=guid,guidMap=ids,originalTag=cfg['tag'],releaseTag=tag,sourceSha256=hashlib.sha256(cfg['source'].read_bytes()).hexdigest()))

# Retain the live collection, changing only the requested bags and catalogue entries.
L=LuaRuntime(unpack_returned_tuples=True)
L.execute(collection['LuaScript'].splitlines()[0]+'\n'+collection['LuaScript'].splitlines()[1]+'\nfunction releaseItems()return ITEMS end')
def fromlua(v):
 if hasattr(v,'items'):
  d={k:fromlua(q)for k,q in v.items()}
  return [d[k]for k in sorted(d)]if d and all(isinstance(k,int)for k in d)else d
 return v
catalogue=fromlua(L.globals().releaseItems())
for cfg in configs:
 for kind,guid in [('general',cfg['general']),('top40',cfg['event'])]:
  item=next((x for x in catalogue if x['guid']==guid),None)
  if item is None:item={};catalogue.append(item)
  bag=by[guid];item.update(guid=guid,category='missions'if kind=='general'else'top40',title=cfg['name']if kind=='general'else cfg['label'],mission=cfg['mission'],theme=cfg['theme'],source_name=bag['Nickname'],home={k:bag['Transform']['pos'+k.upper()]for k in ['x','y','z']})
collection['LuaScript']=re.sub(r'^local ITEMS = .*$',lambda _:'local ITEMS = '+lua(catalogue),collection['LuaScript'],count=1,flags=re.M)
collection['SaveName']="Lobo's Infinity Maps - Verdant and Neon FINAL"
write(OUT/'Collection/Lobo-Workshop-Verdant-Neon-FINAL.json',collection)
write(OUT/'Review/ownership-mapping.json',pairs)

meta=read(APP/'shared/lobo-workshop-current.json')
for cfg in configs:
 row=next(m for m in meta['maps']if m['slug']==cfg['slug']);bag=by[cfg['general']]
 row['labelAliases']=list(dict.fromkeys(row.get('labelAliases',[])+[row['name'],row['workshopName'],row['workshopBagName']]))
 row.update(name=cfg['name'],workshopName=bag['Nickname'][4:],workshopBagName=bag['Nickname'],objectCount=len(bag['ContainedObjects']),download=next(r['download']for r in records if r['guid']==cfg['general']),captureDate='2026-11-03',previewKind='geometry',overhead='/assets/maps/'+REV+'/'+cfg['key']+'-overhead.webp',angled='/assets/maps/'+REV+'/'+cfg['key']+'-angled.webp',diagram='/assets/maps/'+REV+'/'+cfg['key']+'-overhead.webp',sourceOverhead=None,sourceAngled=None,sourceNote=('Exact user-edited TS_Save_42 final layout; two removed screen clusters stay removed. Matching Top 40 Winners Round 3.'if cfg['key']=='verdant'else'Official Double Bind grand-final map: five city districts, illuminated signs and kiosks, cycling billboards and sky traffic. Replaces the Tidal Turbines Double Bind slot; other Tidal Turbines missions remain. Matching Top 40 Final map.')+' Stage drop deployment and Clear Table cleanup; no bag buttons. Offline checks passed; live TTS physics remains unverified.')
 if cfg['key']=='neon':row['layoutKey']=2025
meta.update(updatedAt='2026-11-03',downloadRevision=REV,download='/assets/maps/'+REV+'/Lobo-ITS18-Drop-Zone-Maps.zip',installer='/assets/maps/'+REV+'/Lobo-Verdant-Neon-Final-Workshop-Update-Installer.zip')
(APP/'shared/lobo-workshop-current.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
p=APP/'shared/top40-round-maps.mjs';s=p.read_text();start=s.index('[',s.index('export const TOP40_ROUND_MAPS'));end=s.index('\n]',start)+2;rounds=json.loads(s[start:end])
for cfg in configs:
 row=next((m for m in rounds if m['key']==cfg['roundKey']),None)
 if row is None:row={};rounds.append(row)
 row.update(key=cfg['roundKey'],mission=cfg['mission'],name=cfg['name'],workshopLabel=cfg['label'],href='/event/lobos-top-40/maps/'+cfg['roundKey'],download=next(r['download']for r in records if r['guid']==cfg['event']),angled='/assets/maps/'+REV+'/'+cfg['key']+'-angled.webp',overhead='/assets/maps/'+REV+'/'+cfg['key']+'-overhead.webp',generalHref='/maps/'+cfg['slug'],bracket=cfg['bracket'],round=cfg['round'])
s=s[:start]+json.dumps(rounds,ensure_ascii=False,indent=2)+s[end:]
s=re.sub(r"export const TOP40_APPROVED_MAPS_INSTALLER = '[^']+'","export const TOP40_APPROVED_MAPS_INSTALLER = '"+meta['installer']+"'",s)
p.write_text(s)
p=APP/'shared/top40-launch-plan.json';plan=read(p)
for row in plan['rounds']:
 for cfg in configs:
  if row['bracket']==cfg['bracket']and row['bracketRound']==cfg['round']and row['mission']==cfg['mission']:row['map']=cfg['label']
p.write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
p=APP/'src/public/Top40MapPage.tsx';p.write_text(p.read_text().replace('Lobo’s Infinity Maps - Five Map Update R1','Lobo’s Infinity Maps - Verdant and Neon FINAL'))

inventory=read(APP/'public/assets/maps/approved-five-map-update-20261102-r1/release-inventory.json')
inventory['maps']=[r for r in inventory['maps']if r['guid']not in {r['guid']for r in records}]+records
inventory.update(release='Verdant and Neon FINAL',saveName=collection['SaveName'],top40Maps=11,steamPublication='Requires in-game Update Workshop for existing item 3719263238; installer does not publish Steam.')
write(PUBLIC/'release-inventory.json',inventory)
with zipfile.ZipFile(PUBLIC/'Lobo-ITS18-Drop-Zone-Maps.zip','w',zipfile.ZIP_DEFLATED,9)as z:
 for m in meta['maps']:z.write(APP/('public'+m['download']),m['slug']+'.json')

previews={
 'neon-angled.webp':ROOT/'final-work/Review/Neon-Shogunate-Double-Bind-Overview.jpg',
 'neon-overhead.webp':OUT/'Review/neon-overhead.jpg',
 'verdant-angled.webp':ROOT/'verdant-render/Previews/Verdant-Exchange-Overview.png',
 'verdant-overhead.webp':ROOT/'verdant-render/Previews/Verdant-Exchange-Overhead.png'
}
for name,path in previews.items():Image.open(path).convert('RGB').save(PUBLIC/name,quality=88)
for r in records:
 key='verdant'if r['name']=='Verdant Exchange'else'neon'
 Image.open(PUBLIC/(key+'-angled.webp')).resize((512,512)).save(OUT/'Map-Bags'/r['installerFile'].replace('.json','.png'))
Image.open(PUBLIC/'neon-angled.webp').resize((512,512)).save(OUT/'Collection/Lobo-Workshop-Verdant-Neon-FINAL.png')
print('Built',len(records),'updated bags; 40 general, 50 Aurora VII, 11 Top 40; live baseline preserved.')
