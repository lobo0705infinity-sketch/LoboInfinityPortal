from pathlib import Path
import json,copy,re,hashlib,collections,concurrent.futures,urllib.request
from lupa import LuaRuntime
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'release-verdant-neon'
def read(p):return json.loads(Path(p).read_text())
def walk(o):
 yield o
 for k in ['ContainedObjects','ChildObjects']:
  for q in o.get(k,[]):yield from walk(q)
 for q in o.get('States',{}).values():yield from walk(q)
def rewrite(v,fn):
 if isinstance(v,dict):return {fn(k):rewrite(q,fn)for k,q in v.items()}
 if isinstance(v,list):return [rewrite(q,fn)for q in v]
 return fn(v)if isinstance(v,str)else v
collection=read(OUT/'Collection/Lobo-Workshop-Verdant-Neon-FINAL.json');by={o['GUID']:o for o in collection['ObjectStates']}
baseline=read(ROOT/'published-workshop-decoded.json');changed={'1010b1','100993','03c892'}
for old in baseline['ObjectStates']:
 if old['GUID']not in changed:assert by[old['GUID']]==old,('Unrelated object changed',old['GUID'])
for k in baseline:
 if k not in ['ObjectStates','LuaScript','SaveName']:assert baseline[k]==collection[k],k
assert len(collection['ObjectStates'])==len(baseline['ObjectStates'])+1
pairs=read(OUT/'Review/ownership-mapping.json');sources={
 'Verdant Exchange':read(ROOT/'verdant-final/Map-Bags/Verdant-Exchange-Uplink-Center-FINAL.json')['ObjectStates'][0],
 'Neon Shogunate':read(ROOT/'compact-installer/SavedObjects/Neon-Shogunate-Double-Bind-Top40-Final.json')['ObjectStates'][0]}
L=LuaRuntime(unpack_returned_tuples=True);compile=L.eval('function(s)local f,e=load(s);return f~=nil,e end')
scripts=0;ids=[];urls=set();stagecases=[]
stage=(ROOT/'native-stage.lua').read_text().replace('!=','~=')
for pair in pairs:
 bag=by[pair['guid']];source=sources[pair['name']];inverse={v:k for k,v in pair['guidMap'].items()}
 pat=re.compile(r'(?<![0-9a-fA-F])('+'|'.join(inverse)+r')(?![0-9a-fA-F])')
 def undo(s):
  parts=re.split(r'(https?://[^\s\"\'<>\\]+)',s)
  for i in range(0,len(parts),2):parts[i]=pat.sub(lambda m:inverse[m[0]],parts[i]).replace(pair['releaseTag'],pair['originalTag'])
  return ''.join(parts)
 assert rewrite(bag['ContainedObjects'],undo)==source['ContainedObjects'],'Approved component data changed'
 assert undo(bag['LuaScript'])==source['LuaScript'],'Approved final deployment layout changed'
 assert bag['LuaScript'].endswith('\r\n')and not re.search(r'(?<!\r)\n',bag['LuaScript'])
 assert not any(x in bag['LuaScript']for x in ['function','createButton'])
 positions={line[2:8]:list(map(float,line[9:].split(',')))for line in bag['LuaScript'].splitlines()}
 assert len(positions)==len(bag['LuaScript'].splitlines())
 for o in walk(bag):
  if o.get('GUID'):ids.append(o['GUID'])
  s=o.get('LuaScript','')
  assert not any(x in s for x in ['--[[Object base code]]','obje.glitch.me','tcejbo gninwapS'])
  if s:
   ok,err=compile(s.replace('!=','~='));assert ok,(o.get('GUID'),err);scripts+=1
  if o.get('CustomMesh'):
   for k in ['MeshURL','DiffuseURL','NormalURL','ColliderURL']:
    u=o['CustomMesh'].get(k)
    if u:urls.add(u)
 for root in bag['ContainedObjects']:
  assert root['GUID']in positions
  for alt in root.get('States',{}).values():assert alt['GUID']in positions
 # Execute the actual Infinity Stage script for default and every available state.
 choices=['default']+sorted({k for o in bag['ContainedObjects']for k in o.get('States',{})})
 for choice in choices:
  l=LuaRuntime(unpack_returned_tuples=True)
  l.execute('''registry={};spawned={};hld=0
Global={getVar=function(k)if k=='hld'then return hld end end,setVar=function(k,v)if k=='hld'then hld=v end end}
function getObjectFromGUID(g)return registry[g]end
function broadcastToAll(...)end
self={getPosition=function()return {-29.73,1.06,-49.84}end}
''');l.execute(stage);g=l.globals();g.cb=None
  g.entries=l.table_from([l.table_from({'guid':o['GUID']})for o in bag['ContainedObjects']]);g.manifestText=bag['LuaScript'];g.bagName=bag['Nickname']
  l.execute('''local b={name='Bag',guid='bag001'}
b.getName=function()return bagName end;b.getGUID=function()return b.guid end
b.getLuaScript=function()return manifestText end;b.getObjects=function()return entries end
b.lock=function()end;b.setName=function(n)b.nick=n end;b.setScale=function(v)b.scale=v end;b.setPosition=function(v)b.position=v end
b.takeObject=function(t)
 local o={guid=t.guid,resting=true};o.getGUID=function()return o.guid end;o.lock=function()end
 o.setPosition=function(p)o.position=p end;o.getPosition=function()return o.position end
 o.setRotation=function(r)o.rotation=r end;o.getRotation=function()return o.rotation end
 o.getName=function()return o.guid end;o.destruct=function()registry[o.guid]=nil end
 registry[o.guid]=o;spawned[#spawned+1]=o;self.call(t.callback,o)
end
self.call=function(n,p)_G[n](p)end;b.destruct=function()registry[b.guid]=nil end
registry[b.guid]=b;onCollisionEnter({collision_object=b})
for i=1,20000 do if cb then update()else break end end
''')
  assert len(g.spawned)==len(bag['ContainedObjects'])
  assert g.hld==0 and g.cb is None,'Stage busy flag released'
  active=[]
  for i,o in enumerate(bag['ContainedObjects'],1):
   obj=g.spawned[i];values=positions[o['GUID']]
   assert all(abs(obj.position[j+1]-values[j])<1e-6 for j in range(3))
   assert all(abs(obj.rotation[j+1]-values[j+3])<.0005 for j in range(3))
   alt=o.get('States',{}).get(choice)
   if alt:
    g.oldGuid=o['GUID'];g.newGuid=alt['GUID'];l.execute('local o=registry[oldGuid];registry[oldGuid]=nil;o.guid=newGuid;registry[newGuid]=o')
    active.append((alt['GUID'],values))
   else:active.append((o['GUID'],values))
  l.execute('btnTrash()')
  for guid,v in active:
   if abs(v[0])<44 and abs(v[1])<26 and abs(v[2])<26:assert g.registry[guid]is None,('Stage failed to clear',choice,guid)
  stagecases.append(dict(map=pair['name'],kind=pair['kind'],state=choice,roots=len(bag['ContainedObjects']),deploy=True,clear=True,busyReleased=True))
assert len(ids)==len(set(ids)),'Updated families have overlapping identities'
otherids={o['GUID']for b in baseline['ObjectStates']if b['GUID']not in changed for o in walk(b)if o.get('GUID')}
assert not set(ids)&otherids,'Updated family collides with retained map'
neon=next(o for o in by['100993']['ContainedObjects']if '-- Stage cleanup includes'in o.get('LuaScript',''))
s=neon['LuaScript'];cleanup=s[s.index('-- Stage cleanup includes'):s.index('-- Double Bind mission guides:')]
l=LuaRuntime(unpack_returned_tuples=True);l.execute('''retired=0;objects={};releases=0
self={isDestroyed=function()return false end}
function getObjectsWithTag(t)return objects end
function onDestroy()releases=releases+1 end
for i=1,9 do local o={dead=false};o.isDestroyed=function()return o.dead end;o.destruct=function()if not o.dead then retired=retired+1;o.dead=true end end;objects[i]=o end
''');l.execute(cleanup);l.globals().onDestroy();assert l.globals().retired==9 and l.globals().releases==1
report=dict(status='passed',sourceWorkshopUpdated=read(ROOT/'workshop-details-release.json')['time_updated'],approvedFinalLayoutsPreserved=True,unrelatedPublishedObjectsUnchanged=True,generalTop40CopiesIndependent=True,updatedFamilyUniqueGUIDs=len(ids),scriptsParsed=scripts,nativeStageCases=stagecases,skyCleanupCallbackPassed=True,liveTTSTested=False)
(OUT/'Review/release-validation.json').write_text(json.dumps(report,indent=2)+'\n')
def checkurl(url):
 try:
  r=urllib.request.urlopen(urllib.request.Request(url,method='HEAD'),timeout=35)
  return dict(url=url,status=r.status)
 except Exception:
  try:
   r=urllib.request.urlopen(url,timeout=35);b=r.read()
   return dict(url=url,status=r.status,method='GET',bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
  except Exception as e:return dict(url=url,error=str(e))
prior=OUT/'Review/hosted-assets-validation.json'
cached={r['url']:r for r in read(prior).get('results',[])if r.get('status')==200}if prior.exists()else{}
pending=sorted(urls-set(cached))
with concurrent.futures.ThreadPoolExecutor(max_workers=12)as pool:results=[cached[u]for u in sorted(urls&set(cached))]+list(pool.map(checkurl,pending))
bad=[r for r in results if r.get('status')!=200]
(OUT/'Review/hosted-assets-validation.json').write_text(json.dumps(dict(checked=len(urls),failed=bad,results=results),indent=2)+'\n')
assert not bad,bad
print(json.dumps(dict(status='passed',stageCases=len(stagecases),scripts=scripts,uniqueIDs=len(ids),hostedAssets=len(urls),unchangedOtherObjects=len(baseline['ObjectStates'])-3)))
