from pathlib import Path
import json,hashlib,subprocess,shutil,tempfile
pkg=Path('release-verdant-neon').resolve();root=Path(tempfile.mkdtemp(prefix='lobo-final-installer-'))
(root/'Saves').mkdir()
pwsh='/tmp/harmony-installer-pwsh/pwsh'
def hashes():return {p.relative_to(root/'Saves').as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in (root/'Saves').rglob('*')if p.is_file()}
fresh=subprocess.run([pwsh,'-NoProfile','-File',str(pkg/'Install.ps1'),'-TtsRoot',str(root)],capture_output=True,text=True)
assert fresh.returncode==0,fresh.stdout+fresh.stderr
legacy=root/'Saves/Saved Objects/Verdant-Exchange-Uplink-Center-R5.json'
legacy.unlink(missing_ok=True)
before=hashes()
legacy.write_text('{"legacy":true}')
r=subprocess.run([pwsh,'-NoProfile','-File',str(pkg/'Install.ps1'),'-TtsRoot',str(root)],capture_output=True,text=True)
assert r.returncode==0,r.stdout+r.stderr
assert not legacy.exists()and any((root/'Lobo Map Backups').rglob(legacy.name))
assert before==hashes()
wrap=Path('installer-tests/injected-write-failure.ps1');wrap.write_text('''$script:moves=0
function global:Move-Item {param($LiteralPath,$Destination,[switch]$Force)
 $script:moves++;if($script:moves -eq 5){throw 'Injected installer write failure'}
 Microsoft.PowerShell.Management\Move-Item -LiteralPath $LiteralPath -Destination $Destination -Force:$Force
}
& "'''+str(pkg/'Install.ps1')+'''" -TtsRoot "'''+str(root)+'''"
exit $LASTEXITCODE
''')
r=subprocess.run([pwsh,'-NoProfile','-File',str(wrap)],capture_output=True,text=True)
assert r.returncode==1,r.stdout+r.stderr
assert 'Injected installer write failure'in r.stdout
assert hashes()==before,'Rollback changed installed data'
bad=Path('installer-tests/corrupt-package');shutil.copytree(pkg,bad,dirs_exist_ok=True)
f=next((bad/'Map-Bags').glob('*.json'));f.write_bytes(f.read_bytes()+b'corrupt')
r=subprocess.run([pwsh,'-NoProfile','-File',str(bad/'Install.ps1'),'-TtsRoot',str(root)],capture_output=True,text=True)
assert r.returncode==1 and 'Package verification failed'in r.stdout
assert hashes()==before,'Corrupt package touched installed data'
report=dict(status='passed',runtime='PowerShell 7.4.6 on Linux',fresh=True,reinstall=True,legacyBackupAndRetirement=True,injectedWriteFailureRollback=True,corruptionRejectedBeforeWrites=True,nativeWindowsTested=False)
(pkg/'Review/installer-validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
