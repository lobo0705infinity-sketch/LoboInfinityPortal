﻿param([string]$TtsRoot='')
$ErrorActionPreference='Stop'
$changed=@();$retired=@();$backups=@{};$temporary=@()
try {
 if (-not $TtsRoot) {$TtsRoot=Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'My Games/Tabletop Simulator'}
 $saves=Join-Path $TtsRoot 'Saves'
 if (-not (Test-Path -LiteralPath $saves -PathType Container)) {throw 'TTS Saves folder not found. Pass your Tabletop Simulator folder to Install.cmd.'}
 $objects=Join-Path $saves 'Saved Objects'
 $manifest=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'Install-Manifest.json') -Raw | ConvertFrom-Json
 if ($manifest.Count -ne 10) {throw 'Expected the collection and four named map bags with thumbnails.'}
 $items=@()
 foreach ($entry in $manifest) {
  $source=Join-Path $PSScriptRoot $entry.path
  if ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne $entry.sha256) {throw ('Package verification failed: '+$entry.path)}
  if ($entry.path.EndsWith('.json')) {
   $text=[IO.File]::ReadAllText($source);$null=ConvertFrom-Json -InputObject $text
   if ($text -match '__ASSET_BASE__|__LOCAL_ASSET_BASE__|__REALISM_BASE__|file:///') {throw ('Unresolved local asset: '+$entry.path)}
  }
  $destinationRoot=if ($entry.path.StartsWith('Collection/')) {$saves} else {$objects}
  $items+=@{Source=$source;Target=(Join-Path $destinationRoot (Split-Path $entry.path -Leaf));Hash=$entry.sha256}
 }
 $backup=Join-Path $TtsRoot ('Lobo Map Backups/Verdant-Neon-FINAL/'+(Get-Date -Format 'yyyyMMdd-HHmmss-ffff')+'-'+[Guid]::NewGuid().ToString('N').Substring(0,8))
 $null=New-Item -ItemType Directory -Path $backup -Force
 $null=New-Item -ItemType Directory -Path $objects -Force
 $legacyNames=@('Verdant-Exchange-Uplink-Center-FINAL','Neon-Shogunate-Double-Bind-Top40-Final')
 foreach ($number in 1..5) {$legacyNames+=('Verdant-Exchange-Uplink-Center-R'+$number)}
 foreach ($name in $legacyNames) {
  foreach ($extension in @('.json','.png')) {
   $path=Join-Path $objects ($name+$extension)
   if ((Test-Path -LiteralPath $path) -and -not ($items.Target -contains $path)) {$retired+=$path}
  }
 }
 # Retire verified GUID-named copies of the four replaced collection bags.
 foreach ($id in @('1010b1','100993','03c892','ff1100')) {
  $path=Join-Path $objects ($id+'.json')
  if (Test-Path -LiteralPath $path) {
   $saved=Get-Content -LiteralPath $path -Raw | ConvertFrom-Json
   if ($saved.ObjectStates.Count -eq 1 -and $saved.ObjectStates[0].GUID -eq $id) {
    $retired+=$path
    $image=Join-Path $objects ($id+'.png');if (Test-Path -LiteralPath $image) {$retired+=$image}
   }
  }
 }
 foreach ($target in @($items.Target)+$retired | Select-Object -Unique) {
  if (Test-Path -LiteralPath $target) {
   $copy=Join-Path $backup ([IO.Path]::GetFileName($target))
   Copy-Item -LiteralPath $target -Destination $copy -Force
   if ((Get-FileHash -LiteralPath $copy).Hash -ne (Get-FileHash -LiteralPath $target).Hash) {throw 'Backup verification failed.'}
   $backups[$target]=$copy
  }
 }
 foreach ($item in $items) {
  $stage=$item.Target+'.installing-'+[Guid]::NewGuid().ToString('N');$temporary+=$stage
  Copy-Item -LiteralPath $item.Source -Destination $stage
  if ((Get-FileHash -LiteralPath $stage -Algorithm SHA256).Hash -ne $item.Hash) {throw 'Staged file verification failed.'}
  $changed+=$item.Target;Move-Item -LiteralPath $stage -Destination $item.Target -Force
  if ((Get-FileHash -LiteralPath $item.Target -Algorithm SHA256).Hash -ne $item.Hash) {throw 'Installed file verification failed.'}
 }
 foreach ($path in $retired) {$changed+=$path;Remove-Item -LiteralPath $path -Force}
 Write-Host 'Installed the full Lobo collection and four FINAL map bags in the main Saved Objects folder.' -ForegroundColor Green
 Write-Host "In TTS load: Lobo's Infinity Maps - Verdant and Neon FINAL"
 Write-Host 'Then Workshop Upload > Update Workshop > EXISTING item 3719263238.'
 Write-Host 'Keep the existing title and visibility. Confirm Steam reports a successful update.'
 Write-Host 'The installer does not publish to Steam. The final upload must be performed inside TTS.'
 Write-Host ('Backups: '+$backup)
 exit 0
} catch {
 $failure=$_
 foreach ($target in $changed) {
  if ($backups.ContainsKey($target)) {Copy-Item -LiteralPath $backups[$target] -Destination $target -Force}
  elseif (Test-Path -LiteralPath $target) {Remove-Item -LiteralPath $target -Force}
 }
 Write-Host ('Installation failed: '+$failure.Exception.Message) -ForegroundColor Red
 exit 1
} finally {
 foreach ($path in $temporary) {if (Test-Path -LiteralPath $path) {Remove-Item -LiteralPath $path -Force}}
}
