import json,re,copy,collections
from pathlib import Path
ROOT=Path(__file__).parent/'unpacked'
data=json.loads((ROOT/'Lobo-ITS18-Revised-Library.json').read_text());specs=json.loads((ROOT/'mission-specifications.json').read_text())
bad='https://steamusercontent-a.akamaihd.net/ugc/929303676573608844/077667514B9647A58E54408941578615A56F05A7/'
removed=collections.Counter();fixedbacks=0
for i,b in enumerate(o for o in data['ObjectStates'] if o['Name']=='Bag'):
 kept=[]
 for o in b['ContainedObjects']:
  n=o.get('Nickname','')
  if any(w in n for w in ['Area of Interest','Designated Zone','Stabilization Zone','Data-Harvester','Infected']):removed['unwanted mission components']+=1;continue
  # Small custom image tiles are legacy signs and markers, not the scenery models.
  if o['Name']=='Custom_Tile' and max(o['Transform']['scaleX'],o['Transform']['scaleZ'])<3:removed['decorative image tiles']+=1;continue
  if o.get('CustomImage',{}).get('ImageSecondaryURL')==bad:
   o['CustomImage']['ImageSecondaryURL']=o['CustomImage']['ImageURL'];fixedbacks+=1
  kept.append(o)
 b['ContainedObjects']=kept
 def dec(key):return json.loads(json.loads(re.search(r'local '+key+r'=JSON.decode\(("(?:\\.|[^"\\])*")\)',b['LuaScript'])[1]))
 lines=dec('LINES');dep=specs[i//2]['deployment']
 lines=lines[:1 if dep=='diagonal' else 6 if dep=='split' else 3]
 values={'POS':{o['GUID']:[o['Transform'][k] for k in ['posX','posY','posZ','rotX','rotY','rotZ']] for o in kept},'LOCKS':{o['GUID']:o.get('Locked',True) for o in kept},'LINES':lines}
 for key,v in values.items():
  decl='local '+key+'=JSON.decode('+json.dumps(json.dumps(v,separators=(',',':')))+')\n'
  b['LuaScript'],n=re.subn(r'local '+key+r'=JSON.decode\(("(?:\\.|[^"\\])*")\)\n',lambda m:decl,b['LuaScript'],count=1);assert n==1
 path=ROOT/f"{specs[i//2]['slug']}-{i%2+1}.json";s=json.loads(path.read_text());s['ObjectStates']=copy.deepcopy(kept);s['LuaScript']='local LINES=JSON.decode('+json.dumps(json.dumps(lines))+')\nfunction onLoad() Global.setVectorLines(LINES) end';path.write_text(json.dumps(s,separators=(',',':')))
for m in specs:
 m['objectives']=[o for o in m['objectives'] if 'Infected' not in o['name']]
 m['extras']=[o for o in m['extras'] if not any(w in o for w in ['Area of Interest','Designated Zone','Neutralization Area','Stabilization Zone','Data-Harvester','Infected'])]
(ROOT/'Lobo-ITS18-Revised-Library.json').write_text(json.dumps(data,separators=(',',':')));(ROOT/'mission-specifications.json').write_text(json.dumps(specs,indent=2))
(ROOT/'review-cleanup-validation.json').write_text(json.dumps(dict(removed=removed,repaired_missing_tile_backs=fixedbacks,markings='Board outline and deployment zones only; corner DZ templates retained.'),indent=2))
print(json.dumps(dict(removed=removed,repaired_missing_tile_backs=fixedbacks)))
