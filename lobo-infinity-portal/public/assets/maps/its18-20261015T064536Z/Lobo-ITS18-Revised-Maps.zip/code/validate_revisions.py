import json,sys,math,re,ast,copy
from pathlib import Path
ROOT=Path(__file__).parent;sys.path.insert(0,str(ROOT/'lua-runtime'))
from lupa import LuaRuntime
from map_geometry import shape,pieces
from shapely.geometry import Point,box
out=ROOT/'updated-maps';s=json.loads((out/'Lobo-ITS18-Revised-Library.json').read_text());bags=[o for o in s['ObjectStates'] if o['Name']=='Bag']
assert len(bags)==40
guids=[];script_count=0
def walk(o):
 yield o
 for key in ['ChildObjects','ContainedObjects']:
  for c in o.get(key,[]):yield from walk(c)
 for c in o.get('States',{}).values():yield from walk(c)
for root in s['ObjectStates']:
 for o in walk(root):
  guids.append(o['GUID']);text=o.get('LuaScript','');assert 'obje.glitch.me' not in text;assert '--[[Object base code]]' not in text
  if text:
   lua=LuaRuntime();lua.execute('assert(load(...))',text);script_count+=1
assert len(set(guids))==len(guids),'Duplicate nested object identifiers'
for b in bags:
 lua=LuaRuntime(unpack_returned_tuples=True)
 lua.globals().JSON=lua.table_from({'decode':lambda x:lua.table_from(json.loads(x),recursive=True)})
 lua.globals().entries=lua.table_from([{'guid':o['GUID']} for o in b['ContainedObjects']],recursive=True)
 lua.execute('''calls={};buttons={};vars={};drawn={}
 Global={setVectorLines=function(x)drawn=x end,getVar=function(k)return vars[k]end,setVar=function(k,v)vars[k]=v end}
 self={createButton=function(x)table.insert(buttons,x)end,getObjects=function()return entries end,takeObject=function(p)
 local r={guid=p.guid,position=p.position,rotation=p.rotation};table.insert(calls,r);p.callback_function({setLock=function(v)r.locked=v end}) end}
 function broadcastToAll(...)end function broadcastToColor(...)end''')
 lua.execute(b['LuaScript']);lua.globals().onLoad();assert len(lua.globals().buttons)==1
 lua.globals().loadMap(None,'Red');assert len(lua.globals().calls)==0
 lua.globals().loadMap(None,'White');assert len(lua.globals().calls)==len(b['ContainedObjects'])
 expected={o['GUID']:o for o in b['ContainedObjects']}
 for c in lua.globals().calls.values():
  o=expected[c['guid']];t=o['Transform']
  for i,k in enumerate(['posX','posY','posZ'],1):assert abs(c['position'][i]-t[k])<1e-6
  assert c['locked']==o.get('Locked',True)
 n=len(lua.globals().calls);lua.globals().loadMap(None,'White');assert len(lua.globals().calls)==n
rooms=[]
for p in sorted(out.glob('*-[12].json')):
 m=json.loads(p.read_text());objs=m['ObjectStates'];floor=next((o for o in objs if o['Nickname'].startswith('Objective Room — 8')),None)
 for o in objs:
  match=re.match(r'^(\d+(?:\.\d+)?) mm marker;',o.get('Description',''))
  if not match:continue
  assert not o.get('ChildObjects') and not o.get('States')
  expected=float(match[1])/25.4;ps=list(pieces(o));lo=min(p['lo'][0] for p in ps);hi=max(p['hi'][0] for p in ps);assert abs((hi-lo)-expected)<.001
 if floor:
  assert all(abs(a-b)<1e-5 for a,b in zip(shape(floor).bounds,[-4,-4,4,4]))
  walls=[o for o in objs if o['Nickname']=='Objective Room — infinite-height wall'];assert len(walls)==8
  # Measure the clear central openings between the generated wall panels.
  spans=[]
  for sign in [-1,1]:
   horiz=[shape(o).bounds for o in walls if abs((shape(o).bounds[1]+shape(o).bounds[3])/2-sign*4)<.01]
   vert=[shape(o).bounds for o in walls if abs((shape(o).bounds[0]+shape(o).bounds[2])/2-sign*4)<.01]
   horiz.sort();vert.sort(key=lambda x:x[1]);spans.extend([(horiz[1][0]-horiz[0][2])*25.4,(vert[1][1]-vert[0][3])*25.4])
  assert all(abs(w-55)<1e-5 for w in spans);rooms.append(dict(file=p.name,scoring_footprint_inches=[8,8],gate_widths_mm=spans))
report=json.loads((out/'change-log.json').read_text())
tree=ast.parse((ROOT/'repair_maps.py').read_text());outer=next(n for n in tree.body if isinstance(n,ast.For) and isinstance(n.target,ast.Tuple));helpers={};exec(compile(ast.Module(body=tree.body[:tree.body.index(outer)],type_ignores=[]),'geometry-check-helpers','exec'),helpers)
slots={};independent_clearance=[]
for e in report:
 slot=slots.get(e['slug'],0)+1;slots[e['slug']]=slot
 single=json.loads((out/(e['slug']+'-'+str(slot)+'.json')).read_text())
 m=copy.deepcopy(next(m for m in helpers['specs'] if m['slug']==e['slug']));m['objectives']=e['objectives']
 terrain=[o for o in single['ObjectStates'] if not o['Nickname'].startswith('Objective Room') and not re.match(r'^\d+(?:\.\d+)? mm marker;',o.get('Description','')) and o['Transform']['posX']<25]
 groups,_=helpers['groups_for'](terrain,e['surface']);reservation=helpers['geometry_reservations'](m)
 conflicts=sum(g['shape'].intersection(reservation).area>.001 for g in groups)
 independent_clearance.append(dict(mission=e['mission'],slot=slot,conflicts=conflicts))
assert all(x['conflicts']==0 for x in independent_clearance),independent_clearance
for mission in {x['mission'] for x in report}:
 pair=[x for x in report if x['mission']==mission];assert len(pair)==2 and pair[0]['terrain']!=pair[1]['terrain']
v=dict(setups=40,missions=20,terrain_layouts=len({x['terrain'] for x in report}),clearance_checks_without_flag=sum(x['remaining_terrain_reservation_collisions']==0 for x in report),nested_identifiers_checked=len(guids),lua_scripts_parsed=script_count,loader_mock_tests_passed=40,rooms=rooms,engine_tested=False,play_approved=False,pending=['Actual TTS asset and texture loading','Confirm imported asset scale and collider bounds against measured geometry','Official Wide Gate token size check (modelled openings are 55 mm)','Objective approach routes and player-placed template options','Deployment concealment, protected exits, sightlines, rooftops and ladders','Mission diagram verification and a playtest on each layout'])
v['independent_clearance_recheck']=independent_clearance
(out/'validation.json').write_text(json.dumps(v,indent=2));print(json.dumps(v,indent=2))
