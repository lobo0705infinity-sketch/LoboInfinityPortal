import concurrent.futures,json,re,pathlib,urllib.request
root=pathlib.Path(__file__).parent/'draft-inspect'
out=root/'official-rules';out.mkdir(exist_ok=True)
missions=json.loads((root/'unpacked/mission-specifications.json').read_text())
def walk(o,texts):
 if isinstance(o,dict):
  if isinstance(o.get('text'),str):texts.append(o['text'])
  for v in o.values():walk(v,texts)
 elif isinstance(o,list):
  for v in o:walk(v,texts)
 elif isinstance(o,str) and ('"root"' in o or '"children"' in o):
  try:walk(json.loads(o),texts)
  except Exception:pass
def fetch(m):
 try:
  html=urllib.request.urlopen(m['source_url'],timeout=30).read().decode()
  texts=[]
  for x in re.findall(r'self.__next_f.push\((.*?)\)</script>',html):
   try:
    flight=json.loads(x)[1]
    if not isinstance(flight,str):continue
    for line in flight.splitlines():
     try:walk(json.loads(line.split(':',1)[1]),texts)
     except Exception:pass
   except Exception:pass
  (out/(m['slug']+'.txt')).write_text('\n'.join(texts))
  (out/(m['slug']+'.html')).write_text(html)
  return m['slug'],len(texts)
 except Exception as e:return m['slug'],str(e)
with concurrent.futures.ThreadPoolExecutor(max_workers=10) as ex:
 for r in ex.map(fetch,missions):print(r,flush=True)
