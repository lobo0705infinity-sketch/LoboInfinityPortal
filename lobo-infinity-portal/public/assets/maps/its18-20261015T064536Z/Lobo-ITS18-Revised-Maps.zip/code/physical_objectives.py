import json,copy,re,sys,collections,math
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation as R
sys.path.insert(0,str(Path(__file__).parent/'unpacked/code'))
from map_geometry import bounds,BOUNDS,pieces
ROOT=Path(__file__).parent/'unpacked'
data=json.loads((ROOT/'Lobo-ITS18-Revised-Library.json').read_text())
specs=json.loads((ROOT/'mission-specifications.json').read_text())
allsource=[]
for f in ['candidates','physical-objectives','beacon-candidates','other-objectives']:
 allsource+=json.loads((ROOT.parent.parent/'source'/f'{f}.json').read_text())
def src(g):return copy.deepcopy(next(o for o in allsource if o['GUID']==g))
assets={'console':src('50d514'),'panoply':src('1b225e'),'antenna':src('6d1d8a'),'coffin':src('20a674'),'crate':src('598caf'),'turret':src('4abd58')['ChildObjects'][0]}
people=[src(g) for g in ['5de581','84ce5f','2259c6','3b2eda']]
original_source=json.loads((ROOT.parent.parent/'source/Lobo-Infinity-Maps-43-Saves.json').read_text())
base=next(o for b in original_source['ObjectStates'] for o in b.get('ContainedObjects',[]) if o['GUID']=='7d09d4')
base=copy.deepcopy(base);base.pop('ChildObjects',None)
counter=0x300000;counts=collections.Counter();logs=[]
def clean(o):
 for k in ['ChildObjects','States','AttachedVectorLines']:o.pop(k,None)
 o['LuaScript']='';o['LuaScriptState']='';o['XmlUI']='';return o
def category(label):
 n=label.lower()
 if 'panoply' in n:return 'panoply'
 if 'antenna' in n or 'beacon' in n:return 'antenna'
 if 'turret' in n:return 'turret'
 if 'civilian' in n or 'infected' in n or re.search(r'hyperthermal tech [1-9]',n) or 'data-harvester' in n:return 'person'
 if 'coffin' in n or 'tech box' in n:return 'coffin'
 if 'box' in n or 'pack' in n or 'prototype' in n or 'id token' in n:return 'crate'
 return 'console'
for bi,b in enumerate(o for o in data['ObjectStates'] if o['Name']=='Bag'):
 log=[]
 for index,old in enumerate(b['ContainedObjects']):
  desc=old.get('Description','');label=old.get('Nickname','')
  ismarker='mm marker' in desc
  if not ismarker and not desc.startswith('Physical '):continue
  if any(word in label for word in ['Area of Interest','Designated Zone','Stabilization Zone']):continue
  mm=float(re.search(r'([\d.]+) mm marker',desc)[1]) if ismarker else (float(re.search(r'on a ([\d.]+) mm',desc)[1]) if 'on a ' in desc else 40.)
  support=old['Transform']['posY']-.025 if ismarker else min(p['lo'][1] for p in pieces(old))
  if ismarker:x,z=old['Transform']['posX'],old['Transform']['posZ']
  else:
   ps=list(pieces(old));lo=np.min([p['lo'] for p in ps],axis=0);hi=np.max([p['hi'] for p in ps],axis=0);x,z=(lo[0]+hi[0])/2,(lo[2]+hi[2])/2
  role=category(label)
  template=people[index%len(people)] if role=='person' else assets[role]
  new=clean(copy.deepcopy(template));new['GUID']=old['GUID'];new['Nickname']=label;new['Locked']=old.get('Locked',True)
  low,high,_=bounds(new);lo=np.array(low);hi=np.array(high);center=(lo+hi)/2
  # Fit the model inside the circular mission base without distorting proportions.
  import hashlib
  url=new.get('CustomMesh',{}).get('MeshURL') or new.get('CustomAssetbundle',{}).get('AssetbundleURL','')
  hull=BOUNDS.get(hashlib.sha256(url.encode()).hexdigest(),{}).get('hull')
  if hull:radius=max(math.hypot(a-center[0],c-center[2]) for a,c in hull)
  else:radius=math.hypot((hi[0]-lo[0])/2,(hi[2]-lo[2])/2)
  scale=(mm/50.8)/radius
  if role=='antenna':scale=min(scale,1.)
  yaw=270.;rot=R.from_euler('y',yaw,degrees=True);offset=rot.apply([center[0]*scale,0,center[2]*scale])
  t=new['Transform'];t.update(posX=float(x-offset[0]),posY=float(support+.10-lo[1]*scale),posZ=float(z-offset[2]),rotX=0,rotY=yaw,rotZ=0,scaleX=scale,scaleY=scale,scaleZ=scale)
  child=clean(copy.deepcopy(base));counter+=1;child['GUID']=f'{counter:06x}';child['Nickname']=f'{mm:g} mm objective base'
  bl,bh,_=bounds(child);bc=(np.array(bl)+np.array(bh))/2
  sx=(mm/25.4)/(bh[0]-bl[0])/scale;sz=(mm/25.4)/(bh[2]-bl[2])/scale;sy=.1/(bh[1]-bl[1])/scale
  child['Transform'].update(posX=float(center[0]-bc[0]*sx),posY=float(lo[1]-.1/scale-bl[1]*sy),posZ=float(center[2]-bc[2]*sz),rotX=0,rotY=0,rotZ=0,scaleX=sx,scaleY=sy,scaleZ=sz)
  child['ColorDiffuse']={'r':.12,'g':.15,'b':.18};child['Description']='Attached mission footprint base.'
  new['ChildObjects']=[child];new['Description']=f'Physical {role} model on a {mm:g} mm mission base. Mission position and mobility preserved.'
  b['ContainedObjects'][index]=new;counts[role]+=1
  ps=list(pieces(new));lowest=min(p['lo'][1] for p in ps);assert abs(lowest-support)<1e-6
  log.append(dict(guid=new['GUID'],label=label,physical_model=role,diameter_mm=mm,center=[float(x),float(z)],bottom=float(lowest)))
 pos={o['GUID']:[o['Transform'][k] for k in ['posX','posY','posZ','rotX','rotY','rotZ']] for o in b['ContainedObjects']}
 decl='local POS=JSON.decode('+json.dumps(json.dumps(pos,separators=(',',':')))+')\n'
 b['LuaScript'],n=re.subn(r'local POS=JSON.decode\(("(?:\\.|[^"\\])*")\)\n',lambda m:decl,b['LuaScript'],count=1);assert n==1
 path=ROOT/f"{specs[bi//2]['slug']}-{bi%2+1}.json";single=json.loads(path.read_text());single['ObjectStates']=copy.deepcopy(b['ContainedObjects']);path.write_text(json.dumps(single,separators=(',',':')))
 logs.append(dict(mission=specs[bi//2]['name'],slot=bi%2+1,replacements=log))
remaining=[o['Nickname'] for b in data['ObjectStates'] if b['Name']=='Bag' for o in b['ContainedObjects'] if 'mm marker' in o.get('Description','')]
assert all(any(w in n for w in ['Area of Interest','Designated Zone','Stabilization Zone']) for n in remaining)
(ROOT/'Lobo-ITS18-Revised-Library.json').write_text(json.dumps(data,separators=(',',':')))
(ROOT/'physical-objectives-validation.json').write_text(json.dumps(dict(physical_models=sum(counts.values()),model_categories=counts,flat_templates_remaining=collections.Counter(remaining),setup_changes=logs),indent=2))
print(json.dumps(dict(physical_models=sum(counts.values()),model_categories=counts,flat_area_templates_remaining=len(remaining))))
