import ast,json,copy,sys,re,collections
from pathlib import Path
import numpy as np
from shapely.geometry import box,Point
from shapely.ops import unary_union
ROOT=Path(__file__).parent/'unpacked';CODE=ROOT/'code';sys.path.insert(0,str(CODE))
tree=ast.parse((CODE/'create_replacement_maps.py').read_text())
cut=next(i for i,n in enumerate(tree.body) if isinstance(n,ast.Assign) and any(isinstance(v,ast.Name) and v.id=='new_reports' for v in n.targets))
ns={'__file__':str((CODE/'create_replacement_maps.py').resolve())}
exec(compile(ast.Module(body=tree.body[:cut],type_ignores=[]),'templates','exec'),ns)
geo=ns['ns'];templates=ns['templates'];shifted=ns['shifted'];props=ns['props'];planter=ns['planter']
data=json.loads((ROOT/'Lobo-ITS18-Revised-Library.json').read_text());specs=json.loads((ROOT/'mission-specifications.json').read_text());selected=json.loads((ROOT/'selected-layouts.json').read_text())
bags=[o for o in data['ObjectStates'] if o['Name']=='Bag'];index=13;bag=bags[index]
assert 'Critical Intervention' in bag['Nickname'] and any(n in bag['Nickname'] for n in ['Freight Terminal','Bastion Courtyard'])
def dec(key):return json.loads(json.loads(re.search(r'local '+key+r'=JSON.decode\(("(?:\\.|[^"\\])*")\)',bag['LuaScript'])[1]))
lines=dec('LINES');oldsurface=lines[0]['points'][0][1]-.04;surface=1.1
for line in lines:
 for p in line['points']:p[1]+=surface-oldsurface
objects=[]
for o in bag['ContainedObjects']:
 if o.get('Nickname','').startswith('Objective Room') or o.get('Description','').startswith('Physical '):
  q=copy.deepcopy(o);q['Transform']['posY']+=surface-oldsurface;objects.append(q)
for q in objects:
 if q.get('Nickname','').startswith('Objective Room') or q.get('Nickname') in ['Data Console','Armed Turret 1','Armed Turret 2']:
  q['Transform']['posY']+=.12
assert len([o for o in objects if o.get('Nickname','').startswith('Objective Room')])==13
# A clean two-inch perimeter around the room and four wide approach corridors.
reserved=box(-6,-6,6,6).union(box(-12,-1.15,12,1.15)).union(box(-1.15,-12,1.15,12))
mission=specs[6]
for o in mission['objectives']:reserved=reserved.union(Point(o['x'],o['z']).buffer(o['diameter_mm']/50.8+20/25.4))
floor=geo['flatclean'](ns['original_floor']);floor['Nickname']='Bastion Courtyard — 48 × 48 inch table';floor['Transform'].update(posX=0,posY=1,posZ=0,rotX=0,rotY=270,rotZ=0,scaleX=24,scaleY=1,scaleZ=24);objects.insert(0,floor)
occupied=[];usage=collections.Counter();placements=[];terrain=[]
slots=[(-18,-16,8,7),(-18,0,8,8),(-17,17,8,7),(18,-17,8,7),(19,-1,7,8),(16,17,8,8),(-8,-16,6,8),(-7,16,6,7),(8,-16,6,7),(7,16,7,8),(-9.5,-8.5,5.5,5),(-9.5,8.5,5.5,5),(9.5,-8.5,5.5,5),(9.5,8.5,5.5,5),(-20,-8,5,4),(-20,8,5,4),(20,-8,5,4),(20,8,5,4)]
for n,(x,z,mw,md) in enumerate(slots):
 options=[]
 for ti,t in enumerate(templates):
  if usage[t['key']]>=2:continue
  for a in [0,90]:
   w,d=(t['width'],t['depth']) if a==0 else (t['depth'],t['width'])
   scale=min(1,mw/w,md/d)
   if scale<.8:continue
   score=(mw-w*scale)+(md-d*scale)+usage[t['key']]*8
   options.append((score,ti,a,scale))
 for _,ti,a,scale in sorted(options):
  t=templates[ti];objs=shifted(t,x,z,a,scale,surface);sh=unary_union([geo['shape'](o) for o in objs])
  if not box(-23.8,-23.8,23.8,23.8).covers(sh) or sh.intersects(reserved) or any(sh.distance(p)<1.0 for p in occupied):continue
  objects+=objs;terrain+=objs;occupied.append(sh);usage[t['key']]+=1
  placements.append(dict(role='building',center=[x,z],source=t['source'],scale=scale));break
 else:raise RuntimeError('No building fits planned block '+str(n))
# Add varied scenery at street bends without touching room or approach reserves.
scatter=[(-12,-10),(-11,10),(12,-9),(11,11),(-21,10),(21,-10),(-3,-19),(2,20),(-10,-22),(10,22),(-21,-10),(21,11),(0,-14),(0,14)]
scenery=props+([planter] if planter else [])
for n,(x,z) in enumerate(scatter):
 for j in range(len(scenery)):
  prop=scenery[(n+j)%len(scenery)];objs=shifted(prop,x,z,90 if n%2 else 0,1,surface);sh=unary_union([geo['shape'](o) for o in objs])
  if not box(-23.8,-23.8,23.8,23.8).covers(sh) or sh.intersects(reserved) or any(sh.distance(p)<.8 for p in occupied):continue
  objects+=objs;terrain+=objs;occupied.append(sh);placements.append(dict(role='street cover',kind=prop['key'],center=[x,z]));break
assert len(placements)>=20
# Every new object and attachment receives its own globally unique ID.
counter=0x400000
def rekey(o):
 global counter
 counter+=1;o['GUID']=f'{counter:06x}'
 for c in o.get('ChildObjects',[]):rekey(c)
 for c in o.get('States',{}).values():rekey(c)
for o in objects:rekey(o)
for o in terrain:
 sh=geo['shape'](o)
 assert sh is None or not sh.intersects(reserved)
bag['ContainedObjects']=objects;bag['Nickname']='SET_ITS18 Critical Intervention — Bastion Courtyard — NEW LAYOUT'
bag['Description']='New objective-room layout replacing Freight Terminal. 8-inch room; two-inch scenery-free perimeter and four clear entrance corridors. In-TTS asset and play review required.'
values={'POS':{o['GUID']:[o['Transform'][k] for k in ['posX','posY','posZ','rotX','rotY','rotZ']] for o in objects},'LOCKS':{o['GUID']:o.get('Locked',True) for o in objects},'LINES':lines}
for key,value in values.items():
 decl='local '+key+'=JSON.decode('+json.dumps(json.dumps(value,separators=(',',':')))+')\n'
 bag['LuaScript'],n=re.subn(r'local '+key+r'=JSON.decode\(("(?:\\.|[^"\\])*")\)\n',lambda m:decl,bag['LuaScript'],count=1);assert n==1
singlepath=ROOT/'critical-intervention-2.json';single=json.loads(singlepath.read_text());single['ObjectStates']=copy.deepcopy(objects);single['SaveName']='Critical Intervention — Bastion Courtyard';single['LuaScript']='local LINES=JSON.decode('+json.dumps(json.dumps(lines))+')\nfunction onLoad() Global.setVectorLines(LINES) end';singlepath.write_text(json.dumps(single,separators=(',',':')))
selected[index].update(terrain='Bastion Courtyard',source_save=None,new_layout=True);specs[6]['terrain_layouts'][1]='Bastion Courtyard'
(ROOT/'selected-layouts.json').write_text(json.dumps(selected,indent=2));(ROOT/'mission-specifications.json').write_text(json.dumps(specs,indent=2));(ROOT/'Lobo-ITS18-Revised-Library.json').write_text(json.dumps(data,separators=(',',':')))
(ROOT/'bastion-courtyard-validation.json').write_text(json.dumps(dict(replaces='Critical Intervention / Freight Terminal / slot 2',layout='Bastion Courtyard',buildings=len(slots),street_cover=len(placements)-len(slots),room_scenery_overlap=False,room_perimeter_inches=2,entrance_corridor_width_inches=2.3,placements=placements,in_tts_tested=False),indent=2))
print('Bastion Courtyard generated:',len(objects),'objects;',len(placements),'terrain groups; zero room/perimeter/entrance scenery overlaps.')
