import concurrent.futures, hashlib, json, pathlib, urllib.request, time
ROOT=pathlib.Path(__file__).parent
cache=ROOT/'geometry-cache';cache.mkdir(exist_ok=True)
s=json.loads((ROOT/'draft-inspect/unpacked/Lobo-ITS18-Coverage-Draft.json').read_text())
urls={}
def walk(o):
 yield o
 for key in ['ChildObjects','ContainedObjects']:
  for child in o.get(key,[]):yield from walk(child)
 for child in o.get('States',{}).values():yield from walk(child)
for b in s['ObjectStates']:
 for o in walk(b):
  for k,fields in [('CustomMesh',['MeshURL','ColliderURL']),('CustomAssetbundle',['AssetbundleURL'])]:
   for f in fields:
    u=o.get(k,{}).get(f)
    if u:urls[u]='bundle' if k=='CustomAssetbundle' else 'obj'
def fetch(item):
 u,kind=item;p=cache/(hashlib.sha256(u.encode()).hexdigest()+'.'+kind)
 if p.exists():return u,dict(path=str(p),kind=kind,size=p.stat().st_size)
 for attempt in range(2):
  try:
   data=urllib.request.urlopen(u,timeout=25).read();p.write_bytes(data)
   return u,dict(path=str(p),kind=kind,size=len(data))
  except Exception as e:err=str(e)
 return u,dict(kind=kind,error=err)
out={}
with concurrent.futures.ThreadPoolExecutor(max_workers=20) as ex:
 for u,r in ex.map(fetch,urls.items()):out[u]=r
(cache/'index.json').write_text(json.dumps(out,indent=2))
print('Downloaded',sum('path' in x for x in out.values()),'of',len(out),'assets',flush=True)
print('Failures',[(u,x['error']) for u,x in out.items() if 'error' in x],flush=True)
