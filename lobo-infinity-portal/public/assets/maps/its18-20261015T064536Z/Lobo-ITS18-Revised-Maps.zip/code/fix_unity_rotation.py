import json,copy,re,warnings
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation as R
ROOT=Path(__file__).parent/'unpacked'
data=json.loads((ROOT/'Lobo-ITS18-Revised-Library.json').read_text())
source=json.loads((ROOT.parent.parent/'source/Lobo-Infinity-Maps-43-Saves.json').read_text())
selected=json.loads((ROOT/'selected-layouts.json').read_text())
sourcebags={int(re.search(r'\[(\d+)\]$',o['Nickname'])[1]):o for o in source['ObjectStates'] if o['Name']=='Bag'}
def key(o):return (o['Name'],o.get('CustomMesh',{}).get('MeshURL',''),o.get('CustomAssetbundle',{}).get('AssetbundleURL',''))
def candidates(b):
 out={}
 for o in b.get('ContainedObjects',[]):
  out.setdefault(key(o),[]).append((o['Transform']['rotX'],o['Transform']['rotZ']))
 return out
allpairs={}
for b in sourcebags.values():
 for k,v in candidates(b).items():allpairs.setdefault(k,[]).extend(v)
records=[]
for i,b in enumerate(o for o in data['ObjectStates'] if o['Name']=='Bag'):
 refs=candidates(sourcebags[selected[i]['source_save']]) if selected[i]['source_save'] else allpairs
 for o in b['ContainedObjects']:
  t=o['Transform']
  # Invert the earlier XYZ conversion, then recover the original Euler branch
  # from the authored asset's pitch/roll. Unity uses Z-X-Y, not XYZ.
  oldmatrix=(R.from_euler('y',90,degrees=True)*R.from_euler('xyz',[t['rot'+k] for k in 'XYZ'],degrees=True)).as_matrix()
  options=refs.get(key(o),allpairs.get(key(o),[]))+[(0,0)]
  best=None
  for x,z in options:
   x=(x+180)%360-180;z=(z+180)%360-180
   mid=R.from_euler('z',-z,degrees=True).as_matrix()@oldmatrix@R.from_euler('x',-x,degrees=True).as_matrix()
   y=float(np.degrees(np.arctan2(mid[0,2],mid[0,0])))
   error=np.max(abs(R.from_euler('xyz',[x,y,z],degrees=True).as_matrix()-oldmatrix))
   if best is None or error<best[0]:best=(error,x,y,z)
  error,x,y,z=best
  assert error<2e-6,(o['GUID'],error)
  # Change only Unity yaw; preserve authored pitch and roll exactly.
  t['rotX']=x;t['rotY']=(y-90)%360;t['rotZ']=z
  before=R.from_euler('zxy',[z,x,y],degrees=True).as_matrix()
  after=R.from_euler('zxy',[t['rotZ'],t['rotX'],t['rotY']],degrees=True).as_matrix()
  assert np.allclose(after,R.from_euler('y',-90,degrees=True).as_matrix()@before,atol=1e-8)
  if o['Name']=='Custom_Tile' and max(t['scaleX'],t['scaleZ'])>=20:
   normal=after@np.array([0,1,0]);assert abs(normal[1])>.999,(o['GUID'],normal)
   records.append(dict(guid=o['GUID'],surface=o.get('Nickname',''),normal_y=float(normal[1]),pitch=x,roll=z))
 pos={o['GUID']:[o['Transform'][k] for k in ['posX','posY','posZ','rotX','rotY','rotZ']] for o in b['ContainedObjects']}
 declaration='local POS=JSON.decode('+json.dumps(json.dumps(pos,separators=(',',':')))+')\n'
 b['LuaScript'],n=re.subn(r'local POS=JSON.decode\(("(?:\\.|[^"\\])*")\)\n',lambda m:declaration,b['LuaScript'],count=1);assert n==1
 specs=json.loads((ROOT/'mission-specifications.json').read_text())
 path=ROOT/f"{specs[i//2]['slug']}-{i%2+1}.json";single=json.loads(path.read_text());single['ObjectStates']=copy.deepcopy(b['ContainedObjects']);path.write_text(json.dumps(single,separators=(',',':')))
(ROOT/'Lobo-ITS18-Revised-Library.json').write_text(json.dumps(data,separators=(',',':')))
(ROOT/'unity-rotation-validation.json').write_text(json.dumps(dict(setups_checked=40,unity_order='Z-X-Y',all_object_rotations_verified=True,table_surfaces_horizontal=True,surfaces=records),indent=2))
print('Unity yaw corrected on all 40 maps; horizontal surfaces checked:',len(records))
