import json,hashlib,time,urllib.request,urllib.error,concurrent.futures,io
from pathlib import Path
from PIL import Image
ROOT=Path(__file__).parent
urls=json.loads((ROOT/'asset-urls.json').read_text());cache=ROOT/'asset-cache';cache.mkdir(exist_ok=True)
def inspect(u):
 result={'url':u,'fields':urls[u]};p=cache/hashlib.sha256(u.encode()).hexdigest()
 try:
  req=urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0'})
  with urllib.request.urlopen(req,timeout=15) as r:
   head=r.read(4096);contenttype=r.headers.get('Content-Type','');result.update(status=r.status,content_type=contenttype,final_url=r.url)
   isimage=any(x in head[:16] for x in [b'\x89PNG',b'\xff\xd8\xff',b'GIF8',b'RIFF',b'BM'])
   if isimage:
    raw=head+r.read(32*1024*1024);im=Image.open(io.BytesIO(raw));im.verify();p.write_bytes(raw);result['kind']='image'
   elif head.startswith((b'UnityFS',b'UnityRaw',b'UnityWeb')):
    result['kind']='unity_bundle'
   elif b'v ' in head or b'Wavefront' in head or b'OBJ' in head or b'Blender' in head:
    result['kind']='mesh'
   else:
    result['kind']='unknown';result['sample']=head[:100].decode('utf-8',errors='replace')
   result['ok']=result['kind']!='unknown'
 except Exception as e:result.update(ok=False,error=str(e))
 return result
results=[];start=time.time()
with concurrent.futures.ThreadPoolExecutor(max_workers=20) as ex:
 for f in concurrent.futures.as_completed([ex.submit(inspect,u) for u in urls]):
  r=f.result();results.append(r)
  if len(results)%40==0:print(json.dumps({'checked':len(results),'total':len(urls),'failed':sum(not x['ok'] for x in results),'elapsed_seconds':round(time.time()-start)}),flush=True)
  (ROOT/'asset-audit.json').write_text(json.dumps(results,indent=2))
print(json.dumps({'complete':len(results),'failed':sum(not x['ok'] for x in results)}),flush=True)
