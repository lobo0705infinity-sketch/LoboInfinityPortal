import ast,json,copy,pathlib
ROOT=pathlib.Path(__file__).parent
tree=ast.parse((ROOT/'repair_maps.py').read_text());outer=next(n for n in tree.body if isinstance(n,ast.For) and isinstance(n.target,ast.Tuple));ns={};exec(compile(ast.Module(body=tree.body[:tree.body.index(outer)],type_ignores=[]),'helpers','exec'),ns)
out=ROOT/'updated-maps';report=json.loads((out/'change-log.json').read_text());review=json.loads((out/'Lobo-ITS18-Revised-Library.json').read_text());bags=[o for o in review['ObjectStates'] if o['Name']=='Bag'];counts={}
for i,e in enumerate(report):
 slot=counts.get(e['slug'],0)+1;counts[e['slug']]=slot
 if e['remaining_terrain_reservation_collisions']==0:continue
 path=out/(e['slug']+'-'+str(slot)+'.json');single=json.loads(path.read_text());original=copy.deepcopy(single['ObjectStates'])
 m=copy.deepcopy(next(m for m in ns['specs'] if m['slug']==e['slug']));m['objectives']=e['objectives']
 objective_names={o['name'] for o in e['objectives']}|set(m['extras'])
 fixed=[o for o in single['ObjectStates'] if o['Nickname'].startswith('Objective Room') or o['Nickname'] in objective_names or o['Transform']['posX']>25]
 fixed_ids={o['GUID'] for o in fixed}
 terrain=[o for o in single['ObjectStates'] if o['GUID'] not in fixed_ids]
 groups,extras=ns['groups_for'](terrain,e['surface']);res=ns['geometry_reservations'](m);log=[]
 ns['clear_reserved'](groups,res,log,repack=True)
 left=sum(g['shape'].intersection(res).area>.001 for g in groups)
 # A repack is accepted only when every group found a legal location, no
 # objective reservations are occupied, and all scenery remains on-board.
 good=not any(c['action']=='UNRESOLVED collision' for c in log) and left==0
 print(e['mission'],e['terrain'],'repack accepted',good,'moves',len(log),flush=True)
 if not good:continue
 single['ObjectStates']=[o for g in groups for o in g['objects']]+extras+fixed
 path.write_text(json.dumps(single,separators=(',',':')))
 b=bags[i];b['ContainedObjects']=single['ObjectStates'];lines=ns['lines_for'](m,e['surface']);b['LuaScript']=ns['loader'](b['ContainedObjects'],lines,b['Nickname'])
 e['changes']=[c for c in e['changes'] if c['action']!='UNRESOLVED collision']+log;e['remaining_terrain_reservation_collisions']=0;e['global_repack']=True
(out/'change-log.json').write_text(json.dumps(report,indent=2));(out/'Lobo-ITS18-Revised-Library.json').write_text(json.dumps(review,separators=(',',':')))
