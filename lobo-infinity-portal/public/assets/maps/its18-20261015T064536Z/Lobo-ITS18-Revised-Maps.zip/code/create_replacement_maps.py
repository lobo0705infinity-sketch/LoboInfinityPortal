"""Create two new urban arrangements using measured existing scenery assets."""
import ast,json,copy,pathlib,math,collections
import numpy as np
from shapely.geometry import box,Point
from shapely import affinity
ROOT=pathlib.Path(__file__).parent
tree=ast.parse((ROOT/'repair_maps.py').read_text());outer=next(n for n in tree.body if isinstance(n,ast.For) and isinstance(n.target,ast.Tuple));ns={};exec(compile(ast.Module(body=tree.body[:tree.body.index(outer)],type_ignores=[]),'helpers','exec'),ns)
out=ROOT/'updated-maps';review=json.loads((out/'Lobo-ITS18-Revised-Library.json').read_text());report=json.loads((out/'change-log.json').read_text());bags=[o for o in review['ObjectStates'] if o['Name']=='Bag']
def shifted(group,x,z,angle=0,scale=1,surface=1.1):
 objs=copy.deepcopy(group['objects']);sh=group['shape'];cx,cz=sh.centroid.x,sh.centroid.y;bottom=group['lo'];a=math.radians(angle);c,s=math.cos(a),math.sin(a)
 for o in objs:
  ns['clean'](o);t=o['Transform'];px,pz=t['posX']-cx,t['posZ']-cz
  t['posX']=x+scale*(c*px+s*pz);t['posZ']=z+scale*(-s*px+c*pz);t['posY']=surface+scale*(t['posY']-bottom)
  t['rotY']=(t['rotY']+angle)%360
  for k in ['scaleX','scaleY','scaleZ']:t[k]*=scale
 return objs
templates=[];seen=set()
for idx in [28,7,13,14,26,19,2,8]:
 b=copy.deepcopy(ns['bags'][idx]);ns['restore'](b)
 objects=[ns['strip_effects'](o) for o in b['ContainedObjects'] if not ns['oldobjective'](o) and not ns['unknownterrain'](o) and not ('panic room' in o.get('Nickname','').lower() or len(list(ns['walk'](o)))==19)]
 groups,_=ns['groups_for'](objects,1.1 if idx in [28,26,19,8] else 4.6)
 for g in groups:
  # Use complete buildings, including their roof accessories, as single groups.
  if g['shape'].area<12 or g['shape'].area>150 or g['hi']-g['lo']<2 or g['hi']-g['lo']>10:continue
  if any(o['Name']=='BlockSquare' for o in g['objects']):continue
  raw=next((o.get('CustomMesh',{}).get('MeshURL') or o.get('CustomAssetbundle',{}).get('AssetbundleURL') for o in g['objects'] if o.get('CustomMesh') or o.get('CustomAssetbundle')),None)
  if not raw or raw in seen:continue
  labels=' '.join((o.get('Nickname','')+' '+(ns['bounds'](o)[2] if ns['bounds'](o) else '')) for o in g['objects']).lower()
  if any(word in labels for word in ['tree','planter','palm','car -','wrecked car','pickle van']):continue
  seen.add(raw)
  # Normalize the source building orientation before selecting a footprint.
  primary=max(g['objects'],key=lambda o:ns['shape'](o).area if ns['shape'](o) else 0)
  rect=list(ns['shape'](primary).minimum_rotated_rectangle.exterior.coords)
  edge=max([(rect[i+1][0]-rect[i][0],rect[i+1][1]-rect[i][1]) for i in range(4)],key=lambda d:d[0]**2+d[1]**2)
  angle=math.degrees(math.atan2(edge[1],edge[0]))
  objs=shifted(g,0,0,angle);ps=[p for o in objs for p in ns['pieces'](o)];sh=ns['unary_union']([p['poly'] for p in ps]);w=sh.bounds[2]-sh.bounds[0];d=sh.bounds[3]-sh.bounds[1]
  if max(w,d)>14 or min(w,d)<3.5:continue
  templates.append(dict(objects=objs,shape=sh,lo=min(p['lo'][1] for p in ps),hi=max(p['hi'][1] for p in ps),source=idx,key=raw,width=w,depth=d))
print('Building templates',len(templates),flush=True)
original_floor=next(o for o in ns['bags'][7]['ContainedObjects'] if o['Name']=='Custom_Tile' and o['Transform']['scaleX']>=20)
all_source=ns['source']['ObjectStates']
def find_prop(pattern):
 for b in all_source:
  for o in b.get('ContainedObjects',[]):
   if ns['bounds'](o) and (pattern.lower() in o.get('Nickname','').lower() or pattern.lower() in ns['bounds'](o)[2].lower()):
    q=ns['flatclean'](o);q['Transform'].update(posX=0,posY=0,posZ=0,rotX=0,rotY=0,rotZ=0)
    ps=list(ns['pieces'](q));return dict(objects=[q],shape=ns['shape'](q),lo=min(p['lo'][1] for p in ps),hi=max(p['hi'][1] for p in ps),key=pattern)
props=[p for p in [find_prop('City Wrecked Car'),find_prop('City Car'),find_prop('Pickle Van'),find_prop('Tech Container'),find_prop('Shady Trees')] if p]
planter=find_prop('planter_1') or find_prop('planter_2')
patterns={
 'Meridian Blocks':[(-18,-18,8,8),(-4,-18,7,6),(15,-18,10,7),(-18,-4,7,8),(18,1,7,7),(-6.5,8,7,6),(5,-8,6,6),(-16,18,10,7),(0,19,7,6),(17,18,8,8)],
 'Switchback Quarter':[(-18,-18,8,8),(-3,-19,7,6),(15,-18,10,7),(-18,3,7,8),(-6,-8,6,6),(7,8,6,6),(18,-3,7,7),(-16,18,10,7),(0,18,7,6),(17,18,8,8)]}
new_reports=[]
for slug,slot,layout in [('last-launch',2,'Meridian Blocks'),('superiority',1,'Meridian Blocks'),('superiority',2,'Switchback Quarter')]:
 i=next(i for i,e in enumerate(report) if e['slug']==slug)+(slot-1);e=report[i];m=copy.deepcopy(next(m for m in ns['specs'] if m['slug']==slug));surface=1.1
 # Room and non-room versions share the street structure, with different central scenery.
 m['objectives']=copy.deepcopy(e['objectives']);reserved=ns['geometry_reservations'](m)
 if not m['room']:reserved=reserved.union(box(-2,-2,2,2))
 floor=ns['flatclean'](original_floor);floor['Nickname']=layout+' — 48 × 48 inch table';floor['Transform'].update(posX=0,posY=1,posZ=0,rotX=0,rotY=0,rotZ=0,scaleX=24,scaleY=1,scaleZ=24)
 objects=[floor];occupied=[];usage=collections.Counter();placements=[]
 slots=list(patterns[layout])
 if m['room']:slots=[(19,6,6,5) if p[0]==18 and p[1]==1 else p for p in slots]
 for n,(x,z,mw,md) in enumerate(slots):
  candidates=[]
  for ti,t in enumerate(templates):
   if usage[t['key']]>=2:continue
   for angle in [0,90]:
    w,d=(t['width'],t['depth']) if angle==0 else (t['depth'],t['width'])
    scale=min(1,mw/w,md/d)
    if scale<.75:continue
    # Prefer structures that fill the intended block without enlarging assets.
    score=(mw-w*scale)+(md-d*scale)+usage[t['key']]*4+(0 if t['source'] in ([28,7,26] if layout=='Meridian Blocks' else [13,14,19,2]) else 2)
    candidates.append((score,ti,angle,scale))
  placed=False
  for _,ti,angle,scale in sorted(candidates):
   t=templates[ti];objs=shifted(t,x,z,angle,scale);sh=ns['unary_union']([ns['shape'](o) for o in objs])
   if not box(-23.7,-23.7,23.7,23.7).covers(sh) or sh.intersects(reserved) or any(sh.distance(p)<.8 for p in occupied):continue
   objects+=objs;occupied.append(sh);usage[t['key']]+=1;placements.append(dict(role='building block',center=[x,z],template_source=t['source'],scale=scale,objects=[o['GUID'] for o in objs]));placed=True;break
  if not placed:placements.append(dict(role='unfilled planned building block',center=[x,z]))
 if m['room']:objects+=ns['room'](surface)
 else:
  # A central offset barrier interrupts the board-bisecting lane without making an objective room.
  p=props[3] if len(props)>3 else props[0]
  objs=shifted(p,.6,0,90,1,surface);sh=ns['unary_union']([ns['shape'](o) for o in objs])
  actual_reserved=ns['geometry_reservations'](m)
  if not sh.intersects(actual_reserved) and not any(sh.distance(q)<.8 for q in occupied):objects+=objs;occupied.append(sh)
 # Vehicles, trees and containers provide limited staging cover at street bends.
 scatter=[(-12,0,0),(11,0,90),(-10,-11,0),(10,11,90),(-10,11,0),(10,-11,90),(-21,10,0),(21,-10,0),(-10,-22,90),(10,22,90),(20,10,0),(-20,-10,0),(.5,12,0)]
 for n,(x,z,a) in enumerate(scatter):
  p=props[-1] if n>=10 else props[n%len(props)];objs=shifted(p,x,z,a,1,surface);sh=ns['unary_union']([ns['shape'](o) for o in objs])
  if not box(-23.7,-23.7,23.7,23.7).covers(sh) or sh.intersects(reserved) or any(sh.distance(q)<.9 for q in occupied):continue
  objects+=objs;occupied.append(sh);placements.append(dict(role='street scenery',kind=p['key'],center=[x,z],objects=[o['GUID'] for o in objs]))
 if planter:
  for x,z in [(-12,-3),(12,3),(-12,3),(12,-3)]:
   objs=shifted(planter,x,z,0,1,surface);sh=ns['unary_union']([ns['shape'](o) for o in objs])
   if sh.intersects(reserved) or any(sh.distance(q)<.8 for q in occupied):continue
   objects+=objs;occupied.append(sh);placements.append(dict(role='street scenery',kind='planter',center=[x,z],objects=[o['GUID'] for o in objs]))
 for obj in m['objectives']:objects.append(ns['token'](obj['name'],obj['x'],obj['z'],obj['diameter_mm'],surface))
 extras=['ID Token 1','ID Token 2','ID Token 3','ID Token 4'] if slug=='last-launch' else []
 for j,label in enumerate(extras):objects.append(ns['token'](label,29,-12+6*j,25,surface,'reserve'))
 path=out/(slug+'-'+str(slot)+'.json');single=json.loads(path.read_text());single['ObjectStates']=objects;single['SaveName']=m['name']+' — '+layout+' — New layout';lines=ns['lines_for'](m,surface);single['LuaScript']='local LINES=JSON.decode('+json.dumps(json.dumps(lines))+')\nfunction onLoad() Global.setVectorLines(LINES) end';single['Note']='New terrain arrangement. Actual TTS loading, collider, mission diagram and gameplay review remain required.';path.write_text(json.dumps(single,separators=(',',':')))
 b=bags[i];b['ContainedObjects']=objects;b['Nickname']='SET_ITS18 '+m['name']+' — '+layout+' — NEW LAYOUT';b['LuaScript']=ns['loader'](objects,lines,b['Nickname']);b['Description']=single['Note']
 e.update(terrain=layout,source_save=None,new_layout=True,global_repack=False,changes=[dict(action='replace conversion requiring extensive changes with a new terrain arrangement',replaced_terrain=e['terrain'])]+placements,surface=surface,remaining_terrain_reservation_collisions=0,engine_tested=False)
 new_reports.append(dict(mission=m['name'],slot=slot,layout=layout,placements=placements,buildings=sum(p['role']=='building block' for p in placements),unfilled=sum(p['role'].startswith('unfilled') for p in placements)))
 print(m['name'],layout,'building blocks',new_reports[-1]['buildings'],'unfilled',new_reports[-1]['unfilled'],flush=True)
(out/'new-layouts.json').write_text(json.dumps(new_reports,indent=2));(out/'change-log.json').write_text(json.dumps(report,indent=2));(out/'Lobo-ITS18-Revised-Library.json').write_text(json.dumps(review,separators=(',',':')))
