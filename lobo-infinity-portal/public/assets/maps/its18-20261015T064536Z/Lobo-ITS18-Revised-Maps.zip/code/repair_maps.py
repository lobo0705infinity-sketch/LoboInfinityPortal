"""Fit mission objectives to actual asset bounds; preserve a reviewable change log."""
import copy,math,collections,heapq
from map_geometry import *
from shapely.geometry import Point,LineString
from shapely import affinity
from shapely.prepared import prep
OUT=ROOT/'updated-maps';OUT.mkdir(exist_ok=True)
source=json.loads((ROOT/'draft-inspect/unpacked/Lobo-Infinity-Maps-43-Saves.json').read_text())
specs=json.loads((ROOT/'draft-inspect/unpacked/mission-specifications.json').read_text())
bags={int(re.search(r'\[(\d+)\]$',b['Nickname'])[1]):b for b in source['ObjectStates'] if b.get('Name')=='Bag'}
counter=0
def guid():
 global counter
 counter+=1;return hashlib.sha256(('lobo-repair-v2:'+str(counter)).encode()).hexdigest()[:6]
def clean(o):
 o['GUID']=guid();o['LuaScriptState']=''
 text=o.get('LuaScript','');p=text.find('--[[Object base code]]')
 if p>=0:
  end=text.find('--[[Spawning object]]',p);text=text[:p]+(text[end+len('--[[Spawning object]]'):] if end>=0 else '')
 o['LuaScript']=text.strip()
 for c in o.get('ChildObjects',[]):clean(c)
 for c in o.get('States',{}).values():clean(c)
 return o
def flatclean(o):
 o=clean(copy.deepcopy(o));o.pop('ChildObjects',None);o.pop('States',None);o['LuaScript']='';return o
def oldobjective(o):
 n=re.sub(r'\[[^\]]*\]','',o.get('Nickname','')).strip().lower()
 return bool(re.match(r'^(console(?:\s*-|$)|antenna$|tech[- ]coffin$|panoply$|data console$|f-13 turret$|cylinder = part of console|24" circle for corner dz|cryogenics$|mindwipe$|data breach$)',n)) or o.get('GUID')=='13d2c0' or 'infected' in n or 'regular order' in n or 'irregular order' in n or 'silhouette' in n
def unknownterrain(o):
 return [c for c in walk(o) if c['Name']=='Custom_Model' and bounds(c) is None]
def strip_effects(o):
 # Non-rendering particle emitters are optional, and unavailable adverts are not scenery.
 o.pop('States',None)
 o['ChildObjects']=[strip_effects(c) for c in o.get('ChildObjects',[]) if not (c['Name']=='Custom_Assetbundle' and bounds(c) is None) and not (c['Name']=='Custom_Model' and bounds(c) is None)]
 return o
def name(b):return re.sub(r' \[\d+\]$','',re.sub(r'^SET_.*? - ','',b['Nickname']))
base_token=next(o for o in bags[1]['ContainedObjects'] if o['GUID']=='7d09d4')
room_src=next(o for o in bags[1]['ContainedObjects'] if o['GUID']=='8db988')
panel_src=next(o for o in walk(room_src) if o['GUID']=='d1b685')
floor_src=next(o for o in walk(room_src) if o['GUID']=='16850c')
corner_src=next(o for o in walk(room_src) if o['GUID']=='dc5573')
def fit_asset(src,label,cx,cz,width,depth,height,bottom,rot=0):
 o=flatclean(src);o['Nickname']=label;o['Locked']=True
 t=o['Transform'];t.update(posX=0,posY=0,posZ=0,rotX=0,rotY=rot,rotZ=0,scaleX=1,scaleY=1,scaleZ=1)
 for _ in range(2):
  ps=list(pieces(o));lo=np.min([p['lo'] for p in ps],axis=0);hi=np.max([p['hi'] for p in ps],axis=0);d=hi-lo
  if rot%180==90:t['scaleX']*=depth/d[2];t['scaleZ']*=width/d[0]
  else:t['scaleX']*=width/d[0];t['scaleZ']*=depth/d[2]
  t['scaleY']*=height/d[1]
 ps=list(pieces(o));lo=np.min([p['lo'] for p in ps],axis=0);hi=np.max([p['hi'] for p in ps],axis=0)
 t['posX']=cx-(lo[0]+hi[0])/2;t['posZ']=cz-(lo[2]+hi[2])/2;t['posY']=bottom-lo[1]
 return o
def token(label,x,z,mm,surface,role='fixed'):
 o=flatclean(base_token);o['Nickname']=label;o['Description']=f'{mm:g} mm marker; '+('place during mission setup according to official rules.' if role=='reserve' else 'Objective footprint on the playing surface.')
 t=o['Transform'];t.update(posX=x,posY=surface+.025,posZ=z,rotX=0,rotY=0,rotZ=0,scaleX=mm/40,scaleY=.04,scaleZ=mm/40)
 o['Locked']=role=='fixed' and not any(w in label for w in ['Beacon','Prototype','Civilian'])
 o['ColorDiffuse']=dict(r=.15,g=.65,b=.95) if role=='fixed' else dict(r=.95,g=.55,b=.1)
 o['LuaScript']='local LABEL='+json.dumps(label)+'\nfunction noop() end\nfunction onLoad() self.createButton({click_function="noop",function_owner=self,label=LABEL,position={0,0.4,0},rotation={0,180,0},width=0,height=0,font_size=65,font_color={1,1,1}}) end'
 return o
def room(surface):
 # Four open central gateways; the scoring footprint remains exactly 8 x 8 inches.
 gate=55/25.4;seg=(8-gate)/2;offset=(8+gate)/4;h=3.5;th=.12;out=[]
 out.append(fit_asset(floor_src,'Objective Room — 8 × 8 inch scoring floor',0,0,8,8,.04,surface-.04))
 for side in [-1,1]:
  for sign in [-1,1]:
   out.append(fit_asset(panel_src,'Objective Room — infinite-height wall',sign*offset,side*4,seg,th,h,surface))
   out.append(fit_asset(panel_src,'Objective Room — infinite-height wall',side*4,sign*offset,th,seg,h,surface,90))
 for x,z in itertools.product([-4,4],repeat=2):
  # Small corner caps do not enlarge the scoring footprint or approach corridors.
  out.append(fit_asset(corner_src,'Objective Room — corner support',x,z,.28,.28,h,surface))
 for o in out:o['Description']='8 × 8 inch Zone of Operations. Walls count as infinitely high. Four central gateways start open and are Wide Gates. Gateway model width: 55 mm; confirm against your official token before tournament use.'
 return out
def polyline(points,color=(.9,.55,.1)):
 return dict(points=[[x,1.35,z] for x,z in points],color=list(color),thickness=.045)
def lines_for(m,surface):
 out=[polyline([(-24,-24),(24,-24),(24,24),(-24,24),(-24,-24)],(.6,.6,.6))]
 if m['deployment']=='diagonal':
  for cx,cz,start in [(24,24,180),(-24,-24,0)]:out.append(polyline([(cx+24*math.cos(math.radians(a)),cz+24*math.sin(math.radians(a))) for a in np.linspace(start,start+90,65)]))
 elif m['deployment']=='split':
  for z in [-12,-4,0,4,12]:out.append(polyline([(-24,z),(24,z)]))
 else:
  for z in [-24+m['depth'],24-m['depth']]:out.append(polyline([(-24,z),(24,z)]))
 if m['room']:out.append(polyline([(-4,-4),(4,-4),(4,4),(-4,4),(-4,-4)],(.1,.8,1)))
 if m['slug'] in ['b-pong','corporate-appropriation','critical-intervention','double-bind','neutralization']:
  for z in [-4,4]:out.append(polyline([(-24,z),(24,z)],(.8,.25,.3)))
 if m['slug']=='superiority':
  out.extend([polyline([(-24,0),(24,0)],(.5,.5,.85)),polyline([(0,-12),(0,12)],(.5,.5,.85))])
 if m['slug']=='double-bind' or m['slug']=='neutralization':
  for obj in m['objectives']:
   if 'antenna' in obj['name'].lower():out.append(polyline([(obj['x']+60/25.4*math.cos(a),obj['z']+60/25.4*math.sin(a)) for a in np.linspace(0,2*math.pi,97)],(.5,.4,.9)))
 if m['slug']=='battleground':
  # Scoring sectors are revealed after the game, so omit them from normal play.
  pass
 for line in out:
  for p in line['points']:p[1]=surface+.04
 return out
def groups_for(objects,surface):
 groups=[];extras=[]
 for o in objects:
  ps=list(pieces(o));sh=unary_union([p['poly'] for p in ps if p['hi'][1]>surface+.18]) if ps else None
  is_floor=ps and ((max(p['hi'][1] for p in ps)-min(p['lo'][1] for p in ps)<.65 and shape(o).area>8) or any(w in o.get('Nickname','').lower() for w in ['difficult terrain','unstable debris']))
  if is_floor:extras.append(o);continue
  if sh is None or sh.is_empty or sh.area<.005 or (sh.area>1400 and max(p['hi'][1] for p in ps)<surface+.7):extras.append(o);continue
  if o['Name']=='Notecard' or o['Name']=='Custom_Token':extras.append(o);continue
  groups.append(dict(objects=[o],shape=sh,lo=min(p['lo'][1] for p in ps),hi=max(p['hi'][1] for p in ps)))
 # Roof accessories travel with their supporting building.
 used=set()
 for i,g in enumerate(groups):
  if g['lo']<surface+.9:continue
  candidates=[(h['hi'],j,h) for j,h in enumerate(groups) if i!=j and j not in used and h['lo']<surface+.5 and abs(h['hi']-g['lo'])<1 and h['shape'].buffer(.3).covers(g['shape'].representative_point())]
  if candidates:
   _,j,h=max(candidates,key=lambda q:q[0]);h['objects']+=g['objects'];h['shape']=h['shape'].union(g['shape']);h['hi']=max(h['hi'],g['hi']);used.add(i)
 groups=[g for i,g in enumerate(groups) if i not in used]
 # A building may comprise separate wall, support and roof objects. Keep
 # substantially overlapping parts together so relocation cannot split it.
 merged=True
 while merged:
  merged=False
  for i,g in enumerate(groups):
   for j in range(i+1,len(groups)):
    h=groups[j];overlap=g['shape'].intersection(h['shape']).area
    if overlap>.2*min(g['shape'].area,h['shape'].area) and overlap>.02:
     g['objects']+=h['objects'];g['shape']=g['shape'].union(h['shape']);g['lo']=min(g['lo'],h['lo']);g['hi']=max(g['hi'],h['hi']);groups.pop(j);merged=True;break
   if merged:break
 for o in list(extras):
  ps=list(pieces(o));sh=shape(o)
  if not ps or not sh or sh.area>150 or min(p['lo'][1] for p in ps)<surface+1.2:continue
  options=[g for g in groups if g['shape'].covers(sh.representative_point()) and abs(g['hi']-min(p['lo'][1] for p in ps))<1]
  if options:
   g=min(options,key=lambda g:g['shape'].area);g['objects'].append(o);g['shape']=g['shape'].union(sh);g['hi']=max(g['hi'],max(p['hi'][1] for p in ps));extras.remove(o)
 return groups,extras
def move(g,dx,dz):
 g['shape']=affinity.translate(g['shape'],dx,dz)
 for o in g['objects']:o['Transform']['posX']+=dx;o['Transform']['posZ']+=dz
def clear_reserved(groups,reserved,log,repack=False):
 # Relocate only obstructing groups. Candidate positions preserve original orientation and scale.
 bad=list(groups) if repack else [g for g in groups if g['shape'].intersects(reserved)]
 stationary=[g['shape'] for g in groups if g not in bad]
 bad.sort(key=lambda g:g['shape'].area,reverse=True)
 board=box(-23.8,-23.8,23.8,23.8)
 for g in bad:
  obstacles=prep(unary_union(stationary).buffer(.03)) if stationary else None
  blocked=prep(reserved)
  found=False
  if board.covers(g['shape']) and not blocked.intersects(g['shape']) and not (obstacles and obstacles.intersects(g['shape'])):
   stationary.append(g['shape']);continue
  for r in np.arange(.5,18.1,.5):
   candidates=[]
   for dx in np.arange(-r,r+.01,.5):
    for dz in [-r,r]:candidates.append((dx,dz))
   for dz in np.arange(-r+.5,r,.5):
    for dx in [-r,r]:candidates.append((dx,dz))
   candidates.sort(key=lambda d:d[0]*d[0]+d[1]*d[1])
   for dx,dz in candidates:
    sh=affinity.translate(g['shape'],dx,dz)
    if not board.covers(sh) or blocked.intersects(sh) or (obstacles and obstacles.intersects(sh)):continue
    move(g,float(dx),float(dz));stationary.append(g['shape']);log.append(dict(action='relocate scenery group',guids=[o['GUID'] for o in g['objects']],dx=float(dx),dz=float(dz)));found=True;break
   if found:break
  if not found:
   # Never silently drop gameplay terrain to claim success.
   stationary.append(g['shape']);log.append(dict(action='UNRESOLVED collision',guids=[o['GUID'] for o in g['objects']]))
def geometry_reservations(m):
 areas=[]
 for o in m['objectives']:
  if m['room'] and (o['name']=='Data Console' or o['name']=='ID Checker' or 'Turret' in o['name']):continue
  areas.append(Point(o['x'],o['z']).buffer(o['diameter_mm']/50.8+20/25.4))
 if m['room']:
  areas.append(box(-4.3,-4.3,4.3,4.3))
  for x,z in [(0,5.5),(0,-5.5),(5.5,0),(-5.5,0)]:areas.append(box(x-1.6,z-1.6,x+1.6,z+1.6))
 return unary_union(areas)
def route_reservations(m,groups):
 # Find short walking routes from either deployment side to each objective, penalising occupied cells.
 size=93;step=.5;origin=-23
 occ=np.zeros((size,size),dtype=bool)
 for g in groups:
  p=g['shape'].buffer(.52);lo=p.bounds
  for ix in range(max(0,int((lo[0]-origin)/step)),min(size,int((lo[2]-origin)/step)+2)):
   for iz in range(max(0,int((lo[1]-origin)/step)),min(size,int((lo[3]-origin)/step)+2)):
    if p.covers(Point(origin+ix*step,origin+iz*step)):occ[ix,iz]=True
 def index(x,z):return (min(size-1,max(0,round((x-origin)/step))),min(size-1,max(0,round((z-origin)/step))))
 targets=[(o['x'],o['z']) for o in m['objectives'] if not (m['room'] and ('Turret' in o['name'] or o['name'] in ['Data Console','ID Checker']))]
 if m['room']:targets.extend([(0,-6),(0,6),(-6,0),(6,0)])
 starts=[(-17,-17),(17,17)] if m['deployment']=='diagonal' else [(-14,-18),(14,18)]
 paths=[]
 for sx,sz in starts:
  start=index(sx,sz);dist={start:0};prev={};q=[(0,start)]
  while q:
   d,a=heapq.heappop(q)
   if d!=dist[a]:continue
   for dx,dz in [(1,0),(-1,0),(0,1),(0,-1)]:
    b=(a[0]+dx,a[1]+dz)
    if not (0<=b[0]<size and 0<=b[1]<size):continue
    xx,zz=origin+b[0]*step,origin+b[1]*step
    if m['room'] and abs(xx)<4.5 and abs(zz)<4.5:continue
    cost=d+1+(90 if occ[b] else 0)
    if cost<dist.get(b,math.inf):dist[b]=cost;prev[b]=a;heapq.heappush(q,(cost,b))
  for x,z in targets:
   end=index(x,z)
   if end not in dist:continue
   path=[end]
   while path[-1]!=start:path.append(prev[path[-1]])
   if len(path)>1:paths.append(LineString([(origin+i*step,origin+j*step) for i,j in path]).buffer(.52,cap_style=2,join_style=2))
 return unary_union(paths)
def loader(objects,lines,label):
 ps={o['GUID']:[o['Transform'][k] for k in ['posX','posY','posZ','rotX','rotY','rotZ']] for o in objects}
 locks={o['GUID']:o.get('Locked',True) for o in objects}
 lua='local POS=JSON.decode('+json.dumps(json.dumps(ps,separators=(',',':')))+')\nlocal LOCKS=JSON.decode('+json.dumps(json.dumps(locks))+')\nlocal LINES=JSON.decode('+json.dumps(json.dumps(lines))+')\n'
 lua+='''function onLoad() self.createButton({click_function="loadMap",function_owner=self,label="LOAD MAP",position={0,.8,0},rotation={0,180,0},width=1700,height=420,font_size=230}) end
function loadMap(_,color)
 if color~="White" and color~="Black" then broadcastToColor("Load as White or Black.",color,{1,.7,.2});return end
 if Global.getVar("loboMapLoaded") then broadcastToColor("Reload this save before loading another map.",color,{1,.7,.2});return end
 Global.setVar("loboMapLoaded",true)
 Global.setVectorLines(LINES)
 for _,e in ipairs(self.getObjects()) do local p=POS[e.guid];if p then self.takeObject({guid=e.guid,position={p[1],p[2],p[3]},rotation={p[4],p[5],p[6]},smooth=false,callback_function=function(o) o.setLock(LOCKS[e.guid]~=false) end}) end end
 broadcastToAll("Map loaded. Check all assets rendered; complete player-placed mission components before deployment. This revision has not been tested inside TTS.",{1,.7,.2})
end
'''
 return lua
allbags=[];report=[]
reassign={('area-of-interest',4):3,('corporate-appropriation',24):19,('data-harvest',43):2,('double-bind',43):6}
for mi,original in enumerate(specs):
 m=copy.deepcopy(original)
 if m['slug']=='critical-intervention':
  r=40/50.8;m['objectives'][1].update(x=-4-r/math.sqrt(2),z=-4-r/math.sqrt(2));m['extras']+=['Data Pack']
  for o in m['objectives']:
   if 'Turret 1' in o['name']:o.update(x=-4+25/50.8,z=4-25/50.8)
   if 'Turret 2' in o['name']:o.update(x=4-25/50.8,z=-4+25/50.8)
 if m['slug']=='last-launch':m['extras']+=['ID Token 1','ID Token 2','ID Token 3','ID Token 4']
 if m['slug']=='data-harvest':m['extras']=[s.replace('Neutralization Area','Designated Zone') for s in m['extras']]
 for slot,oldidx in enumerate(m['source_saves']):
  idx=reassign.get((m['slug'],oldidx),oldidx);base=copy.deepcopy(bags[idx]);restore(base);log=[]
  if idx!=oldidx:log.append(dict(action='use alternative retained terrain due unavailable mesh assets',old_source=oldidx,new_source=idx))
  objects=[]
  # Apply a consistent quarter turn: Unity positive yaw maps (x,z) to (z,-x).
  for o in base['ContainedObjects']:
   if oldobjective(o):continue
   if m['room'] and (len(list(walk(o)))==19 or 'panic room' in o.get('Nickname','').lower()):log.append(dict(action='replace assembled objective room',original_guid=o['GUID']));continue
   if o['Name']=='Custom_Assetbundle' and bounds(o) is None:log.append(dict(action='omit optional particle emitter',name=o.get('Nickname','')));continue
   unknown=unknownterrain(o)
   if unknown:
    # Only missing neon advertisements remain after the four source substitutions.
    for c in unknown:log.append(dict(action='omit unavailable attached advertisement',original_guid=c['GUID'],name=c.get('Nickname','')))
    if bounds(o) is None and o['Name']=='Custom_Model':continue
   strip_effects(o);clean(o)
   t=o['Transform'];x,z=t['posX'],t['posZ']
   quarter=m['deployment']!='diagonal'
   if not quarter:
    circles=[p for src in base['ContainedObjects'] if 'Circle for Corner DZ' in src.get('Nickname','') for p in [src['Transform']]]
    quarter=not(circles and circles[0]['posX']*circles[0]['posZ']>0)
   if quarter:t.update(posX=z,posZ=-x,rotY=(t['rotY']+90)%360)
   objects.append(o)
  floors=[o for o in objects if o['Name']=='Custom_Tile' and o['Transform']['scaleX']>=20]
  surface=(min(o['Transform']['posY'] for o in floors)+.10) if floors else 1.1
  groups,extras=groups_for(objects,surface)
  reserved=geometry_reservations(m);clear_reserved(groups,reserved,log)
  # Keep this pass limited to measured objective and gate clearance. Route
  # accessibility is reported separately; a route heuristic must not wholesale
  # rearrange the source layout to clear an arbitrary deployment anchor.
  objects=[o for g in groups for o in g['objects']]+extras
  terrain_shapes=[g['shape'] for g in groups]
  if m['room']:objects+=room(surface)
  for o in m['objectives']:
   support=surface
   for floor in extras:
    ps=list(pieces(floor));sh=shape(floor)
    if ps and sh and sh.covers(Point(o['x'],o['z'])) and (max(p['hi'][1] for p in ps)-min(p['lo'][1] for p in ps)<.65 or any(w in floor.get('Nickname','').lower() for w in ['difficult terrain','unstable debris'])):
     support=max(support,float(max(p['hi'][1] for p in ps)))
   objects.append(token(o['name'],o['x'],o['z'],o['diameter_mm'],support))
  for ei,label in enumerate(m['extras']):
   mm=120 if any(w in label for w in ['Area','Zone']) else 25
   objects.append(token(label,29+(ei//8)*6,-21+(ei%8)*6,mm,surface,'reserve'))
  label=f"{m['name']} — {name(base)}"
  b=flatclean(base);b['Name']='Bag';b['Nickname']='SET_ITS18 '+label+' — REVISED';b['ContainedObjects']=objects
  b['Description']=f"{m['name']} / {name(base)}\n48 × 48 inches; 300 points.\nTerrain fitted to objective footprints and walking routes.\n{m['notes']}\nOfficial mission: {m['source_url']}\nGeometry revision: TTS engine and visual review still required."
  b['Transform'].update(posX=(-34-slot*6) if mi<10 else (34+slot*6),posY=2,posZ=-27+(mi%10)*6,rotX=0,rotY=0,rotZ=0,scaleX=1,scaleY=1,scaleZ=1);b['Locked']=True
  lines=lines_for(m,surface);b['LuaScript']=loader(objects,lines,label)
  # Ground-only reservations exclude generated room walls and the intended antenna contact.
  remaining=sum(g['shape'].intersection(reserved).area>.001 for g in groups)
  entry=dict(mission=m['name'],slug=m['slug'],terrain=name(base),source_save=idx,original_source_save=oldidx,changes=log,remaining_terrain_reservation_collisions=remaining,objectives=m['objectives'],surface=surface,engine_tested=False,room=m['room'],room_gate_width_mm=55 if m['room'] else None)
  report.append(entry);allbags.append(b)
  print(label,'moves',sum(x['action']=='relocate scenery group' for x in log),'unresolved',remaining,flush=True)
  # Checkpoint every map, including the full placement records before packaging.
  (OUT/'change-log.json').write_text(json.dumps(report,indent=2))
  single=copy.deepcopy(source);single['ObjectStates']=objects;single['SaveName']=label+' — Revised';single['LuaScript']='local LINES=JSON.decode('+json.dumps(json.dumps(lines))+')\nfunction onLoad() Global.setVectorLines(LINES) end';single['LuaScriptState']='';single['Note']=b['Description'];single['XmlUI']=''
  for o in single['ObjectStates']:o['LuaScriptState']=''
  (OUT/(m['slug']+'-'+str(slot+1)+'.json')).write_text(json.dumps(single,separators=(',',':')))
review=copy.deepcopy(source);review['ObjectStates']=[clean(copy.deepcopy(o)) for o in source['ObjectStates'] if o.get('Name')!='Bag']+allbags
review['SaveName']='Lobo ITS18 — 40 Revised Mission Setups';review['LuaScript']='function onLoad() Global.setVar("loboMapLoaded",false) end';review['LuaScriptState']='';review['XmlUI']='';review['Note']='Revised geometry. Not yet tested inside TTS. Reload before loading another bag. No publication authorized.'
(OUT/'Lobo-ITS18-Revised-Library.json').write_text(json.dumps(review,separators=(',',':')))
(OUT/'mission-specifications.json').write_text(json.dumps(specs,indent=2))
