import json,pathlib,html,math,collections,copy,ast
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as MPolygon,Circle,Rectangle
from map_geometry import *
ROOT=Path(__file__).parent;out=ROOT/'updated-maps';report=json.loads((out/'change-log.json').read_text());validation=json.loads((out/'validation.json').read_text())
images=out/'previews';images.mkdir(exist_ok=True)
def render(path,e,dest):
 s=json.loads(path.read_text());fig,ax=plt.subplots(figsize=(6,6));ax.set_facecolor('#f2eee5')
 for o in s['ObjectStates']:
  if o['Description'].startswith(('25 mm marker','40 mm marker','120 mm marker')) or o.get('Nickname','') in {x['name'] for x in e['objectives']}:continue
  sh=shape(o)
  if sh is None:continue
  ps=list(pieces(o));lo=min(p['lo'][1] for p in ps);hi=max(p['hi'][1] for p in ps)
  if sh.area>1400 or o['Name']=='Notecard' or o['Name']=='Custom_Token':continue
  if 'scoring floor' in o['Nickname']:color='#cfe9f1'
  elif o['Nickname'].startswith('Objective Room'):color='#28697c'
  elif hi-lo<.65 and sh.area>8:color='#d9d4c9'
  else:color='#828b87'
  if 'Shady Trees' in o['Nickname']:color='#71865c'
  for p in sh.geoms if hasattr(sh,'geoms') else [sh]:
   if p.geom_type=='Polygon':ax.add_patch(MPolygon(list(p.exterior.coords),closed=True,facecolor=color,edgecolor='#48544f',linewidth=.45,alpha=.9))
 for n,o in enumerate(e['objectives'],1):
  ax.add_patch(Circle((o['x'],o['z']),o['diameter_mm']/50.8,facecolor='#efb147',edgecolor='#784c0c',linewidth=.9,zorder=8));ax.text(o['x'],o['z'],str(n),ha='center',va='center',fontsize=7,zorder=9)
 if e['slug'] in ['area-of-interest','outbreak','provisioning','the-dig']:
  for x,z,a in [(24,24,180),(-24,-24,0)]:
   angles=np.radians(np.linspace(a,a+90,80));ax.plot(x+24*np.cos(angles),z+24*np.sin(angles),color='#a65b42',ls='--',lw=.8)
 else:
  depth=16 if e['slug'] in ['b-pong','cutthroat','uplink-center'] else 12
  for z in [-24+depth,24-depth]:ax.axhline(z,color='#a65b42',ls='--',lw=.8)
  if e['slug']=='crossing-lines':
   for z in [-4,0,4]:ax.axhline(z,color='#a65b42',ls='--',lw=.8)
 ax.add_patch(Rectangle((-24,-24),48,48,fill=False,edgecolor='#283d39',linewidth=1.2));ax.set(xlim=(-24.6,24.6),ylim=(-24.6,24.6),aspect='equal',xticks=[-24,-12,0,12,24],yticks=[-24,-12,0,12,24]);ax.tick_params(labelsize=7);ax.set_title(e['mission']+'\n'+e['terrain'],loc='left',fontsize=11,fontweight='bold');ax.set_xlabel('Inches from table centre · footprint diagram, not a TTS render',fontsize=7)
 fig.tight_layout();fig.savefig(dest,dpi=140);plt.close(fig)
sections=[];counts={}
for e in report:
 slot=counts.get(e['slug'],0)+1;counts[e['slug']]=slot;filename=e['slug']+'-'+str(slot)
 render(out/(filename+'.json'),e,images/(filename+'.png'))
 objectives='; '.join(f"{i}. {o['name']} ({o['x']:.2f}, {o['z']:.2f})" for i,o in enumerate(e['objectives'],1)) or 'No fixed objectives.'
 moves=sum(c.get('action')=='relocate scenery group' for c in e['changes'])
 sections.append(f'<article><h2>{html.escape(e["mission"])} · {slot}</h2><h3>{html.escape(e["terrain"])}</h3><img src="previews/{filename}.png"><p>{html.escape(objectives)}</p><p>{"New terrain arrangement" if e.get("new_layout") else str(moves)+" scenery groups relocated"}. Clearance flags: {e["remaining_terrain_reservation_collisions"]}.</p><a href="{filename}.json">Standalone TTS save</a></article>')
body='''<!doctype html><meta charset="utf-8"><title>Lobo ITS18 — Geometry Revision Review</title><style>body{margin:0;background:#f5f2e9;color:#243d38;font:16px system-ui}header,main{max-width:1300px;margin:auto;padding:32px}h1{font-size:40px}.notice{background:#fff0d5;border-left:5px solid #c18a2c;padding:20px;line-height:1.6}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(420px,1fr));gap:24px}article{background:white;padding:20px;border:1px solid #d8dcd4;border-radius:8px}h2{margin:0}h3{font-weight:400;margin-top:6px}img{width:100%}p{font-size:14px;line-height:1.5}a{color:#236c78}</style><header><h1>Lobo ITS18 · revised terrain and mission setups</h1><p>40 setups · 20 missions · 15 terrain layout names · two new urban arrangements</p><div class="notice"><b>This is a geometry revision, not a play-approved release.</b> Marker footprints, model placements, room floors and loader scripts have been checked outside TTS. All 40 setups have zero flagged scenery conflicts within the modelled objective/gate clearance areas. This does not establish actual asset scale, collider behaviour, route access, deployment safety, sightline balance, rooftop counterplay, or ladder usability. Room openings are modelled at 55 mm and require comparison with the official Wide Gate token. No Workshop or portal publication occurred.</div><p>Original 43-save library unchanged. The change log records substitutions and scenery moves. Source modelling transforms and convex footprints are approximations that require an in-game check.</p></header><main><div class="grid">'''+''.join(sections)+'</div></main>'
(out/'Review.html').write_text(body)
print('Rendered',len(sections),'footprint diagrams')
