import json,hashlib,re,itertools
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation
from shapely.geometry import MultiPoint,box
from shapely.ops import unary_union
ROOT=Path(__file__).parent
BOUNDS=json.loads((ROOT/'geometry-cache/bounds.json').read_text())
def matrix(t):
 m=np.eye(4);m[:3,:3]=Rotation.from_euler('zxy',[t.get('rot'+k,0) for k in 'ZXY'],degrees=True).as_matrix()@np.diag([t.get('scale'+k,1) for k in 'XYZ']);m[:3,3]=[t.get('pos'+k,0) for k in 'XYZ'];return m
def walk(o):
 yield o
 for c in o.get('ChildObjects',[]):yield from walk(c)
def bounds(o):
 u=o.get('CustomMesh',{}).get('MeshURL') or o.get('CustomAssetbundle',{}).get('AssetbundleURL','')
 b=BOUNDS.get(hashlib.sha256(u.encode()).hexdigest(),{})
 if 'lo' in b:return b['lo'],b['hi'],b.get('name','')
 if o['Name']=='BlockSquare':return [-.5]*3,[.5]*3,'native cube'
 if o['Name']=='Custom_Tile':return [-1,-.1,-1],[1,.1,1],'tile estimate'
 return None
def pieces(o,parent=None):
 m=matrix(o['Transform']);m=parent@m if parent is not None else m
 b=bounds(o)
 if b:
  u=o.get('CustomMesh',{}).get('MeshURL') or o.get('CustomAssetbundle',{}).get('AssetbundleURL','');data=BOUNDS.get(hashlib.sha256(u.encode()).hexdigest(),{})
  if 'hull' in data:v=np.array([[x,y,z] for x,z in data['hull'] for y in [b[0][1],b[1][1]]])
  else:v=np.array(list(itertools.product(*zip(b[0],b[1]))))
  v=(m@np.c_[v,np.ones(len(v))].T).T[:,:3]
  yield dict(guid=o['GUID'],poly=MultiPoint(v[:,[0,2]]).convex_hull,lo=v.min(axis=0),hi=v.max(axis=0),name=b[2])
 for c in o.get('ChildObjects',[]):yield from pieces(c,m)
def shape(o):
 p=list(pieces(o))
 return unary_union([x['poly'] for x in p]) if p else None
def positions(b):return {g:list(map(float,v.split(','))) for g,v in re.findall(r'^--([0-9a-f]{6}),([+\-\d.Ee,]+)',b['LuaScript'],re.M)}
def restore(b):
 ps=positions(b)
 for o in b['ContainedObjects']:
  if o['GUID'] in ps:
   p=ps[o['GUID']]
   for i,k in enumerate(['posX','posY','posZ','rotX','rotY','rotZ']):o['Transform'][k]=p[i]
 return b
