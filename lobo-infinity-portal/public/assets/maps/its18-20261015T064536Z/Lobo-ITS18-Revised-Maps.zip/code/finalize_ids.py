"""Assign globally unique IDs and synchronize review bags with standalone saves."""
import json,re,pathlib
ROOT=pathlib.Path(__file__).parent;out=ROOT/'updated-maps'
s=json.loads((out/'Lobo-ITS18-Revised-Library.json').read_text());r=json.loads((out/'change-log.json').read_text());new=json.loads((out/'new-layouts.json').read_text());counter=0x100000
def walk(o):
 yield o
 for key in ['ChildObjects','ContainedObjects']:
  for c in o.get(key,[]):yield from walk(c)
 for c in o.get('States',{}).values():yield from walk(c)
def rekey(o):
 global counter
 mapping={}
 for c in walk(o):
  old=c['GUID'];counter+=1;c['GUID']=format(counter,'06x');mapping[old]=c['GUID']
 for c in walk(o):
  c['LuaScript']=re.sub(r'\b[0-9a-f]{6}\b',lambda m:mapping.get(m[0],m[0]),c.get('LuaScript',''))
 return mapping
counts={};bi=0
for o in s['ObjectStates']:
 mp=rekey(o)
 if o['Name']!='Bag':continue
 e=r[bi];bi+=1;slot=counts.get(e['slug'],0)+1;counts[e['slug']]=slot
 p=out/(e['slug']+'-'+str(slot)+'.json');single=json.loads(p.read_text());single['ObjectStates']=o['ContainedObjects'];p.write_text(json.dumps(single,separators=(',',':')))
 for c in e['changes']:
  for key in ['objects','guids']:
   if key in c:c[key]=[mp.get(g,g) for g in c[key]]
 for nr in new:
  if nr['mission']==e['mission'] and nr['slot']==slot:
   for c in nr['placements']:
    if 'objects' in c:c['objects']=[mp.get(g,g) for g in c['objects']]
(out/'Lobo-ITS18-Revised-Library.json').write_text(json.dumps(s,separators=(',',':')));(out/'change-log.json').write_text(json.dumps(r,indent=2));(out/'new-layouts.json').write_text(json.dumps(new,indent=2))
print('Unique IDs assigned:',counter-0x100000)
