"""Try retained layouts until each mission has two different geometrically clear choices."""
import ast,copy,json,pathlib
ROOT=pathlib.Path(__file__).parent
tree=ast.parse((ROOT/'repair_maps.py').read_text())
outer=next(n for n in tree.body if isinstance(n,ast.For) and isinstance(n.target,ast.Tuple))
cut=tree.body.index(outer)
ns={};exec(compile(ast.Module(body=tree.body[:cut],type_ignores=[]),'repair_maps.py','exec'),ns)
inner=next(n for n in outer.body if isinstance(n,ast.For))
prelude=compile(ast.Module(body=outer.body[:outer.body.index(inner)],type_ignores=[]),'mission-prelude','exec')
trial=compile(ast.Module(body=inner.body,type_ignores=[]),'layout-fitting','exec')
last=compile(ast.Module(body=tree.body[cut+1:],type_ignores=[]),'package-library','exec')
choices=[7,14,13,6,8,25,46,28,1,26,19,3,20,2,10,44,47,37]
selected=[]
for mi,original in enumerate(ns['specs']):
 ns.update(mi=mi,original=original);exec(prelude,ns)
 used=set()
 for slot,oldidx in enumerate(ns['m']['source_saves']):
  ns.update(slot=slot,oldidx=oldidx)
  initial=ns['reassign'].get((ns['m']['slug'],oldidx),oldidx)
  candidates=[initial]+[i for i in choices if i!=initial]
  best=None;bestscore=10**9
  for idx in candidates:
   terrain=ns['name'](ns['bags'][idx])
   if terrain in used:continue
   ns['reassign'][(ns['m']['slug'],oldidx)]=idx
   before=len(ns['report']);exec(trial,ns)
   score=ns['entry']['remaining_terrain_reservation_collisions']
   single_path=ns['OUT']/(ns['m']['slug']+'-'+str(slot+1)+'.json')
   if score<bestscore:
    bestscore=score;best=(copy.deepcopy(ns['b']),copy.deepcopy(ns['entry']),single_path.read_bytes(),idx)
   if score==0:break
   ns['report']=ns['report'][:before];ns['allbags']=ns['allbags'][:before]
  # Replace the trial result with the selected conversion, even when all tried
  # layouts fail. The failure remains explicitly recorded.
  ns['report']=ns['report'][:mi*2+slot];ns['allbags']=ns['allbags'][:mi*2+slot]
  b,entry,data,idx=best
  if idx!=oldidx:
   entry['changes']=[x for x in entry['changes'] if 'alternative retained terrain' not in x['action']]
   entry['changes'].insert(0,dict(action='substitute retained layout for mission clearance or available geometry',old_source=oldidx,new_source=idx))
  ns['report'].append(entry);ns['allbags'].append(b);single_path.write_bytes(data)
  used.add(entry['terrain']);selected.append(dict(mission=entry['mission'],slot=slot+1,source=idx,remaining=bestscore))
  (ns['OUT']/'change-log.json').write_text(json.dumps(ns['report'],indent=2))
  (ns['OUT']/'selected-layouts.json').write_text(json.dumps(selected,indent=2))
  print('SELECTED',entry['mission'],slot+1,entry['terrain'],'remaining',bestscore,flush=True)
exec(last,ns)
