import json,re,copy
from pathlib import Path
ROOT=Path(__file__).parent/'unpacked'
data=json.loads((ROOT/'Lobo-ITS18-Revised-Library.json').read_text());specs=json.loads((ROOT/'mission-specifications.json').read_text());report=[]
for i,b in enumerate(o for o in data['ObjectStates'] if o['Name']=='Bag'):
 changed=0;fixed=[]
 for o in b['ContainedObjects']:
  desc=o.get('Description','')
  mobile=desc.startswith('Physical ') or 'mm marker' in desc
  if not mobile:
   if not o.get('Locked'):changed+=1
   o['Locked']=True
  if o.get('Locked'):
   old=o.get('LuaScript','')
   if '-- Immediate static lock' not in old:
    o['LuaScript']=old+'\n-- Immediate static lock: preserve scenery before physics can resolve stacked colliders.\nlocal originalOnLoad=onLoad\nfunction onLoad(saved)\n self.setLock(true)\n if originalOnLoad then originalOnLoad(saved) end\nend\n'
   fixed.append(o['GUID'])
 locks={o['GUID']:o.get('Locked',True) for o in b['ContainedObjects']}
 decl='local LOCKS=JSON.decode('+json.dumps(json.dumps(locks,separators=(',',':')))+')\n'
 b['LuaScript'],n=re.subn(r'local LOCKS=JSON.decode\(("(?:\\.|[^"\\])*")\)\n',lambda m:decl,b['LuaScript'],count=1);assert n==1
 path=ROOT/f"{specs[i//2]['slug']}-{i%2+1}.json";s=json.loads(path.read_text());s['ObjectStates']=copy.deepcopy(b['ContainedObjects']);path.write_text(json.dumps(s,separators=(',',':')))
 report.append(dict(bag=b['Nickname'],scenery_newly_locked=changed,immediate_lock_objects=len(fixed),dustline='Dustline Outpost' in b['Nickname']))
(ROOT/'Lobo-ITS18-Revised-Library.json').write_text(json.dumps(data,separators=(',',':')))
(ROOT/'scenery-lock-validation.json').write_text(json.dumps(dict(setups_checked=40,changes=report,in_tts_physics_tested=False),indent=2))
print('Locked scenery across all 40 setups:',sum(r['scenery_newly_locked'] for r in report),'new static locks.')
print('Dustline:',[(r['bag'],r['scenery_newly_locked']) for r in report if r['dustline']])
