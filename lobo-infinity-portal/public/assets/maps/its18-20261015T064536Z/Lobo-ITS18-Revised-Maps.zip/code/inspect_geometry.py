import json,pathlib,concurrent.futures,itertools
import numpy as np
from scipy.spatial.transform import Rotation
import UnityPy
from UnityPy.helpers.MeshHelper import MeshHandler
from scipy.spatial import ConvexHull
ROOT=pathlib.Path(__file__).parent
def corners(lo,hi):return np.array(list(itertools.product(*zip(lo,hi))))
def extract(p):
 try:
  if p.suffix=='.obj':
   v=np.array([list(map(float,l.split()[1:4])) for l in p.read_text(errors='ignore').splitlines() if l.startswith('v ')])
   if len(v)==0:raise ValueError('No vertices')
   hull=ConvexHull(v[:,[0,2]])
   return p.stem,dict(lo=v.min(axis=0).tolist(),hi=v.max(axis=0).tolist(),name='mesh',hull=v[hull.vertices][:,[0,2]].tolist())
  e=UnityPy.load(str(p));trees={};mesh_readers={}
  for o in e.objects:
   if o.type.name in ['Mesh','Transform','MeshFilter','GameObject','MeshRenderer','BoxCollider','MeshCollider','AssetBundle']:
    try:
     trees[o.path_id]=(o.type.name,o.read_typetree())
     if o.type.name=='Mesh':mesh_readers[o.path_id]=o
    except Exception:pass
  transforms={d['m_GameObject']['m_PathID']:i for i,(t,d) in trees.items() if t=='Transform'}
  rendered={d['m_GameObject']['m_PathID'] for t,d in trees.values() if t=='MeshRenderer' and d.get('m_Enabled',True)}
  def matrix(i,seen=()):
   if i in seen:raise ValueError('cycle')
   d=trees[i][1];q=d['m_LocalRotation'];r=Rotation.from_quat([q[k] for k in 'xyzw']).as_matrix()
   s=d['m_LocalScale'];pos=d['m_LocalPosition'];m=np.eye(4);m[:3,:3]=r@np.diag([s[k] for k in 'xyz']);m[:3,3]=[pos[k] for k in 'xyz']
   parent=d['m_Father']['m_PathID']
   # Ignore the prefab's editor location; its authored scale and orientation
   # remain part of the loaded asset underneath TTS's object transform.
   if parent in trees:return matrix(parent,seen+(i,))@m
   m[:3,3]=0
   return m
  points=[];name='bundle'
  for i,(t,d) in trees.items():
   if t=='AssetBundle':name=d.get('m_Name','bundle')
   if t!='MeshFilter':continue
   if d['m_GameObject']['m_PathID'] not in rendered:continue
   mesh=trees.get(d['m_Mesh']['m_PathID'])
   if not mesh:continue
   md=mesh[1];a=md.get('m_LocalAABB')
   if not a:continue
   c=np.array([a['m_Center'][k] for k in 'xyz']);h=np.array([a['m_Extent'][k] for k in 'xyz'])
   tr=transforms.get(d['m_GameObject']['m_PathID'])
   if tr is None:continue
   mh=MeshHandler(mesh_readers[d['m_Mesh']['m_PathID']].read());mh.process();v=np.asarray(mh.m_Vertices)
   v=(matrix(tr)@np.c_[v,np.ones(len(v))].T).T[:,:3];points.extend(v)
  if not points:raise ValueError('No render bounds')
  v=np.array(points)
  hull=ConvexHull(v[:,[0,2]])
  return p.stem,dict(lo=v.min(axis=0).tolist(),hi=v.max(axis=0).tolist(),name=name,hull=v[hull.vertices][:,[0,2]].tolist())
 except Exception as ex:return p.stem,dict(error=str(ex))
if __name__=='__main__':
 paths=list((ROOT/'geometry-cache').glob('*.obj'))+list((ROOT/'geometry-cache').glob('*.bundle'))
 with concurrent.futures.ProcessPoolExecutor(max_workers=8) as ex:out=dict(ex.map(extract,paths))
 (ROOT/'geometry-cache/bounds.json').write_text(json.dumps(out,indent=2))
 print('Bounds extracted:',sum('lo' in x for x in out.values()),'/',len(out))
 print('Errors',[(k,v) for k,v in out.items() if 'error' in v][:15])
