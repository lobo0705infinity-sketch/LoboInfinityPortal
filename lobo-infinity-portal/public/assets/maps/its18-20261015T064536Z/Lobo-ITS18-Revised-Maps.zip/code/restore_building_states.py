import json,re,copy,collections,sys,warnings
from pathlib import Path
from scipy.spatial.transform import Rotation as R
ROOT=Path(__file__).parent/'unpacked'
data=json.loads((ROOT/'Lobo-ITS18-Revised-Library.json').read_text())
source=json.loads((ROOT.parent.parent/'source/Lobo-Infinity-Maps-43-Saves.json').read_text())
specs=json.loads((ROOT/'mission-specifications.json').read_text());selected=json.loads((ROOT/'selected-layouts.json').read_text())
sourcebags={int(re.search(r'\[(\d+)\]$',b['Nickname'])[1]):b for b in source['ObjectStates'] if b['Name']=='Bag'}
def key(o):return (o['Name'],o.get('CustomMesh',{}).get('MeshURL',''),o.get('CustomAssetbundle',{}).get('AssetbundleURL',''))
def rot(t):return R.from_euler('zxy',[t['rot'+k] for k in 'ZXY'],degrees=True)
def source_index(bags):
 d=collections.defaultdict(list)
 for b in bags:
  for o in b.get('ContainedObjects',[]):
   if o.get('States'):d[key(o)].append(o)
 return d
allrefs=source_index(sourcebags.values());counter=0x600000;report=[]
def sanitize(o):
 global counter
 counter+=1;o['GUID']=f'{counter:06x}';o['LuaScript']='';o['LuaScriptState']='';o['XmlUI']=''
 o['Locked']=True
 if o.get('CustomImage',{}).get('ImageSecondaryURL','').endswith('077667514B9647A58E54408941578615A56F05A7/'):o['CustomImage']['ImageSecondaryURL']=o['CustomImage']['ImageURL']
 o['ChildObjects']=[c for c in o.get('ChildObjects',[]) if not (c['Name']=='Custom_Tile' and max(c['Transform']['scaleX'],c['Transform']['scaleZ'])<3)]
 for c in o.get('ChildObjects',[]):sanitize(c)
 for c in o.get('States',{}).values():sanitize(c)
 o['LuaScript']='function onLoad() self.setLock(true) end'
 return o
def decl(k,v):return 'local '+k+'=JSON.decode('+json.dumps(json.dumps(v,separators=(',',':')))+')\n'
for bi,b in enumerate(o for o in data['ObjectStates'] if o['Name']=='Bag'):
 refs=source_index([sourcebags[selected[bi]['source_save']]]) if selected[bi]['source_save'] else allrefs
 aliases={};restored=[]
 for o in b['ContainedObjects']:
  if o.get('Description','').startswith('Physical ') or o.get('Nickname','').startswith('Objective Room'):continue
  options=refs.get(key(o)) or allrefs.get(key(o))
  if not options:continue
  ref=max(options,key=lambda r:len(r['States']))
  o['States']=copy.deepcopy(ref['States'])
  for stateid,state in o['States'].items():
   original_t=copy.deepcopy(state['Transform']);sanitize(state)
   state['Transform']=copy.deepcopy(o['Transform'])
   for axis in 'XYZ':state['Transform']['scale'+axis]=original_t['scale'+axis]*o['Transform']['scale'+axis]/ref['Transform']['scale'+axis]
   composed=rot(o['Transform'])*rot(ref['Transform']).inv()*rot(original_t)
   with warnings.catch_warnings():warnings.simplefilter('ignore');angles=composed.as_euler('zxy',degrees=True)
   for axis,value in zip('ZXY',angles):state['Transform']['rot'+axis]=float(value)
   aliases[state['GUID']]=o['GUID']
  restored.append({'guid':o['GUID'],'nickname':o.get('Nickname',''),'states':list(o['States']),'source_guid':ref['GUID']})
 # Recognize alternate-state IDs both when retracting and when loading them again.
 lua=b['LuaScript'];lua=decl('ALIASES',aliases)+lua
 lua=lua.replace('local p=POS[e.guid]','local p=POS[e.guid] or POS[ALIASES[e.guid]]')
 lua=lua.replace('local id=e.guid\n   pending','local id=e.guid\n   pending')
 lua=lua.replace('local o=getObjectFromGUID(id)\n  if o then', 'local o=getObjectFromGUID(id)\n  if not o then\n   for alias,root in pairs(ALIASES) do if root==id then o=getObjectFromGUID(alias);if o then break end end end\n  end\n  if o then')
 lua=lua.replace('for id,_ in pairs(POS) do if getObjectFromGUID(id) then return false end end','for id,_ in pairs(POS) do if getObjectFromGUID(id) then return false end end\n  for alias,_ in pairs(ALIASES) do if getObjectFromGUID(alias) then return false end end')
 assert 'POS[ALIASES[e.guid]]' in lua and 'for alias,root in pairs(ALIASES)' in lua
 b['LuaScript']=lua
 singlepath=ROOT/f"{specs[bi//2]['slug']}-{bi%2+1}.json";single=json.loads(singlepath.read_text());single['ObjectStates']=copy.deepcopy(b['ContainedObjects']);singlepath.write_text(json.dumps(single,separators=(',',':')))
 report.append({'bag':b['Nickname'],'restored_objects':restored,'alternate_states':len(aliases)})
(ROOT/'Lobo-ITS18-Revised-Library.json').write_text(json.dumps(data,separators=(',',':')))
(ROOT/'building-state-validation.json').write_text(json.dumps({'objects_restored':sum(len(r['restored_objects']) for r in report),'alternate_states_restored':sum(r['alternate_states'] for r in report),'setups':report,'in_tts_tested':False},indent=2))
print('Restored',sum(len(r['restored_objects']) for r in report),'objects and',sum(r['alternate_states'] for r in report),'alternate states.')
for r in report:
 if 'NeoTerran Command' in r['bag']:print(r['bag'],len(r['restored_objects']),'objects;',r['alternate_states'],'states')
