import check_controls as test
import json,re
cycles=0
for b in test.data['ObjectStates']:
 if b['Name']!='Bag':continue
 ids=[o['GUID'] for o in b['ContainedObjects']]
 aliases=json.loads(json.loads(re.search(r'local ALIASES=JSON.decode\(("(?:\\.|[^"\\])*")\)',b['LuaScript'])[1]))
 for alias,root in aliases.items():
  env,inventory=test.lua.globals().newEnvironment(b['GUID'],test.table(ids))
  test.load(b['LuaScript'],env);env.onLoad('');env.loadMap(None,'White')
  obj=test.world[root];assert obj is not None
  test.world[root]=None;obj['guid']=alias;test.world[alias]=obj
  env.retractMap(None,'White')
  assert not test.lua.globals().VARS['loboMapLoaded']
  assert inventory[alias] and not inventory[root]
  assert len(list(test.world.items()))==1
  env.loadMap(None,'White');assert test.world[alias] is not None
  env.retractMap(None,'White');assert not test.lua.globals().VARS['loboMapLoaded']
  assert len(list(test.world.items()))==1
  cycles+=1
result={'alternate_state_retract_redeploy_cases':cycles,'passed':True,'real_tts_tested':False}
(test.root/'alternate-state-controls-validation.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))
