import json,re,copy
from pathlib import Path
from lupa import LuaRuntime
root=Path(__file__).parent/'unpacked'
data=json.loads((root/'Lobo-ITS18-Revised-Library.json').read_text())
lua=LuaRuntime(unpack_returned_tuples=True)
def table(v):
 if isinstance(v,dict):return lua.table_from({k:table(x) for k,x in v.items()})
 if isinstance(v,list):return lua.table_from([table(x) for x in v])
 return v
def plain(v):
 if hasattr(v,'items'):
  d={k:plain(x) for k,x in v.items()}
  if d and set(d)==set(range(1,len(d)+1)):return [d[i] for i in range(1,len(d)+1)]
  return d
 return v
lua.globals().JSON=lua.table_from(dict(decode=lambda s:table(json.loads(s)),encode=lambda v:json.dumps(plain(v))))
lua.execute('''
VARS={};WORLD={};LASTLINES={};BUTTONS={};TIMEOUT=false;FAILRETURN=false
Global={setVar=function(k,v) VARS[k]=v end,getVar=function(k) return VARS[k] end,
 setVectorLines=function(v) LASTLINES=v end,getVectorLines=function() return LASTLINES end}
Wait={condition=function(done,condition,seconds,timeout) if condition() then done() else TIMEOUT=true;timeout() end end}
function broadcastToColor(...) end
function broadcastToAll(...) end
function getObjectFromGUID(id) return WORLD[id] end
function newEnvironment(bagid,ids)
 local inventory={};for _,id in ipairs(ids) do inventory[id]=true end
 local env={};setmetatable(env,{__index=_G})
 env.self={getGUID=function() return bagid end,clearButtons=function() BUTTONS={} end,
 createButton=function(b) BUTTONS[b.click_function]=true end,
 getObjects=function() local r={};for id,_ in pairs(inventory) do table.insert(r,{guid=id}) end;return r end,
 takeObject=function(p)
  assert(inventory[p.guid]);inventory[p.guid]=nil
  local obj={guid=p.guid,position=p.position,rotation=p.rotation,locked=false}
  obj.setLock=function(v) obj.locked=v end
  WORLD[p.guid]=obj;p.callback_function(obj)
 end,
 putObject=function(obj)
  if FAILRETURN then return end
  assert(obj.locked==false);WORLD[obj.guid]=nil;inventory[obj.guid]=true
 end}
 return env,inventory
end
''')
world=lua.globals().WORLD
world['player-model']=lua.table_from(dict(locked=True))
load=lua.eval('function(src,env) setmetatable(env,{__index=_G});local f,e=load(src,"bag","t",env);assert(f,e);f() end')
allids=[];counts=[]
for i,bag in enumerate(o for o in data['ObjectStates'] if o['Name']=='Bag'):
 objects=bag['ContainedObjects'];ids=[o['GUID'] for o in objects]
 env,inventory=lua.globals().newEnvironment(bag['GUID'],table(ids))
 load(bag['LuaScript'],env);env.onLoad('')
 assert lua.globals().BUTTONS['retractMap']
 env.loadMap(None,'Red');assert not lua.globals().VARS['loboMapLoaded']
 env.loadMap(None,'White');assert lua.globals().VARS['loboMapOwner']==bag['GUID']
 assert sum(1 for _ in world.items())==len(ids)+1
 # A moved piece is still retrieved by identity; player-created pieces are ignored.
 world[ids[0]]['position']=table([99,99,99])
 env.loadMap(None,'White');assert sum(1 for _ in world.items())==len(ids)+1
 if i==0:
  saved=env.onSave();load(bag['LuaScript'],env);env.onLoad(saved)
  lua.globals().FAILRETURN=True;env.retractMap(None,'White')
  assert lua.globals().VARS['loboMapLoaded'];lua.globals().FAILRETURN=False
 env.retractMap(None,'White')
 assert not lua.globals().VARS['loboMapLoaded']
 assert sum(1 for _ in world.items())==1 and world['player-model']['locked']
 assert len(list(inventory.items()))==len(ids)
 env.loadMap(None,'Black');env.retractMap(None,'Black')
 assert not lua.globals().VARS['loboMapLoaded']
 # Standalone and bag copies must contain identical terrain and objectives.
 specs=json.loads((root/'mission-specifications.json').read_text())
 single=json.loads((root/f"{specs[i//2]['slug']}-{i%2+1}.json").read_text())
 assert objects==single['ObjectStates']
 def walk(o):
  yield o
  for k in ['ContainedObjects','ChildObjects']:
   for c in o.get(k,[]):yield from walk(c)
  for c in o.get('States',{}).values():yield from walk(c)
 for o in objects:
  for c in walk(o):
   allids.append(c['GUID']);assert 'obje.glitch.me' not in c.get('LuaScript','')
   if c.get('LuaScript'):load(c['LuaScript'],lua.table_from({'self':lua.table_from({'setVectorLines':lambda v:None})}))
 load(single['LuaScript'],lua.table())
 templates=[o for o in objects if o['Name']=='PlayerPawn']
 assert len(templates)==(2 if specs[i//2]['deployment']=='diagonal' else 0)
 counts.append(len(ids))
assert len(set(allids))==len(allids)
result=dict(bags_tested=40,deploy_retract_cycles=80,access_checks=True,moved_piece_retrieval=True,player_models_preserved=True,saved_state_restored=True,failed_retract_retry=True,standalone_bag_parity=True,unique_nested_ids=True,lua_syntax_checked=True,real_tts_tested=False)
(root/'controls-validation.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))
