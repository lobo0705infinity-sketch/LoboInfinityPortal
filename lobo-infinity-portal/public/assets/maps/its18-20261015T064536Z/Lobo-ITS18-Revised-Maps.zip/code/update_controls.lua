local active=false
local busy=false
local pending=0
local previousLines={}
local function allowed(color)
 if color=="White" or color=="Black" then return true end
 broadcastToColor("Load or retract as White or Black.",color,{1,.7,.2})
 return false
end
local function buttons()
 self.clearButtons()
 self.createButton({click_function="loadMap",function_owner=self,label="LOAD MAP",position={0,.8,-.45},rotation={0,180,0},width=1700,height=420,font_size=230})
 self.createButton({click_function="retractMap",function_owner=self,label="RETRACT MAP",position={0,.8,.45},rotation={0,180,0},width=1700,height=420,font_size=200})
end
function onLoad(saved)
 if saved and saved~="" then
  local ok,s=pcall(JSON.decode,saved)
  if ok and s then active=s.active==true;previousLines=s.previousLines or {} end
 end
 if active then Global.setVar("loboMapOwner",self.getGUID());Global.setVar("loboMapLoaded",true) end
 buttons()
end
function onSave() return JSON.encode({active=active,previousLines=previousLines}) end
function loadMap(_,color)
 if not allowed(color) or busy then return end
 if active or Global.getVar("loboMapLoaded") then
  broadcastToColor("Retract the deployed map using its bag first.",color,{1,.7,.2});return
 end
 active=true;busy=true;pending=0
 Global.setVar("loboMapOwner",self.getGUID());Global.setVar("loboMapLoaded",true)
 previousLines=Global.getVectorLines() or {}
 Global.setVectorLines(LINES)
 for _,e in ipairs(self.getObjects()) do
  local p=POS[e.guid]
  if p then
   local id=e.guid
   pending=pending+1
   self.takeObject({guid=id,position={p[1],p[2],p[3]},rotation={p[4],p[5],p[6]},smooth=false,
    callback_function=function(o)
     o.setLock(LOCKS[id]~=false);pending=pending-1
    end})
  end
 end
 Wait.condition(function() busy=false end,function() return pending==0 end,15,
  function() busy=false;broadcastToAll("Some map objects did not finish loading. Retract before retrying.",{1,.7,.2}) end)
end
function retractMap(_,color)
 if not allowed(color) or busy then return end
 if not active then broadcastToColor("This bag has no deployed map.",color,{1,.7,.2});return end
 if Global.getVar("loboMapOwner")~=self.getGUID() then return end
 busy=true
 for id,_ in pairs(POS) do
  local o=getObjectFromGUID(id)
  if o then o.setLock(false);self.putObject(o) end
 end
 Wait.condition(function()
  Global.setVectorLines(previousLines)
  Global.setVar("loboMapLoaded",false);Global.setVar("loboMapOwner",nil)
  active=false;busy=false;pending=0
  broadcastToAll("Map retracted. You can now load another map.",{.3,1,.5})
 end,function()
  for id,_ in pairs(POS) do if getObjectFromGUID(id) then return false end end
  return true
 end,15,function()
  busy=false
  broadcastToAll("Some map objects could not be returned. Click RETRACT MAP to retry.",{1,.7,.2})
 end)
end
