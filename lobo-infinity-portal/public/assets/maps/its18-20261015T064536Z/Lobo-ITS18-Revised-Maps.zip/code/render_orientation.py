import json,re,sys,html
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon,Circle,Rectangle
sys.path.insert(0,str(Path(__file__).parent/'unpacked/code'))
from map_geometry import pieces
ROOT=Path(__file__).parent/'unpacked'
spec=json.loads((ROOT/'mission-specifications.json').read_text())
selected=json.loads((ROOT/'selected-layouts.json').read_text())
collection=json.loads((ROOT/'Lobo-ITS18-Revised-Library.json').read_text())
sections=[]
for i,bag in enumerate(o for o in collection['ObjectStates'] if o['Name']=='Bag'):
 m=spec[i//2];slot=i%2+1;slug=m['slug']+'-'+str(slot)
 fig,ax=plt.subplots(figsize=(6,6));ax.set_facecolor('#f1f1ed')
 fixed={o['name'] for o in m['objectives']}
 for o in bag['ContainedObjects']:
  if o.get('Nickname') in fixed or o['Name'] in ['Notecard','PlayerPawn']:continue
  for p in pieces(o):
   if p['poly'].area>1400:continue
   if p['poly'].geom_type!='Polygon':continue
   points=[(z,x) for x,z in p['poly'].exterior.coords]
   ax.add_patch(Polygon(points,facecolor='#9aa7aa',edgecolor='#465658',lw=.4))
 lines=json.loads(json.loads(re.search(r'local LINES=JSON.decode\(("(?:\\.|[^"\\])*")\)',bag['LuaScript'])[1]))
 for line in lines:
  ax.plot([p[2] for p in line['points']],[p[0] for p in line['points']],color=line['color'],lw=1)
 if m['deployment']=='diagonal':
  import numpy as np
  for o in bag['ContainedObjects']:
   if o['Name']=='PlayerPawn':
    t=o['Transform'];angles=np.linspace(0,2*np.pi,129)
    ax.plot(t['posZ']+24*np.cos(angles),t['posX']+24*np.sin(angles),color='#d27934',lw=1)
 else:
  for y in [-23,23]:ax.text(0,y,'DEPLOYMENT ZONE',ha='center',va='center',fontsize=8,color='#b84b25')
 for n,o in enumerate(m['objectives'],1):
  ax.add_patch(Circle((o['z'],o['x']),o['diameter_mm']/50.8,facecolor='#ffc252',edgecolor='#885319',zorder=8))
  ax.text(o['z'],o['x'],str(n),ha='center',va='center',fontsize=7,zorder=9)
 ax.set(xlim=(-24.5,24.5),ylim=(-24.5,24.5),aspect='equal',xticks=[],yticks=[])
 ax.set_title(m['name']+' · '+str(slot)+'\n'+selected[i]['terrain'],loc='left',fontsize=11)
 ax.set_xlabel('Board orientation: top/bottom deployment edges · footprint diagram',fontsize=8)
 fig.tight_layout();fig.savefig(ROOT/'previews'/f'{slug}.png',dpi=120);plt.close(fig)
 sections.append('<article><h2>'+html.escape(m['name'])+' · '+str(slot)+'</h2><p>'+html.escape(selected[i]['terrain'])+'</p><img src="previews/'+slug+'.png"><p>'+html.escape('; '.join(f"{n}. {o['name']}" for n,o in enumerate(m['objectives'],1)) or 'No fixed objectives.')+'</p><a href="'+slug+'.json">Standalone save</a></article>')
(ROOT/'Review.html').write_text('<!doctype html><meta charset="utf-8"><title>Lobo ITS18 — Corrected Board Orientation</title><style>body{background:#f0f1ed;color:#233638;font:16px system-ui;margin:32px}main{display:grid;grid-template-columns:repeat(auto-fit,minmax(360px,1fr));gap:24px}article{background:white;padding:20px}img{width:100%}h2{font-size:20px}</style><h1>Lobo ITS18 — Corrected Board Orientation</h1><p>All 40 setups checked. Straight deployment zones use the top and bottom board edges in the supplied TTS view. Eight diagonal setups use opposing corner templates. Terrain and mission components turned together, preserving relative geometry.</p><p>All bags have LOAD MAP and RETRACT MAP controls. Physical consoles replace console discs. These are footprint diagrams; final in-TTS asset and play checks remain necessary. Historical placement logs use the earlier coordinate frame.</p><main>'+''.join(sections)+'</main>')
print('Updated all 40 review diagrams.')
