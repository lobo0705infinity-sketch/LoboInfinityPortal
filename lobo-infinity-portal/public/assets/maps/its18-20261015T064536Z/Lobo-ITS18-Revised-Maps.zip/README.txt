LOBO ITS18 — TERRAIN AND MISSION REVISIONS

40 setups for 20 missions, with two different terrain layout names per mission.
15 terrain layouts overall: 13 retained layouts and 2 new urban arrangements.

STATUS: GEOMETRY REVISION — NOT YET TESTED OR APPROVED INSIDE TTS.
All 40 have zero flagged scenery conflicts in the modelled objective/entrance clearance areas. This is not confirmation of actual colliders, asset loading, gameplay routes, deployment safety, or sightlines.

START HERE
1. Open Review.html for all forty footprint diagrams and assignments.
2. To load the complete collection, copy Lobo-ITS18-Revised-Library.json into your Tabletop Simulator Saves folder. On Windows this is usually Documents\My Games\Tabletop Simulator\Saves.
3. Open the save in TTS. Clear the central board and click LOAD MAP on ONE bag as White or Black. Click RETRACT MAP on that same bag to return its objects, then load another map.
4. Alternatively, import any mission-1.json or mission-2.json as a standalone save. These load the terrain directly.
5. Complete player-placed objectives and role-dependent setup using the current official mission rules. Critical Intervention defaults to the Defender in the south; reposition its Inhibitor Antenna if the Defender uses the other side.

NEW ARRANGEMENTS
Meridian Blocks: used for Last Launch 2 and Superiority 1.
Switchback Quarter: used for Superiority 2.
Each has ten building blocks plus street scenery. They replace conversions that needed extensive rearrangement. Their balance is not playtest-certified.

ROOMS
The four room setups have an 8 x 8 inch scoring floor, physical wall sections and four open entrances. Modelled entrance width is 55 mm; compare it with the official Wide Gate token before competitive use. Walls count as infinitely high for the relevant mission.

CHECKS COMPLETED
- 40 standalone saves plus a 40-bag review collection.
- Two different terrain layout names per mission.
- Objective marker diameters and removal of inherited attachments.
- Independent modelled objective/entrance clearance check on all 40 saves.
- Exact 8 x 8 inch room scoring floors and measured entrance widths.
- Globally unique nested object identifiers.
- Lua syntax and forty loader executions against a mocked TTS API.

STILL REQUIRED
- Load in real TTS and verify assets, textures, scale and colliders.
- Check every objective approach, elevated surface and player-placed template option.
- Check protected exits, hiding places, enfilade, cross-table fire lanes, rooftop counterplay and ladder endpoints against the agreed map benchmarks.
- Compare all mission setup diagrams with current official rules.
- Playtest the new arrangements and inspect every revised setup.

The original 43-save library has not been modified. Nothing was uploaded to Steam Workshop, the portal, or production.

FILES
change-log.json: actual selected layouts, moves and substitutions.
validation.json: automated checks and outstanding checks.
new-layouts.json: placement records for the two new terrain arrangements.
previews/: footprint diagrams, not TTS screenshots.
code/: scripts used for preparation and checking. They require the earlier source package, cached geometry and Python dependencies to reproduce the full build.

UPDATE: Physical 40 mm consoles replace console/terminal discs. All eight diagonal setups have two 24-inch-radius corner DZ templates. All forty collection bags now have LOAD MAP and RETRACT MAP buttons. Retraction targets only objects belonging to that bag, leaving player models alone. Moved map objects are returned too. Deleted objects cannot be recovered by retracting. Standalone saves still load terrain directly; use the collection for bag controls.

ORIENTATION CORRECTION: All forty complete setups rotated -90 degrees around table center, aligning straight deployment with the top/bottom board edges in the supplied TTS view. Terrain, fixed objectives, reserve items, room walls, deployment lines and corner-template anchors rotate together. Relative geometry is preserved. Earlier placement logs use the pre-correction frame; orientation-audit.json records the final frame.

UNITY ROTATION FIX: Supersedes the earlier XYZ rotation conversion. Original asset pitch and roll are preserved, and only Unity yaw is changed. Main table surfaces in all 40 setups checked horizontal using Unity Z-X-Y rotations. Controls retested for 80 deploy/retract cycles. Actual TTS verification remains pending.

LATEST UPDATE: All 158 objective pieces use physical models on their mission bases; only 18 area/zone templates remain flat. Critical Intervention slot 2 now uses newly generated Bastion Courtyard instead of Freight Terminal, with a clear 8-inch room and reserved gate approaches. Static scenery locks immediately on load; both Dustline setups repaired. All 40 bag controls retested. In-TTS physics and visual verification remain required.

LATEST REVIEW FIXES: Bastion has 18 building groups plus five added full-size staging containers. All four room floors have at least .12-inch separation above their main mats. Removed all Area of Interest / Designated / Stabilization zone pieces, Data-Harvesters and Infected, and non-deployment area outlines. Retained all 16 diagonal DZ templates. Removed 112 small decorative image tiles and repaired 24 broken mat underside references. Known confirmed missing assets removed. Broad link validation was limited by network restrictions; no zero-dialog or in-TTS guarantee is claimed.

BUILDING STATES RESTORED: 221 scenery objects have their source state variants restored, including 373 alternate states and their floor/roof attachments. Each NeoTerran Command setup has 9 restored multistate objects with 13 alternate states. Geometry placement and scale remain aligned with the current setup. Alternate states lock on load and are recognized by retract/redeploy controls. All 373 alternate-state retract/redeploy cases passed against the simulated TTS API; actual TTS confirmation remains necessary.
