@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Capture-Lobo-Maps.ps1" -MaxMaps 40
echo.
pause
