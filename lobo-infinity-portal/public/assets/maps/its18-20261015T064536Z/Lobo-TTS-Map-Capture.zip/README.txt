LOBO ITS18 AUTOMATIC MAP CAPTURE - CURRENT 40 SETUPS

1. Extract this ZIP into a NEW folder on your Windows TTS computer.
2. Double-click TEST FIRST MAP.cmd. Leave the command window running.
3. Open/restart TTS, start a single-player game, then use:
   Games > Save & Load > Lobo ITS18 Map Batch Capture - 40 setups
4. Set TTS to 1920 x 1080 or larger (at least 1280 x 720 client area).
   Hide the interface with F11, then keep TTS visible and in front.
5. It deploys the first revised setup, waits 20 seconds, takes the overhead
   and angled JPGs, and creates separate overhead and angled ZIPs.
6. Check those first two photos. Then run CAPTURE ALL MAPS.cmd, reload the
   SAME capture save, hide the UI, and leave TTS in front.

The full run loads all 40 current ITS18 mission setups in order and takes
80 pictures. Expect roughly 20-30 minutes plus asset download time.
The top/bottom deployment edges use a consistent camera orientation.
Only deployment markings are shown; no scoring-area zone overlays are added.
The objects, objective models, and alternate building states come from the
current revised Workshop package, verified against its October 15 update.

Photos and two ZIPs appear beside these scripts. Send BOTH ZIPs back here
for review and portal import. Files already use the portal's required names.
Nothing uploads automatically, and the Workshop item is not modified.

To stop: Ctrl+C in the command window. To resume: CONTINUE CAPTURE.cmd,
reload the capture save, hide the UI, and keep TTS in front. Complete pairs
from this exact revision are reused; old 47-map photos are never reused.

Keep other windows off TTS while screenshots run. If a custom asset import
error appears, stop and report it; check photos before sending the full batch.
The helper waits for TTS to have focus before capturing each view.
Only one capture helper/external editor can use localhost port 39998 at once.
If the save is missing, compare the printed installed-save path to TTS's
configured Mod Save Location. A separate capture save is installed; your
Workshop and ordinary saved games are preserved.

This update reuses the previous Windows PowerShell/.cmd capture workflow.
It has been statically checked here; the first-map test verifies it in TTS.
