﻿param(
    [ValidateRange(1,40)][int]$MaxMaps = 40,
    [ValidateRange(1,40)][int]$StartMap = 1,
    [ValidateRange(45,130)][int]$CameraDistance = 45,
    [switch]$AutoResume
)

$ErrorActionPreference = 'Stop'
$sourceSave = Join-Path $PSScriptRoot 'TS_Save_902818.json'
$mapIndex = Join-Path $PSScriptRoot 'maps.json'
$candidateFolders = @(
    (Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'My Games\Tabletop Simulator\Saves'),
    (Join-Path $env:USERPROFILE 'Documents\My Games\Tabletop Simulator\Saves')
) | Select-Object -Unique
$saveFolder = $candidateFolders |
    Where-Object { Test-Path -LiteralPath (Join-Path $_ 'TS_Save_902810.json') } |
    Select-Object -First 1
if (-not $saveFolder) {
    $saveFolder = $candidateFolders | Where-Object { Test-Path -LiteralPath $_ } |
        Select-Object -First 1
}
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$output = Join-Path $PSScriptRoot "Lobo Map Captures $stamp"

if (-not (Test-Path -LiteralPath $sourceSave)) { throw 'Batch save JSON is missing.' }
if (-not $saveFolder) {
    throw "TTS save folder not found. Check TTS's configured save location."
}

Add-Type -AssemblyName System.Drawing
$captureType = @'
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;

public static class LoboScreenshot {
    [StructLayout(LayoutKind.Sequential)] public struct Rect {
        public int Left, Top, Right, Bottom;
    }
    [StructLayout(LayoutKind.Sequential)] public struct Point {
        public int X, Y;
    }
    [DllImport("user32.dll")] static extern bool GetClientRect(IntPtr hWnd, out Rect rect);
    [DllImport("user32.dll")] static extern bool ClientToScreen(IntPtr hWnd, ref Point point);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
    [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int command);
    public static bool IsForeground(IntPtr window) {
        return GetForegroundWindow() == window;
    }

    public static void Save(IntPtr window, string file) {
        Rect rect;
        Point origin = new Point();
        if (!GetClientRect(window, out rect) || !ClientToScreen(window, ref origin))
            throw new Exception("Cannot find the TTS window's client area.");
        int width = rect.Right - rect.Left, height = rect.Bottom - rect.Top;
        if (width < 1280 || height < 720)
            throw new Exception("Use a TTS client area at least 1280 x 720 (1920 x 1080 preferred).");
        double scale = 1.0;
        int outWidth = Math.Max(1, (int)Math.Round(width * scale));
        int outHeight = Math.Max(1, (int)Math.Round(height * scale));
        using (Bitmap screen = new Bitmap(width, height))
        using (Graphics grab = Graphics.FromImage(screen)) {
            grab.CopyFromScreen(origin.X, origin.Y, 0, 0,
                new Size(width, height), CopyPixelOperation.SourceCopy);
            using (Bitmap scaled = new Bitmap(outWidth, outHeight))
            using (Graphics draw = Graphics.FromImage(scaled)) {
                draw.InterpolationMode = InterpolationMode.HighQualityBicubic;
                draw.DrawImage(screen, 0, 0, outWidth, outHeight);
                ImageCodecInfo jpeg = null;
                foreach (ImageCodecInfo codec in ImageCodecInfo.GetImageEncoders())
                    if (codec.MimeType == "image/jpeg") { jpeg = codec; break; }
                if (jpeg == null) throw new Exception("JPEG encoder is unavailable.");
                using (EncoderParameters settings = new EncoderParameters(1)) {
                    settings.Param[0] = new EncoderParameter(Encoder.Quality, 92L);
                    scaled.Save(file, jpeg, settings);
                }
            }
        }
    }
}
'@
Add-Type -TypeDefinition $captureType -ReferencedAssemblies @('System.Drawing.dll')

function Get-TTSWindow {
    $process = Get-Process | Where-Object {
        $_.MainWindowHandle -ne 0 -and
        ($_.ProcessName -eq 'Tabletop Simulator' -or $_.MainWindowTitle -like '*Tabletop Simulator*')
    } | Select-Object -First 1
    if (-not $process) { throw 'TTS window not found. Open TTS on this computer first.' }
    return $process.MainWindowHandle
}

function Wait-TTSForeground {
    $noticeAt = (Get-Date).AddSeconds(3)
    $notified = $false
    do {
        $window = Get-TTSWindow
        if ([LoboScreenshot]::IsIconic($window)) {
            [void][LoboScreenshot]::ShowWindow($window, 9)
        }
        [void][LoboScreenshot]::SetForegroundWindow($window)
        Start-Sleep -Milliseconds 400
        if ([LoboScreenshot]::IsForeground($window)) {
            Start-Sleep -Milliseconds 400
            if ([LoboScreenshot]::IsForeground($window)) { return $window }
        }
        if (-not $notified -and (Get-Date) -ge $noticeAt) {
            Write-Host 'Paused: click TTS to continue. Captured photos are safe.' -ForegroundColor Yellow
            $notified = $true
        }
    } while ($true)
}

function Send-TTSCommand([string]$command, [int]$index = 0, [string]$view = '') {
    $body = @{ messageID = 2; customMessage = @{
        lobo_capture = 'command'; command = $command; index = $index;
        view = $view; distance = $CameraDistance
    }} | ConvertTo-Json -Compress -Depth 5
    $bytes = [Text.Encoding]::UTF8.GetBytes($body)
    $client = [Net.Sockets.TcpClient]::new()
    try {
        $client.Connect([Net.IPAddress]::Loopback, 39999)
        $client.GetStream().Write($bytes, 0, $bytes.Length)
    } finally { $client.Dispose() }
}

function Read-TTSMessage($client) {
    try {
        $stream = $client.GetStream()
        $stream.ReadTimeout = 2500
        $buffer = New-Object byte[] 32768
        $memory = [IO.MemoryStream]::new()
        try {
            $read = $stream.Read($buffer, 0, $buffer.Length)
            if ($read -le 0) { return $null }
            $memory.Write($buffer, 0, $read)
            $raw = [Text.Encoding]::UTF8.GetString($memory.ToArray())
            # Object-created events are numerous; they need no response.
            if ($raw -notmatch '"messageID"\s*:\s*[34]') { return $null }
            for ($attempt = 0; $attempt -lt 20; $attempt++) {
                $raw = [Text.Encoding]::UTF8.GetString($memory.ToArray())
                try { return $raw | ConvertFrom-Json }
                catch {
                    Start-Sleep -Milliseconds 50
                    if ($stream.DataAvailable) {
                        $read = $stream.Read($buffer, 0, $buffer.Length)
                        if ($read -le 0) { break }
                        $memory.Write($buffer, 0, $read)
                    }
                }
            }
        } finally { $memory.Dispose() }
    } finally { $client.Dispose() }
    return $null
}

$filename = 'TS_Save_902818.json'
if (Test-Path -LiteralPath (Join-Path $saveFolder $filename)) {
    $match = $false
    $match = (Get-FileHash -LiteralPath $sourceSave -Algorithm SHA256).Hash -eq
             (Get-FileHash -LiteralPath (Join-Path $saveFolder $filename) -Algorithm SHA256).Hash
    if (-not $match) {
        $existingPath = Join-Path $saveFolder $filename
        try {
            $existingName = (Get-Content -LiteralPath $existingPath -Raw -Encoding UTF8 |
                ConvertFrom-Json).SaveName
        } catch { $existingName = $null }
        if ($existingName -ne 'Lobo ITS18 Map Batch Capture - 40 setups') {
            $filename = 900000..900999 | ForEach-Object { "TS_Save_$_.json" } |
                Where-Object { -not (Test-Path -LiteralPath (Join-Path $saveFolder $_)) } |
                Select-Object -First 1
            if (-not $filename) { throw 'No unused TTS save slot found.' }
        }
    }
}
$installedSave = Join-Path $saveFolder $filename
Copy-Item -LiteralPath $sourceSave -Destination $installedSave -Force
New-Item -ItemType Directory -Path $output | Out-Null
Copy-Item -LiteralPath $mapIndex -Destination (Join-Path $output 'maps.json')
Set-Content -LiteralPath (Join-Path $output 'capture-version.txt') -Value 'its18-20261015-v6' -Encoding ASCII

$maps = @(Get-Content -LiteralPath $mapIndex -Raw -Encoding UTF8 | ConvertFrom-Json)
$alreadyCaptured = @{}
if ($AutoResume) {
    $previousRuns = @(Get-ChildItem -LiteralPath $PSScriptRoot -Directory |
        Where-Object { $_.Name -like 'Lobo Map Captures *' -and $_.FullName -ne $output } |
        Sort-Object LastWriteTime -Descending)
    for ($i = 1; $i -le $maps.Count; $i++) {
        $slug = $maps[$i - 1].slug
        foreach ($folder in $previousRuns) {
            # Only reuse this exact ITS18 revision; never mix historical photos.
            $marker = Join-Path $folder.FullName 'capture-version.txt'
            if (-not (Test-Path -LiteralPath $marker) -or
                (Get-Content -LiteralPath $marker -Raw).Trim() -ne 'its18-20261015-v6') { continue }
            $overhead = Join-Path $folder.FullName "$slug-overhead.jpg"
            $angled = Join-Path $folder.FullName "$slug-angled.jpg"
            if ((Test-Path -LiteralPath $overhead) -and (Test-Path -LiteralPath $angled)) {
                Copy-Item -LiteralPath $overhead -Destination $output
                Copy-Item -LiteralPath $angled -Destination $output
                $alreadyCaptured[$i] = $true
                break
            }
        }
    }
    $nextMap = 1
    while ($nextMap -le $maps.Count -and $alreadyCaptured.ContainsKey($nextMap)) {
        $nextMap++
    }
    if ($nextMap -le $maps.Count) { $StartMap = $nextMap }
}

function Complete-Capture {
    param([int]$NewCount, [int]$ExpectedCount)
    Write-Host ''
    Write-Host "Captured $NewCount new map(s); $($alreadyCaptured.Count) reused." -ForegroundColor Green
    $overheads = @(Get-ChildItem -LiteralPath $output -Filter '*-overhead.jpg')
    $angles = @(Get-ChildItem -LiteralPath $output -Filter '*-angled.jpg')
    if ($overheads.Count -ne $ExpectedCount -or $angles.Count -ne $ExpectedCount) {
        throw "Image count mismatch: $($overheads.Count) overhead, $($angles.Count) angled; expected $ExpectedCount."
    }
    foreach ($view in @('overhead', 'angled')) {
        $archive = Join-Path $PSScriptRoot "Lobo Map Captures $stamp - $view.zip"
        $photos = @(Get-ChildItem -LiteralPath $output -Filter "*-$view.jpg" |
            Select-Object -ExpandProperty FullName)
        Compress-Archive -LiteralPath $photos -DestinationPath $archive
        Write-Host "Created: $archive"
    }
}

if ($AutoResume -and $alreadyCaptured.Count -eq $maps.Count) {
    Complete-Capture -NewCount 0 -ExpectedCount $maps.Count
    exit 0
}

$listener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback, 39998)
try {
    $listener.Start()
    Write-Host ''
    Write-Host 'Lobo map capture is ready.' -ForegroundColor Cyan
    Write-Host "Installed save: $installedSave"
    Write-Host 'Open TTS and start a single-player game. If TTS was already open,'
    Write-Host 'quit and reopen it first so the imported save appears.'
    Write-Host 'Then load: Games > Save & Load > Lobo ITS18 Map Batch Capture - 40 setups'
    Write-Host 'Keep TTS in front while capturing. If its interface is showing, press F11.'
    Write-Host "Output: $output"
    if ($AutoResume) {
        Write-Host "Found $($alreadyCaptured.Count) complete map(s) in earlier folders."
    }
    if ($StartMap -gt 1) {
        Write-Host "Starting directly at map $StartMap."
    }
    Write-Host ''

    $lastActivity = Get-Date
    $captured = 0
    $captureLimit = if ($AutoResume) { $maps.Count - $alreadyCaptured.Count } else {
        [Math]::Min($MaxMaps, (41 - $StartMap))
    }
    $started = $false
    $done = $false
    while ($true) {
        if (-not $listener.Pending()) {
            if (((Get-Date) - $lastActivity).TotalSeconds -gt 240 -and $started) {
                throw 'TTS stopped responding for four minutes. The images captured so far are intact.'
            }
            Start-Sleep -Milliseconds 100
            continue
        }
        $message = Read-TTSMessage ($listener.AcceptTcpClient())
        if (-not $message) { continue }
        if ($message.messageID -eq 3) {
            throw "TTS Lua error: $($message.error)"
        }
        if ($message.messageID -ne 4) { continue }
        $data = $message.customMessage
        if (-not $data -or -not $data.lobo_capture) { continue }
        $lastActivity = Get-Date
        switch ($data.lobo_capture) {
            'hello' {
                if (-not $started) {
                    $started = $true
                    Write-Host "TTS connected; deploying map $StartMap."
                    Send-TTSCommand 'start' $StartMap
                }
            }
            'loading' {
                Write-Host "Loading map $($data.index)/40: $($data.name) ..."
            }
            'map_ready' {
                Write-Host "Map $($data.index)/40: $($data.name) ($($data.objects) objects)"
                if ($alreadyCaptured.ContainsKey([int]$data.index)) {
                    Write-Host '  Skipping: both views already saved.'
                    Send-TTSCommand 'next' ([int]$data.index)
                } else {
                    Send-TTSCommand 'view' ([int]$data.index) 'overhead'
                }
            }
            'view_ready' {
                $window = Wait-TTSForeground
                $lastActivity = Get-Date
                $name = "$($data.slug)-$($data.view).jpg"
                [LoboScreenshot]::Save($window, (Join-Path $output $name))
                Write-Host "  Saved $name"
                if ($data.view -eq 'overhead') {
                    Send-TTSCommand 'view' ([int]$data.index) 'angled'
                } else {
                    $captured++
                    if ($captured -ge $captureLimit) { break }
                    Send-TTSCommand 'next' ([int]$data.index)
                }
            }
            'done' { $done = $true }
            'error' { throw "TTS: $($data.reason)" }
        }
        if ($captured -ge $captureLimit -or $done) { break }
    }

    Complete-Capture -NewCount $captured -ExpectedCount ($captured + $alreadyCaptured.Count)
} finally {
    $listener.Stop()
}
