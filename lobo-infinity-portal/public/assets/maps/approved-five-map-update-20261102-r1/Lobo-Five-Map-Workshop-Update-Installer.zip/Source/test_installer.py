from pathlib import Path
import json,tempfile,subprocess,hashlib,shutil
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'five-release';PS=Path('/tmp/redline-powershell/pwsh')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest().upper()
def manifest(package):return json.loads((package/'Install-Manifest.json').read_text())
def target(tts,e):
 prefix,name=e['path'].split('/');return tts/'Saves'/(''if prefix=='Files'else'Saved Objects')/name
def run(package,tts,ok=True):
 r=subprocess.run([str(PS),'-NoProfile','-NonInteractive','-File',str(package/'Install.ps1'),'-TtsRoot',str(tts)],capture_output=True,text=True,timeout=90)
 assert (r.returncode==0)==ok,r.stdout+r.stderr
 return r
with tempfile.TemporaryDirectory(prefix='lobo-four-map-')as tmp:
 T=Path(tmp);tts=T/"Jake's Custom TTS";(tts/'Saves').mkdir(parents=True);entries=manifest(OUT)
 run(OUT,tts);assert len(entries)==46
 assert all(sha(target(tts,e))==e['sha256']for e in entries)
 assert len(list((tts/'Saves/Saved Objects').glob('Lobos Top 40 *.json')))==10
 old={}
 for i,e in enumerate(entries):
  p=target(tts,e);p.write_bytes(('original-'+str(i)).encode());old[p.relative_to(tts/'Saves').as_posix()]=p.read_bytes()
 legacy=tts/'Saves/Saved Objects/1007ad.json';legacy.write_text(json.dumps(dict(ObjectStates=[dict(GUID='1007ad',Nickname='SET_ITS18 Cutthroat — Dustline Outpost')])));legacy.with_suffix('.png').write_bytes(b'old-preview');legacy_bytes=legacy.read_bytes()
 unrelated=tts/'Saves/Saved Objects/810241.json';unrelated.write_text(json.dumps(dict(ObjectStates=[dict(GUID='abcdef',Nickname='My personal map')])));unrelated_bytes=unrelated.read_bytes()
 kestrel=tts/'Saves/Saved Objects/Lobos Top 40 Kestrel Lunar Base - Data Harvest.json';kestrel.write_text(json.dumps(dict(ObjectStates=[dict(GUID='e1da22',Nickname="SET_Lobo's Top 40 Kestrel Lunar Base — Data Harvest")])));kestrel_bytes=kestrel.read_bytes()
 run(OUT,tts);assert all(sha(target(tts,e))==e['sha256']for e in entries);assert unrelated.read_bytes()==unrelated_bytes;assert not legacy.exists();assert not kestrel.exists()
 backup=max((tts/'Lobo Map Backups').iterdir(),key=lambda p:p.stat().st_mtime_ns)
 for rel,data in old.items():assert(backup/'Replaced'/rel).read_bytes()==data
 assert (backup/'Previous-GUID-Copies/Saved Objects/1007ad.json').read_bytes()==legacy_bytes
 assert (backup/'Retired-Top40-Copies/Saved Objects/Lobos Top 40 Kestrel Lunar Base - Data Harvest.json').read_bytes()==kestrel_bytes
 assert (tts/'Saves/Saved Objects/Kestrel Lunar Base - Data Harvest.json').exists()
 # A corrupt file and blocked target are rejected before any changes.
 package=T/'damaged';shutil.copytree(OUT,package);(package/entries[0]['path']).write_bytes(b'corrupt')
 run(package,tts,False);assert all(sha(target(tts,e))==e['sha256']for e in entries)
 blocked=T/'blocked';(blocked/'Saves'/entries[0]['path'].split('/')[-1]).mkdir(parents=True);run(OUT,blocked,False);assert not(blocked/'Lobo Map Backups').exists()
 # Mid-install failure restores every existing destination and leaves unrelated files.
 package=T/'fail-write';shutil.copytree(OUT,package);p=package/'Install.ps1';s=p.read_text(encoding='utf-8-sig');s=s.replace('Copy-Item -LiteralPath $item.Source -Destination $item.Destination -Force',"if ($written.Count -eq 3) { throw 'Injected write failure' }\n        Copy-Item -LiteralPath $item.Source -Destination $item.Destination -Force");p.write_text(s,encoding='utf-8-sig')
 before={target(tts,e):target(tts,e).read_bytes()for e in entries};run(package,tts,False);assert all(p.read_bytes()==b for p,b in before.items())
 # A failure after a retired old file was removed restores that old file too.
 package=T/'fail-retire';shutil.copytree(OUT,package);p=package/'Install.ps1';s=p.read_text(encoding='utf-8-sig').replace('Remove-Item -LiteralPath $oldFile',"Remove-Item -LiteralPath $oldFile\n                    throw 'Injected retirement failure'");p.write_text(s,encoding='utf-8-sig');legacy.write_bytes(legacy_bytes);run(package,tts,False);assert legacy.read_bytes()==legacy_bytes;assert all(p.read_bytes()==b for p,b in before.items())
 # Windows PowerShell 5.1 compatibility: manifest array is not nested by @().
 assert '$manifest = Get-Content'in(OUT/'Install.ps1').read_text();assert b'\r\n'in(OUT/'Install.cmd').read_bytes()
report=dict(status='passed',powerShellVersion=subprocess.check_output([str(PS),'-NoProfile','-Command','$PSVersionTable.PSVersion.ToString()'],text=True).strip(),installedFiles=46,namedBags=22,top40Bags=10,freshInstall=True,reinstallAndAllTargetBackups=True,legacyGUIDRetirement=True,unrelatedPersonalFilesPreserved=True,corruptPackageRejectedBeforeWrites=True,blockedTargetRejectedBeforeWrites=True,midWriteRollback=True,retirementRollback=True,nativeWindowsTested=False)
(OUT/'Source/installer-validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
