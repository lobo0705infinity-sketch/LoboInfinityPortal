from pathlib import Path
import json,copy,re,zipfile,hashlib,collections,struct,shutil
ROOT=Path(__file__).resolve().parent
BASE=ROOT/'baseline'; OUT=ROOT/'release'; OUT.mkdir(exist_ok=True)
REPO=ROOT.parent/'portal-batch-repo/lobo-infinity-portal'
REV='approved-four-map-update-20261102-r1'
PUBLIC=REPO/'public/assets/maps'/REV;PUBLIC.mkdir(parents=True,exist_ok=True)
def read(p):return json.loads(Path(p).read_text())
def write(p,d):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def walk(o):
 yield o
 for k in ['ContainedObjects','ChildObjects']:
  for q in o.get(k,[]):yield from walk(q)
 for q in o.get('States',{}).values():yield from walk(q)
def rewrite(v,fn):
 if isinstance(v,dict):return {fn(k):rewrite(q,fn)for k,q in v.items()}
 if isinstance(v,list):return [rewrite(q,fn)for q in v]
 return fn(v)if isinstance(v,str)else v
def zipjson(path,fragment=None):
 with zipfile.ZipFile(ROOT.parent/path)as z:
  n=next(n for n in z.namelist()if n.endswith('.json') and (fragment is None or fragment in n))
  return json.loads(z.read(n))
baseline=read(BASE/'Files/Lobo-Workshop-Current-Maps-and-Rules.json');collection=copy.deepcopy(baseline)
catalogue=read(BASE/'Source/catalogue.json');portal=read(REPO/'shared/lobo-workshop-current.json')
by={o['GUID']:o for o in collection['ObjectStates']}
configs=[
 dict(name='Redline Interchange',key='redline',mission='Cutthroat',round=3,slug='cutthroat-1',tag='LoboMap:RedlineInterchangeR3',path='upload/TS_Save_35.zip',source='TS_Save_35',theme='Urban / Railway'),
 dict(name='Ironveil Complex',key='ironveil',mission='Hardlock',round=7,slug='hardlock-1-satellite',tag='LoboMap8101d2',path='map-status-review/TS_Save_36.zip',source='TS_Save_36, approved current controls',theme='Urban / Industrial'),
 dict(name='Cairnfall Sanctuary',key='cairnfall',mission='Battleground',round=4,slug='battleground-1',tag=None,path='map-status-refreshed/Cairnfall-Sanctuary-Battleground-R2-Approved-Installer.zip',source='Approved TS_Save_37 layout with archive staircase fix',theme='Sanctuary / Autumn'),
 dict(name='Vesper Glassworks',key='vesper',mission='Neutralization',round=5,slug='neutralization-1-satellite',tag='LoboMap:VesperGlassworksR1',path='map-status-latest/Vesper-Glassworks-Neutralization-Approved-Save.zip',source='TS_Save_38',theme='Urban / Glassworks'),
]
used={o['GUID']for b in collection['ObjectStates']for o in walk(b)if o.get('GUID')};seq=0xbc0000
def fresh():
 global seq
 while f'{seq:06x}'in used:seq+=1
 s=f'{seq:06x}';used.add(s);seq+=1;return s
def clone(bag):
 ids={o['GUID']:fresh()for o in walk(bag)if o.get('GUID')}
 controller=next(o for o in bag['ContainedObjects']if 'local universalConfig='in o.get('LuaScript',''))
 cfg=json.loads(json.loads(re.search(r'^local universalConfig=JSON.decode\((.*)\)$',controller['LuaScript'],re.M)[1]))
 tags={t:t+'Top40'for t in cfg.get('tags',[])if t!='NoSave'}
 # Include every family ownership tag, including the controller-only tag.
 for o in bag['ContainedObjects']:
  for t in o.get('Tags',[]):
   if t.startswith('LoboMap') or any(t.startswith(s)for s in ['LoboIronveil','RedlineInterchange','Cairnfall','VesperGlassworks']):tags[t]=t+'Top40'
 pattern=re.compile(r'(?<![0-9a-fA-F])('+'|'.join(ids)+r')(?![0-9a-fA-F])')
 tagpattern=re.compile('|'.join(re.escape(t)for t in sorted(tags,key=len,reverse=True)))
 def fn(s):
  parts=re.split(r'(https?://[^\s\"\'<>\\]+)',s)
  for i in range(0,len(parts),2):
   parts[i]=pattern.sub(lambda m:ids[m[0]],parts[i])
   parts[i]=tagpattern.sub(lambda m:tags[m[0]],parts[i])
  return ''.join(parts)
 return rewrite(bag,fn),ids,tags
def manifest(roots):
 lines=[]
 for o in roots:
  for q in [o,*o.get('States',{}).values()]:
   t=q['Transform'];values=[t[k]for k in ['posX','posY','posZ','rotX','rotY','rotZ']]
   # TTS stores rotations in float32; exact representable angles avoid Stage waits.
   values[3:]=[struct.unpack('f',struct.pack('f',v))[0]for v in values[3:]]
   lines.append('--'+q['GUID']+','+','.join(format(v,'.17g')for v in values))
 return '\r\n'.join(lines)+'\r\n'
newindex=[];pairs=[];preservation=[]
for ix,c in enumerate(configs):
 oldrow=next(m for m in portal['maps']if m['slug']==c['slug']);old=by[oldrow['guid']]
 d=zipjson(c['path'],'/Map-Bags/'if c['key']=='cairnfall'else None)
 roots=copy.deepcopy(d['ObjectStates'][0]['ContainedObjects']if c['tag']is None else [o for o in d['ObjectStates']if c['tag']in o.get('Tags',[])])
 assert len(roots)>40
 removed=[]
 for o in [q for o in roots for q in walk(o)]:
  s=o.get('LuaScript','')
  if '--[[Object base code]]'in s:
   start=s.index('--[[Object base code]]');end=s.find('--[[Spawning object]]',start)
   assert end>=0,'Unexpected injected script terminator'
   clean=s[:start].rstrip()+s[end+len('--[[Spawning object]]'):]
   assert not clean.strip().endswith('-- User code here'), 'Unexpected payload shape'
   o['LuaScript']=clean.rstrip()+'\n';removed.append(o['GUID'])
 # Source layout is kept byte-for-byte at field level except the documented Lua suffix removal.
 bag=copy.deepcopy(old);bag['Nickname']='SET_ITS18 '+c['mission']+' — '+c['name']
 bag['Description']=c['name']+' | '+c['mission']+' | 48 × 48 inches. User-approved layout: '+c['source']+'.'
 bag['ContainedObjects']=roots;bag['LuaScript']=manifest(roots);bag['LuaScriptState']='';bag['XmlUI']=''
 for k in ['States','ChildObjects']:bag.pop(k,None)
 current=next(x for x in catalogue if x['guid']==bag['GUID']);current.update(title=c['name'],mission=c['mission'],source_name=bag['Nickname'],theme=c['theme'])
 collection['ObjectStates'][collection['ObjectStates'].index(old)]=bag;by[bag['GUID']]=bag
 event,ids,tags=clone(bag);label=f"Lobo's Top 40 Losers Round {c['round']} Map"
 event['Nickname']='SET_'+label;event['Description']=bag['Description']+' Top 40 Losers Round '+str(c['round'])+'.'
 event['Transform']=dict(posX=-39+(ix+6)%12*7,posY=1.125,posZ=-30.6,rotX=0,rotY=0,rotZ=0,scaleX=1,scaleY=1,scaleZ=1)
 collection['ObjectStates'].append(event)
 catalogue.append(dict(guid=event['GUID'],category='top40',title=c['name'],mission=c['mission'],home={k:event['Transform']['pos'+k.upper()]for k in ['x','y','z']},source_name=event['Nickname'],theme=c['theme']))
 pairs.append(dict(name=c['name'],mission=c['mission'],bracket='Losers',round=c['round'],general=bag['GUID'],event=event['GUID'],guidMap=ids,tagMap=tags,label=label))
 standalone={'SaveName':'','GameMode':'','Date':'','Table':'','Sky':'','Note':'','Rules':'','ObjectStates':[]}
 for b,kind,filename in [(bag,'general',c['name']+' - '+c['mission']),(event,'top40',f"Lobos Top 40 Losers Round {c['round']} Map")]:
  payload=copy.deepcopy(standalone);payload['ObjectStates']=[copy.deepcopy(b)];payload['ObjectStates'][0]['Transform']=dict(posX=0,posY=1,posZ=0,rotX=0,rotY=0,rotZ=0,scaleX=1,scaleY=1,scaleZ=1)
  write(OUT/'Saved-Objects'/(filename+'.json'),payload)
  newindex.append(dict(name=filename,guid=b['GUID'],kind=kind,map=c['name'],path='Saved-Objects/'+filename+'.json'))
  if kind=='general':write(PUBLIC/(c['slug']+'.json'),payload)
  else:write(PUBLIC/(f"Lobos-Top-40-Losers-Round-{c['round']}-Map.json"),payload)
 oldname=oldrow['name'];oldrow.update(name=c['name'],workshopName=bag['Nickname'][4:],workshopBagName=bag['Nickname'],objectCount=len(roots),layoutKey=2020+ix,previewKind='geometry',captureDate='2026-11-02',sourceOverhead=None,sourceAngled=None,overhead='/assets/maps/'+REV+'/'+c['key']+'-overhead.webp',angled='/assets/maps/'+REV+'/'+c['key']+'-angled.webp',diagram='/assets/maps/'+REV+'/'+c['key']+'-overhead.webp',download='/assets/maps/'+REV+'/'+c['slug']+'.json',sourceNote='User-approved '+c['source']+'. Exact terrain, transforms, scales and active building states preserved. Current controls retained. Matching Top 40 Losers Round '+str(c['round'])+'. Offline loading checks pass; native TTS playtesting is unverified.'+(' Unwanted self-propagating Lua suffix removed from release copy.'if removed else''))
 oldrow['labelAliases']=list(dict.fromkeys(oldrow.get('labelAliases',[])+[oldname,old['Nickname'],old['Nickname'][4:]]))
 preservation.append(dict(map=c['name'],source=c['path'],source_sha256=hashlib.sha256((ROOT.parent/c['path']).read_bytes()).hexdigest(),rootObjects=len(roots),injectedLuaSuffixesRemoved=len(removed),removedSuffixGUIDs=removed,approvedTransformsScalesModelsAndStatesPreserved=True,generalGUID=bag['GUID'],round=c['round'],oldName=oldname))
 # Stable general ID is retained, preserving saved-object slot replacement.
 c.update(guid=bag['GUID'],eventGUID=event['GUID'],rootCount=len(roots))
write(OUT/'Source/new-map-index.json',newindex);write(OUT/'Source/new-map-pairs.json',pairs)
write(OUT/'Source/approved-preservation.json',preservation);write(OUT/'Source/configs.json',configs)
for directory in ['Files','Saved-Objects','Source']:(OUT/directory).mkdir(exist_ok=True)
for row in read(BASE/'Source/saved-object-index.json'):
 shutil.copy2(BASE/row['path'],OUT/row['path']);shutil.copy2((BASE/row['path']).with_suffix('.png'),(OUT/row['path']).with_suffix('.png'))
shutil.copy2(BASE/'Files/Lobo-Workshop-Current-Maps-and-Rules.png',OUT/'Files/Lobo-Workshop-Current-Maps-and-Rules.png')
index=read(BASE/'Source/saved-object-index.json')+newindex
write(OUT/'Source/saved-object-index.json',index);write(OUT/'Source/map-pairs.json',read(BASE/'Source/map-pairs.json')+pairs);write(OUT/'Source/catalogue.json',catalogue)
def lua(v):
 if isinstance(v,dict):return '{'+','.join('['+json.dumps(k)+']='+lua(q)for k,q in v.items())+'}'
 if isinstance(v,list):return '{'+','.join(lua(q)for q in v)+'}'
 if isinstance(v,str):return json.dumps(v,ensure_ascii=False)
 if isinstance(v,bool):return str(v).lower()
 if v is None:return 'nil'
 return repr(v)
collection['LuaScript']=re.sub(r'^local ITEMS = .*$',lambda _: 'local ITEMS = '+lua(catalogue),collection['LuaScript'],count=1,flags=re.M)
collection['SaveName']="Lobo's Infinity Maps - Four Map Update R1"
write(OUT/'Files/Lobo-Workshop-Current-Maps-and-Rules.json',collection)
portal.update(updatedAt='2026-11-02',downloadRevision=REV,download='/assets/maps/'+REV+'/Lobo-ITS18-Drop-Zone-Maps.zip',installer='/assets/maps/'+REV+'/Lobo-Four-Map-Workshop-Update-Installer.zip')
write(REPO/'shared/lobo-workshop-current.json',portal)
print(json.dumps(preservation,indent=2));print('Catalogue counts',dict(collections.Counter(x['category']for x in catalogue)))
