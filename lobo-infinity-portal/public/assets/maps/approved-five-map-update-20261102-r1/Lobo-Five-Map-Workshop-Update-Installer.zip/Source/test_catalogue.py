from pathlib import Path
import json,re,collections,xml.etree.ElementTree as ET
from lupa import LuaRuntime
R=Path(__file__).resolve().parents[1]
c=json.load(open(R/'Files/Lobo-Workshop-Current-Maps-and-Rules.json'))
source=json.load(open(R/'Source/catalogue.json'));pairs=json.load(open(R/'Source/map-pairs.json'))
index=json.load(open(R/'Source/saved-object-index.json'))
by={o['GUID']:o for o in c['ObjectStates']}
xml=ET.fromstring('<root>'+c['XmlUI']+'</root>');xmlids={q.attrib['id']for q in xml.iter()if'id'in q.attrib}
L=LuaRuntime(unpack_returned_tuples=True);G=L.globals()
def table(v):
 if isinstance(v,dict):return L.table_from({k:table(q)for k,q in v.items()})
 if isinstance(v,list):return L.table_from([table(q)for q in v])
 return v
G.pyDecode=lambda s:table(json.loads(s))
G.pyXMLIds=table(list(xmlids))
G.pyData=table(c['ObjectStates'])
L.execute('''
attrs={};nodes={};objects={}
for _,id in ipairs(pyXMLIds)do nodes[id]=true end
UI={setAttribute=function(id,k,v) assert(nodes[id],'missing catalogue UI ID: '..id);attrs[id..':'..k]=v end}
for _,data in ipairs(pyData)do
 local o={type=data.Name,guid=data.GUID}
 o.getName=function()return data.Nickname or ''end
 o.getDescription=function()return data.Description or ''end
 o.getGUID=function()return data.GUID end
 o.getPosition=function()local t=data.Transform;return{x=t.posX,y=t.posY,z=t.posZ}end
 objects[data.GUID]=o
end
function getAllObjects()local t={};for _,o in pairs(objects)do t[#t+1]=o end;return t end
function getObjectFromGUID(g)return objects[g]end
Wait={frames=function(f,n)f()end}
Backgrounds={setCustomURL=function()end}
''')
returned=L.execute(c['LuaScript']+'\nreturn {items=function()return ITEMS end,rebuild=rebuildCatalogue,filter=filtered}')
G.onLoad()
assert G.attrs['loboCount:text'].startswith('10 results'),G.attrs['loboCount:text']
counts={}
for category,n in [('missions',40),('campaign',50),('top40',10),('all',100)]:
 G.loboCategory(None,category,None);actual=len(returned['filter']());assert actual==n,(category,actual,n);counts[category]=actual
G.loboCategory(None,'top40',None);G.loboSearch(None,'Frostline Relay',None);assert len(returned['filter']())==1
G.loboSearch(None,'',None);G.loboCategory(None,'missions',None);G.loboSearch(None,'Frostline Relay',None);assert len(returned['filter']())==1
G.loboSearch(None,'',None)

(R/'Source/catalogue-validation.json').write_text(json.dumps(dict(categoryCounts=counts,xmlValid=True,searchWorks=True),indent=2));print(counts)
