from pathlib import Path
import json,zipfile,hashlib,shutil
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'release';REPO=ROOT.parent/'portal-batch-repo/lobo-infinity-portal';PUBLIC=REPO/'public/assets/maps/approved-four-map-update-20261102-r1'
for name in ['build_batch.py','download_assets.py','render_approved.py','validate_release.py','prepare_installer.py','prepare_portal.py','test_installer.py','package_release.py']:
 shutil.copy2(ROOT/name,OUT/'Source'/name)
paths=sorted(f for f in OUT.rglob('*')if f.is_file()and f.name!='SHA256SUMS.txt'and '__pycache__'not in str(f)and not(f.parent.name=='Previews'and f.suffix=='.png'))
(OUT/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.relative_to(OUT).as_posix()+'\n'for f in paths))
destination=ROOT.parent/'output/Lobo-Four-Map-Workshop-Update-Installer.zip'
with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED,9)as z:
 for f in paths+[OUT/'SHA256SUMS.txt']:z.write(f,f.relative_to(OUT).as_posix())
with zipfile.ZipFile(destination)as z:
 assert z.testzip()is None
 for line in z.read('SHA256SUMS.txt').decode().splitlines():
  h,name=line.split('  ',1);assert hashlib.sha256(z.read(name)).hexdigest()==h,name
 for row in json.loads(z.read('Install-Manifest.json')):assert hashlib.sha256(z.read(row['path'])).hexdigest().upper()==row['sha256']
shutil.copy2(destination,PUBLIC/destination.name)
print(json.dumps(dict(archive=str(destination.resolve()),bytes=destination.stat().st_size,sha256=hashlib.sha256(destination.read_bytes()).hexdigest(),crcAndAllArchiveHashesVerified=True)))
