from pathlib import Path
import json,copy,re,zipfile,collections,hashlib
from lupa import LuaRuntime
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'release';BASE=ROOT/'baseline';REPO=ROOT.parent/'portal-batch-repo/lobo-infinity-portal'
def load(p):return json.loads(Path(p).read_text())
def walk(o):
 yield o
 for k in ['ContainedObjects','ChildObjects']:
  for q in o.get(k,[]):yield from walk(q)
 for q in o.get('States',{}).values():yield from walk(q)
def rewrite(v,fn):
 if isinstance(v,dict):return {fn(k):rewrite(q,fn)for k,q in v.items()}
 if isinstance(v,list):return [rewrite(q,fn)for q in v]
 return fn(v)if isinstance(v,str)else v
c=load(OUT/'Files/Lobo-Workshop-Current-Maps-and-Rules.json');by={o['GUID']:o for o in c['ObjectStates']};old=load(BASE/'Files/Lobo-Workshop-Current-Maps-and-Rules.json');configs=load(OUT/'Source/configs.json');newindex=load(OUT/'Source/new-map-index.json')
replaced={x['guid']for x in configs}
for o in old['ObjectStates']:
 if o['GUID']not in replaced:assert by[o['GUID']]==o,('Unrelated collection object changed',o['GUID'])
for key in old:
 if key not in ['LuaScript','ObjectStates','SaveName']:assert old[key]==c[key],('Unrelated collection field changed',key)
L=LuaRuntime(unpack_returned_tuples=True);compile=L.eval('function(s)local f,e=load(s);return f~=nil,e end');scripts=0
for row in newindex:
 b=by[row['guid']];stand=load(OUT/row['path'])['ObjectStates'][0]
 for key in ['Nickname','ContainedObjects','LuaScript','LuaScriptState']:assert stand[key]==b[key]
 records={l[2:8]:list(map(float,l[9:].split(',')))for l in b['LuaScript'].splitlines()}
 assert not re.search(r'(?<!\r)\n',b['LuaScript'])and b['LuaScript'].endswith('\r\n')
 assert len(records)==sum(1+len(o.get('States',{}))for o in b['ContainedObjects'])
 for o in b['ContainedObjects']:
  for q in [o,*o.get('States',{}).values()]:
   assert all(abs(a-q['Transform'][k])<.0005 for a,k in zip(records[q['GUID']],['posX','posY','posZ','rotX','rotY','rotZ']))
 for o in walk(b):
  s=o.get('LuaScript','')
  assert not any(t in s for t in ['--[[Object base code]]','obje.glitch.me','tcejbo gninwapS'])
  if s:
   ok,err=compile(s.replace('!=','~='));assert ok,(row['name'],o['GUID'],err);scripts+=1
for p in load(OUT/'Source/new-map-pairs.json'):
 a,b=by[p['general']],by[p['event']];ids={v:k for k,v in p['guidMap'].items()};tags={v:k for k,v in p['tagMap'].items()}
 pattern=re.compile(r'(?<![0-9a-fA-F])('+'|'.join(ids)+r')(?![0-9a-fA-F])');tagpattern=re.compile('|'.join(re.escape(t)for t in sorted(tags,key=len,reverse=True)))
 def undo(s):
  parts=re.split(r'(https?://[^\s\"\'<>\\]+)',s)
  for i in range(0,len(parts),2):parts[i]=tagpattern.sub(lambda m:tags[m[0]],pattern.sub(lambda m:ids[m[0]],parts[i]))
  return ''.join(parts)
 assert rewrite(b['ContainedObjects'],undo)==a['ContainedObjects'],(p['name'],'Top40 component parity')
 assert undo(b['LuaScript'])==a['LuaScript'],(p['name'],'Top40 manifest parity')
for conf in configs:
 with zipfile.ZipFile(ROOT.parent/conf['path'])as z:
  name=next(n for n in z.namelist()if n.endswith('.json')and (conf['tag']is not None or '/Map-Bags/'in n));src=json.loads(z.read(name))
 roots=src['ObjectStates'][0]['ContainedObjects']if conf['tag']is None else [o for o in src['ObjectStates']if conf['tag']in o.get('Tags',[])]
 original=copy.deepcopy(roots)
 for o in [q for o in roots for q in walk(o)]:
  s=o.get('LuaScript','')
  if '--[[Object base code]]'in s:
   start=s.index('--[[Object base code]]');end=s.index('--[[Spawning object]]',start)+len('--[[Spawning object]]');o['LuaScript']=(s[:start].rstrip()+s[end:]).rstrip()+'\n'
 assert roots==by[conf['guid']]['ContainedObjects'],(conf['name'],'Approved layout/component changed')
 for a,b in zip(original,roots):
  assert a['Transform']==b['Transform'];assert a.get('CustomMesh')==b.get('CustomMesh');assert a.get('CustomAssetbundle')==b.get('CustomAssetbundle')
ids=[o['GUID']for row in load(OUT/'Source/saved-object-index.json')for o in walk(by[row['guid']])];duplicates={g:n for g,n in collections.Counter(ids).items()if n>1};assert not duplicates,duplicates
portal=load(REPO/'shared/lobo-workshop-current.json');assert len(portal['maps'])==40
cats=collections.Counter(x['category']for x in load(OUT/'Source/catalogue.json'));assert cats=={'missions':40,'campaign':50,'top40':10}
host=load(OUT/'Source/hosted-assets-validation.json');assert host['passed']==host['uniqueURLs']and not host['failed']
report=dict(approvedMaps=4,rootObjectCounts={x['name']:x['rootCount']for x in configs},generalTop40Pairs=4,allApprovedTerrainTransformsScalesMeshesAndActiveStatesPreserved=True,unrelatedCollectionObjectsUnchanged=True,nativeCRLFStageRecordsForRootsAndAlternateStates=True,scriptsCompiled=scripts,uniqueUpdatedFamilyGUIDs=len(ids),propagatingScriptRemovedFromVesperOnly=True,categoryCounts=dict(cats),hostedURLsVerified=host['passed'],nativeTTSTested=False)
(OUT/'Source/approved-release-validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
