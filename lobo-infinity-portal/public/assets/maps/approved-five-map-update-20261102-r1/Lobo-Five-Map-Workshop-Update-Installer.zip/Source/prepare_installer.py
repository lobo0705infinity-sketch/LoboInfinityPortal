from pathlib import Path
import json,shutil,hashlib
ROOT=Path(__file__).resolve().parent;BASE=ROOT/'baseline';OUT=ROOT/'release'
s=(BASE/'Install.ps1').read_text(encoding='utf-8-sig')
s=s.replace("$backup = $null","$backup = $null\n$retired = @()")
s=s.replace("if ($items.Count -lt 28) { throw 'Incomplete installer: expected the collection and all thirteen named map pairs.' }","if ($items.Count -ne 44) { throw 'Incomplete installer: expected the collection and all 21 named map pairs.' }")
s=s.replace('Seven-Maps-','Four-Map-Update-')
s=s.replace("Remove-Item -LiteralPath $oldFile","$retired += [pscustomobject]@{Path=$oldFile; Backup=$oldBackup}\n                    Remove-Item -LiteralPath $oldFile")
s=s.replace("Write-Host 'Installed all seven maps and the updated collection.'","Write-Host 'Installed four approved map replacements and the updated collection.'")
s=s.replace("13 map bags and thumbnails","21 map bags and thumbnails").replace('Seven Map Update R1','Four Map Update R1')
s=s.replace("$failure = $_.Exception.Message","$failure = $_.Exception.Message\n    foreach ($old in $retired) {\n        try { Copy-Item -LiteralPath $old.Backup -Destination $old.Path -Force } catch { Write-Host ('Restore needed from backup: ' + $old.Path) -ForegroundColor Yellow }\n    }")
(OUT/'Install.ps1').write_bytes(b'\xef\xbb\xbf'+s.replace('\r\n','\n').replace('\n','\r\n').encode())
shutil.copy2(BASE/'Install.cmd',OUT/'Install.cmd')
(OUT/'START-HERE.txt').write_text("""LOBO'S INFINITY MAPS - FOUR MAP UPDATE R1

1. Close Tabletop Simulator. Extract the COMPLETE ZIP into a fresh folder.
2. Run Install.cmd. Existing target files are backed up and verified first.
   Custom location: drag your Tabletop Simulator folder onto Install.cmd.
3. TTS > Games > Save & Load:
   Lobo's Infinity Maps - Four Map Update R1
4. Workshop Upload > Update Workshop > existing item 3719263238.
   Updating the existing item preserves subscribers and the listing.

Installation does not publish to Steam. Successful Workshop publication must
be confirmed in TTS/Steam. A timeout is not a confirmed upload.

REPLACEMENTS IN THE GENERAL POOL
Redline Interchange - Cutthroat replaces Dustline Outpost.
Ironveil Complex - Hardlock replaces the older Ironveil Complex.
Cairnfall Sanctuary - Battleground replaces Foundry Blocks.
Vesper Glassworks - Neutralization replaces Emberfall Station.
Each mission keeps its other map. There are still 40 general maps.

TOP 40 COPIES
Losers Round 3: Redline Interchange - Cutthroat.
Losers Round 4: Cairnfall Sanctuary - Battleground.
Losers Round 5: Vesper Glassworks - Neutralization.
Losers Round 7: Ironveil Complex - Hardlock.
Hardlock is Round 7, not the Provisioning Round 2 slot.
Halcyon is excluded from this batch; Outbreak remains unassigned.
Kestrel remains an additional Data Harvest map without an assigned round.

APPROVED SOURCES
Redline: exact TS_Save_35 map components.
Ironveil: approved TS_Save_36 map and latest controls.
Cairnfall: approved TS_Save_37 layout and connected archive stair fix.
Vesper: exact TS_Save_38 map components, including its saved building states.
All approved terrain, positions, rotations, scales, models and active states
are preserved. General and event copies differ only in ownership IDs/tags.
An unwanted self-propagating Lua suffix found in Vesper was removed from
the release copy. The user's original archive is unchanged.

CONTENTS
Full current collection: 40 general + 50 Aurora VII + 10 Top 40 entries.
21 named bags and thumbnails install directly into MAIN Saved Objects:
the earlier 13 named bags plus these four maps and their four Top 40 copies.
The prior seven-map improvements, approved Sirocco R7, and unrelated maps
are retained. Nereid remains public Aurora VII terrain without secret scoring.
GUID-named copies of the exact updated slots are backed up before retirement.
Unrelated personal files are preserved.

VERIFICATION
See Source/*validation*.json for exact checks and limits. Hosted references,
source-preservation comparisons, Lua controls, original Stage deployment,
state cleanup, catalogue categories and real PowerShell installation checked.
Previews render the approved exported geometry and saved building states.
Native mission asset-bundle markers are omitted from software previews.
Live TTS physics/rendering, Windows execution and multiplayer are unverified.
First model/texture loading requires internet access.
""")
print('Installer prepared; manifest will be finalized after previews.')
