﻿param([string]$TtsRoot = '')
$ErrorActionPreference = 'Stop'
$items = @()
$written = @()
$backup = $null
$retired = @()
try {
    if ([string]::IsNullOrWhiteSpace($TtsRoot)) {
        $TtsRoot = Join-Path -Path ([Environment]::GetFolderPath('MyDocuments')) -ChildPath 'My Games\Tabletop Simulator'
    }
    $TtsRoot = [IO.Path]::GetFullPath($TtsRoot)
    $saves = Join-Path -Path $TtsRoot -ChildPath 'Saves'
    if (-not (Test-Path -LiteralPath $saves -PathType Container)) {
        throw 'TTS Saves folder not found. Drag your Tabletop Simulator folder onto Install.cmd for a custom location.'
    }
    # Assign directly: wrapping ConvertFrom-Json in @() can nest its array in
    # Windows PowerShell 5.1 and pass an Object[] to Join-Path -ChildPath.
    $manifest = Get-Content -LiteralPath (Join-Path -Path $PSScriptRoot -ChildPath 'Install-Manifest.json') -Raw | ConvertFrom-Json
    $seen = @{}
    foreach ($entry in $manifest) {
        $relative = [string]$entry.path
        $relative = $relative.Replace('\', '/')
        if ($relative -match '(^/|(^|/)\.\.(/|$)|:)' -or $relative -notmatch '^(Files|Saved-Objects|Map-Bags)/[^/]+\.(json|png)$') {
            throw ('Invalid install path: ' + $relative)
        }
        $source = Join-Path -Path $PSScriptRoot -ChildPath $relative
        if ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne [string]$entry.sha256) {
            throw ('Package verification failed: ' + $relative)
        }
        $parts = $relative.Split('/')
        if ($parts[0] -eq 'Files') { $targetRelative = [string]$parts[1] }
        elseif ($parts[0] -eq 'Saved-Objects') { $targetRelative = 'Saved Objects/' + [string]$parts[1] }
        else { $targetRelative = 'Saved Objects/Lobo Workshop - Current Maps/' + [string]$parts[1] }
        if ($seen.ContainsKey($targetRelative.ToLowerInvariant())) { throw ('Duplicate destination: ' + $targetRelative) }
        $seen[$targetRelative.ToLowerInvariant()] = $true
        $destination = Join-Path -Path $saves -ChildPath $targetRelative
        if (Test-Path -LiteralPath $destination -PathType Container) { throw ('A folder blocks the target file: ' + $targetRelative) }
        $items += [pscustomobject]@{Source=$source; Relative=$targetRelative; Destination=$destination; Hash=[string]$entry.sha256; Existed=$false; Backup=$null}
    }
    if ($items.Count -ne 46) { throw 'Incomplete installer: expected the collection and all 22 named map pairs.' }
    $backup = Join-Path -Path $TtsRoot -ChildPath ('Lobo Map Backups/Five-Map-Update-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff') + '-' + [Guid]::NewGuid().ToString('N').Substring(0,6))
    $null = New-Item -ItemType Directory -Path $backup -Force
    # Back up and verify every existing destination before writing any target.
    foreach ($item in $items) {
        if (Test-Path -LiteralPath $item.Destination -PathType Leaf) {
            $item.Existed = $true
            $item.Backup = Join-Path -Path $backup -ChildPath ('Replaced/' + $item.Relative)
            $null = New-Item -ItemType Directory -Path (Split-Path -Path $item.Backup -Parent) -Force
            Copy-Item -LiteralPath $item.Destination -Destination $item.Backup -Force
            if ((Get-FileHash -LiteralPath $item.Destination -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath $item.Backup -Algorithm SHA256).Hash) {
                throw ('Backup verification failed: ' + $item.Relative)
            }
        }
    }
    foreach ($item in $items) {
        $null = New-Item -ItemType Directory -Path (Split-Path -Path $item.Destination -Parent) -Force
        $written += $item
        Copy-Item -LiteralPath $item.Source -Destination $item.Destination -Force
        if ((Get-FileHash -LiteralPath $item.Destination -Algorithm SHA256).Hash -ne $item.Hash) {
            throw ('Installed file verification failed: ' + $item.Relative)
        }
    }
    # Retire only verified GUID-named copies of these exact map slots. Named
    # saved objects and unrelated personal maps are never scanned or removed.
    $index = Get-Content -LiteralPath (Join-Path -Path $PSScriptRoot -ChildPath 'Source/saved-object-index.json') -Raw | ConvertFrom-Json
    foreach ($row in $index) {
        foreach ($folder in @('Saved Objects', 'Saved Objects/Lobo Workshop - Current Maps')) {
            $legacyRelative = $folder + '/' + [string]$row.guid + '.json'
            $legacy = Join-Path -Path $saves -ChildPath $legacyRelative
            if (-not (Test-Path -LiteralPath $legacy -PathType Leaf)) { continue }
            try { $data = Get-Content -LiteralPath $legacy -Raw | ConvertFrom-Json } catch { continue }
            if (@($data.ObjectStates).Count -ne 1 -or [string]$data.ObjectStates[0].GUID -ne [string]$row.guid -or [string]$data.ObjectStates[0].Nickname -notlike 'SET_*') { continue }
            foreach ($extension in @('.json', '.png')) {
                $oldRelative = $folder + '/' + [string]$row.guid + $extension
                $oldFile = Join-Path -Path $saves -ChildPath $oldRelative
                if (-not (Test-Path -LiteralPath $oldFile -PathType Leaf)) { continue }
                $oldBackup = Join-Path -Path $backup -ChildPath ('Previous-GUID-Copies/' + $oldRelative)
                $null = New-Item -ItemType Directory -Path (Split-Path -Path $oldBackup -Parent) -Force
                Copy-Item -LiteralPath $oldFile -Destination $oldBackup -Force
                if ((Get-FileHash -LiteralPath $oldFile -Algorithm SHA256).Hash -eq (Get-FileHash -LiteralPath $oldBackup -Algorithm SHA256).Hash) {
                    $retired += [pscustomobject]@{Path=$oldFile; Backup=$oldBackup}
                    Remove-Item -LiteralPath $oldFile
                }
            }
        }
    }
    # Remove the retired tournament-only Kestrel copy, preserving its general map.
    $retireNames = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'Source/retired-map-index.json') -Raw | ConvertFrom-Json
    foreach ($row in $retireNames) {
        foreach ($folder in @('Saved Objects', 'Saved Objects/Lobo Workshop - Current Maps')) {
            foreach ($stem in @([string]$row.name, [string]$row.guid)) {
                $jsonPath = Join-Path $saves ($folder + '/' + $stem + '.json')
                if (-not (Test-Path -LiteralPath $jsonPath -PathType Leaf)) { continue }
                try { $data = Get-Content -LiteralPath $jsonPath -Raw | ConvertFrom-Json } catch { continue }
                if (@($data.ObjectStates).Count -ne 1 -or [string]$data.ObjectStates[0].GUID -ne [string]$row.guid -or [string]$data.ObjectStates[0].Nickname -notlike 'SET_*') { continue }
                foreach ($extension in @('.json', '.png')) {
                    $relative = $folder + '/' + $stem + $extension
                    $oldFile = Join-Path $saves $relative
                    if (-not (Test-Path -LiteralPath $oldFile -PathType Leaf)) { continue }
                    $oldBackup = Join-Path $backup ('Retired-Top40-Copies/' + $relative)
                    $null = New-Item -ItemType Directory -Path (Split-Path $oldBackup -Parent) -Force
                    Copy-Item -LiteralPath $oldFile -Destination $oldBackup -Force
                    if ((Get-FileHash $oldFile -Algorithm SHA256).Hash -ne (Get-FileHash $oldBackup -Algorithm SHA256).Hash) { throw ('Retirement backup failed: ' + $relative) }
                    $retired += [pscustomobject]@{Path=$oldFile; Backup=$oldBackup}
                    Remove-Item -LiteralPath $oldFile
                }
            }
        }
    }
    Write-Host 'Installed five approved map replacements and the updated collection.' -ForegroundColor Green
    Write-Host '22 map bags and thumbnails are in the MAIN Saved Objects folder.'
    Write-Host "Load save: Lobo's Infinity Maps - Five Map Update R1"
    Write-Host 'Then Workshop Upload > Update Workshop > existing item 3719263238.'
    Write-Host ('Backups: ' + $backup)
    Write-Host 'Installation does not publish to Steam.'
    exit 0
} catch {
    $failure = $_.Exception.Message
    foreach ($old in $retired) {
        try { Copy-Item -LiteralPath $old.Backup -Destination $old.Path -Force } catch { Write-Host ('Restore needed from backup: ' + $old.Path) -ForegroundColor Yellow }
    }
    foreach ($item in $written) {
        try {
            if ($item.Existed) { Copy-Item -LiteralPath $item.Backup -Destination $item.Destination -Force }
            elseif (Test-Path -LiteralPath $item.Destination -PathType Leaf) { Remove-Item -LiteralPath $item.Destination }
        } catch { Write-Host ('Restore needed from backup: ' + $item.Destination) -ForegroundColor Yellow }
    }
    Write-Host ('Installation failed: ' + $failure) -ForegroundColor Red
    if ($backup) { Write-Host ('Backup location: ' + $backup) }
    exit 1
}
