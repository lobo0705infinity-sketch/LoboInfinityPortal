from pathlib import Path
import copy,json,re,hashlib,zipfile,struct
R=Path(__file__).resolve().parent;O=R/'release';O.mkdir(exist_ok=True)
s=json.load(open(R/'TS_Save_46.json'));source=[o for o in s['ObjectStates']if'LoboMap:8102b2'in o.get('Tags',[])]
base=json.load(open(R/'base/Map-Bags/Sirocco-Wells-Provisioning-R8.json'))['ObjectStates'][0]
bag=copy.deepcopy(base);bag['ContainedObjects']=copy.deepcopy(source);bag['Nickname']='SET_ITS18 Provisioning — Sirocco Wells — Approved TS46';bag['Description']='User-approved TS_Save_46: exact active buildings, furnishings, terrain and objective placements; 20 buildings, 9 movable ridges and 22 night lights. Reusable Stage loader rebuilt from this approved save. State 1 remains ground floor.';bag['LuaScriptState']=''
family=lambda o:[o]+[q for v in o.get('States',{}).values()for q in family(v)]
# Session-specific environment must not replace a later table's original settings.
controller=next(o for o in bag['ContainedObjects']if o['GUID']=='d6fffe')
state=json.loads(controller.get('LuaScriptState')or'{}');state.pop('original',None);controller['LuaScriptState']=json.dumps(state,separators=(',',':'))
aligned=[]
for o in bag['ContainedObjects']:
 for q in o.get('States',{}).values():
  if q['Transform']!=o['Transform']:aligned.append(q['GUID']);q['Transform']=copy.deepcopy(o['Transform'])
def manifest(b):
 lines=[]
 for o in b['ContainedObjects']:
  for q in family(o):
   t=q['Transform'];values=[t[k]for k in ['posX','posY','posZ','rotX','rotY','rotZ']]
   lines.append('--'+q['GUID']+','+','.join(f'{v:.9f}'for v in values))
 b['LuaScript']='\r\n'.join(lines)+'\r\n\r\n'
manifest(bag)
jsonwrite=lambda p,d:p.write_text(json.dumps(d,ensure_ascii=False,separators=(',',':'))+'\n')
jsonwrite(O/'Sirocco-Wells-Approved-TS46.json',{'ObjectStates':[bag]})
# A separate tournament copy must not share any loaded object or UI ownership IDs.
collection=json.load(open(R.parent/'collection-input/previous/Collection/Lobo-Workshop-Verdant-Neon-FINAL.json'))
def allnodes(o):
 yield o
 for q in o.get('ContainedObjects',[]):yield from allnodes(q)
 for q in o.get('States',{}).values():yield from allnodes(q)
occupied={o['GUID']for root in collection['ObjectStates']for o in allnodes(root)}
ids=[o['GUID']for o in allnodes(bag)];remap={}
for old in ids:
 salt=0
 while True:
  new=hashlib.sha256(f'SiroccoApproved46Top40:{old}:{salt}'.encode()).hexdigest()[:6]
  if new not in occupied and new not in remap.values():break
  salt+=1
 remap[old]=new
pattern=re.compile(r'(?<![0-9a-fA-F])('+ '|'.join(remap)+r')(?![0-9a-fA-F])')
def convert(v,key=''):
 if isinstance(v,dict):return {k:convert(x,k)for k,x in v.items()}
 if isinstance(v,list):return[convert(x,key)for x in v]
 if isinstance(v,str):
  if key.endswith('URL'):return v
  return pattern.sub(lambda m:remap[m.group()],v)
 return v
top=convert(copy.deepcopy(bag));top['Nickname']="SET_Lobo's Top 40 Losers Round 2 Map";top['Description']='Provisioning — Sirocco Wells. Exact approved TS_Save_46 terrain, with independent tournament IDs.';top['Transform'].update(posX=-57,posY=1.065,posZ=-26,rotX=0,rotY=0,rotZ=0)
manifest(top);jsonwrite(O/'Lobos-Top-40-Losers-Round-2-Map.json',{'ObjectStates':[top]})
# Full table fallback is only used if no newer installed collection exists.
prior=copy.deepcopy(collection)
for i,o in enumerate(collection['ObjectStates']):
 if o['GUID']=='8102b2':
  replacement=copy.deepcopy(bag);replacement['Transform']=copy.deepcopy(o['Transform']);collection['ObjectStates'][i]=replacement
collection['ObjectStates'].append(top);collection['SaveName']="Lobo's Infinity Maps - Approved Sirocco TS46";jsonwrite(O/'Lobo-Workshop-Sirocco-Approved46.json',collection)
assert all(o==collection['ObjectStates'][i]for i,o in enumerate(prior['ObjectStates'])if o['GUID']!='8102b2')
# Exact active objects are authoritative. Only reusable controller session state
# and inactive state placements are normalized; all active transforms stay exact.
for original,q in zip(source,bag['ContainedObjects']):
 for k in ['GUID','Transform','CustomMesh','CustomImage','CustomAssetbundle','ColorDiffuse','LuaScript']:
  assert original.get(k)==q.get(k),(original['GUID'],k)
assert set(o['GUID']for o in allnodes(bag)).isdisjoint(o['GUID']for o in allnodes(top))
assert len(source)==80
# Native Stage manifest targets every active and alternate-state object once.
for b in [bag,top]:
 ids2=[o['GUID']for o in allnodes(b)][1:];assert len(ids2)==len(set(ids2));records={line[2:].split(',')[0]for line in b['LuaScript'].splitlines()if line};assert set(ids2)==records
urls=set()
def urlwalk(v):
 if isinstance(v,dict):
  for k,x in v.items():
   if isinstance(x,str)and k.endswith('URL')and x:urls.add(x)
   elif isinstance(x,(dict,list)):urlwalk(x)
 elif isinstance(v,list):
  for x in v:urlwalk(x)
urlwalk(source);assert all(u.startswith('https://')for u in urls)
jsonwrite(O/'approved-version-validation.json',{'approved_source':'TS_Save_46.json','source_sha256':hashlib.sha256((R/'TS_Save_46.json').read_bytes()).hexdigest(),'active_objects':80,'buildings':20,'ridges':9,'lights':22,'all_active_transforms_models_colors_scripts_preserved':True,'inactive_state_transforms_aligned':aligned,'unrelated_collection_objects_preserved':True,'unique_tournament_ids':True,'tournament_bag_guid':top['GUID'],'https_asset_count':len(urls),'live_TTS_test':'User approved source save; packaged Stage behavior checked offline'})
jsonwrite(O/'asset-urls.json',sorted(urls));jsonwrite(O/'top40-guid-remap.json',remap)
print(json.dumps({'approved_objects':80,'tournament_guid':top['GUID'],'assets':len(urls),'fallback_table_roots':len(collection['ObjectStates'])}))
