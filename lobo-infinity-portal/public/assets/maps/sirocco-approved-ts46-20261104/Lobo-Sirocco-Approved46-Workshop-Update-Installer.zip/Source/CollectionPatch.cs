using System;
using System.Text;
using System.Collections.Generic;
using System.Text.RegularExpressions;
public sealed class SiroccoSpan46 { public int Start; public int Length; public string Guid; }
public static class SiroccoJson46 {
 static int StringEnd(string s,int start) {
  for(int i=start+1;i<s.Length;i++) { if(s[i]=='\\'){i++;continue;} if(s[i]=='"')return i; }
  throw new Exception("Unterminated JSON string");
 }
 static int ArrayStart(string s) {
  int depth=0;
  for(int i=0;i<s.Length;i++) {
   if(s[i]=='"') {
    int end=StringEnd(s,i);
    if(depth==1 && s.Substring(i+1,end-i-1)=="ObjectStates") {
     int j=end+1;while(j<s.Length&&Char.IsWhiteSpace(s[j]))j++;
     if(j<s.Length&&s[j]==':'){j++;while(j<s.Length&&Char.IsWhiteSpace(s[j]))j++;if(j<s.Length&&s[j]=='[')return j;}
    }
    i=end;
   } else if(s[i]=='{')depth++;else if(s[i]=='}')depth--;
  }
  throw new Exception("Root ObjectStates array not found");
 }
 public static List<SiroccoSpan46> Objects(string s) {
  List<SiroccoSpan46> result=new List<SiroccoSpan46>();int i=ArrayStart(s)+1;
  while(i<s.Length) {
   while(i<s.Length&&(Char.IsWhiteSpace(s[i])||s[i]==','))i++;
   if(i<s.Length&&s[i]==']')return result;
   if(i>=s.Length||s[i]!='{')throw new Exception("Invalid root object array");
   int start=i,depth=0,end=-1;
   for(;i<s.Length;i++) {
    if(s[i]=='"'){i=StringEnd(s,i);continue;}
    if(s[i]=='{')depth++;else if(s[i]=='}'){depth--;if(depth==0){end=i+1;break;}}
   }
   if(end<0)throw new Exception("Unterminated root object");
   string head=s.Substring(start,Math.Min(end-start,1500));
   Match m=Regex.Match(head,"^\\s*\\{\\s*\"GUID\"\\s*:\\s*\"([a-fA-F0-9]{6})\"");
   if(!m.Success)throw new Exception("A root object has no leading GUID");
   result.Add(new SiroccoSpan46{Start=start,Length=end-start,Guid=m.Groups[1].Value});i=end;
  }
  throw new Exception("Unterminated root array");
 }
 public static string Patch(string source,string general,string tournament,string topGuid) {
  List<SiroccoSpan46> spans=Objects(source);StringBuilder output=new StringBuilder(source.Length+general.Length+tournament.Length);int cursor=0;bool found=false,hasTop=false;
  foreach(SiroccoSpan46 span in spans) {
   string raw=source.Substring(span.Start,span.Length);
   string head=raw.Substring(0,Math.Min(raw.Length,1500));string replacement=null;
   if(span.Guid=="8102b2"){replacement=general;found=true;}
   else if(span.Guid==topGuid || Regex.IsMatch(head,"\"Nickname\"\\s*:\\s*\"SET_Lobo's Top 40 Losers Round 2 Map\"")){replacement=tournament;hasTop=true;}
   if(replacement!=null){output.Append(source,cursor,span.Start-cursor);output.Append(replacement);cursor=span.Start+span.Length;}
  }
  if(!found)throw new Exception("Sirocco bag was not found in the collection");
  if(!hasTop) {
   int end=spans[spans.Count-1].Start+spans[spans.Count-1].Length;
   output.Append(source,cursor,end-cursor);output.Append(',');output.Append(tournament);cursor=end;
  }
  output.Append(source,cursor,source.Length-cursor);return output.ToString();
 }
 public static bool OthersPreserved(string before,string after,string topGuid) {
  Dictionary<string,string> original=new Dictionary<string,string>();
  foreach(SiroccoSpan46 span in Objects(before)) {
   string raw=before.Substring(span.Start,span.Length);string head=raw.Substring(0,Math.Min(raw.Length,1500));
   if(span.Guid=="8102b2"||span.Guid==topGuid||head.Contains("SET_Lobo's Top 40 Losers Round 2 Map"))continue;
   original.Add(span.Guid,raw);
  }
  foreach(SiroccoSpan46 span in Objects(after)) {
   if(original.ContainsKey(span.Guid)) {
    if(original[span.Guid]!=after.Substring(span.Start,span.Length))return false;
    original.Remove(span.Guid);
   }
  }
  return original.Count==0;
 }
}
