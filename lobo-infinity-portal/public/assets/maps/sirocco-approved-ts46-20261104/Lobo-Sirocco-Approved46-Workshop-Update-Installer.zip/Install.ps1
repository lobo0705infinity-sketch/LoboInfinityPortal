param([string]$TtsRoot='')
$ErrorActionPreference='Stop'
$written=@();$backups=@{}
try {
 if ([string]::IsNullOrWhiteSpace($TtsRoot)) {$TtsRoot=Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'My Games/Tabletop Simulator'}
 $saves=Join-Path $TtsRoot 'Saves'
 if (-not (Test-Path -LiteralPath $saves -PathType Container)) {throw 'TTS Saves folder not found. Pass your Tabletop Simulator folder to Install.cmd.'}
 $manifest=ConvertFrom-Json -InputObject ([IO.File]::ReadAllText((Join-Path $PSScriptRoot 'Install-Manifest.json')))
 foreach ($entry in $manifest) {
  if ($entry.path -isnot [string]) {throw 'Invalid file list: a path is not a string.'}
  $source=Join-Path $PSScriptRoot $entry.path
  if ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne $entry.sha256) {throw ('Package checksum failed: '+$entry.path)}
 }
 Add-Type -Path (Join-Path $PSScriptRoot 'Source/CollectionPatch.cs')
 $generalText=[IO.File]::ReadAllText((Join-Path $PSScriptRoot 'Map-Bags/Sirocco-Wells-Approved-TS46.json'))
 $topText=[IO.File]::ReadAllText((Join-Path $PSScriptRoot 'Map-Bags/Lobos-Top-40-Losers-Round-2-Map.json'))
 $general=(ConvertFrom-Json -InputObject $generalText).ObjectStates[0]
 $top=(ConvertFrom-Json -InputObject $topText).ObjectStates[0]
 $topGuid=$top.GUID
 $candidates=@(Get-ChildItem -LiteralPath $saves -Filter 'Lobo*.json' -File)
 $steam=Join-Path $TtsRoot 'Mods/Workshop/3719263238.json'
 if (Test-Path -LiteralPath $steam -PathType Leaf) {$candidates+=Get-Item -LiteralPath $steam}
 $chosen=$null;$collection=$null;$usedFallback=$false
 foreach ($candidate in ($candidates | Sort-Object LastWriteTime -Descending)) {
  try {
   $raw=[IO.File]::ReadAllText($candidate.FullName)
   $spans=[SiroccoJson46]::Objects($raw)
   if ($spans.Count -lt 50) {continue}
   $match=$spans | Where-Object {$_.Guid -eq '8102b2'} | Select-Object -First 1
   if (-not $match) {continue}
   $oldBag=ConvertFrom-Json -InputObject $raw.Substring($match.Start,$match.Length)
   if ($oldBag.Name -ne 'Bag' -or $oldBag.Nickname -notlike 'SET_*') {continue}
   $collection=$raw;$chosen=$candidate.FullName;$general.Transform=$oldBag.Transform;break
  } catch {continue}
 }
 if (-not $collection) {
  $chosen=Join-Path $PSScriptRoot 'Collection/Lobo-Workshop-Sirocco-Approved46.json'
  $collection=[IO.File]::ReadAllText($chosen);$usedFallback=$true
  $spans=[SiroccoJson46]::Objects($collection)
  $match=$spans | Where-Object {$_.Guid -eq '8102b2'} | Select-Object -First 1
  $general.Transform=(ConvertFrom-Json -InputObject $collection.Substring($match.Start,$match.Length)).Transform
 }
 $generalJson=ConvertTo-Json -InputObject $general -Depth 100 -Compress
 $topJson=ConvertTo-Json -InputObject $top -Depth 100 -Compress
 $patched=[SiroccoJson46]::Patch($collection,$generalJson,$topJson,$topGuid)
 $patched=[regex]::Replace($patched,'\A(\s*\{\s*"SaveName"\s*:\s*)"(?:\\.|[^"\\])*"', {param($m) $m.Groups[1].Value+'"Lobo''s Infinity Maps - Approved Sirocco TS46"'})
 if (-not [SiroccoJson46]::OthersPreserved($collection,$patched,$topGuid)) {throw 'Unrelated collection objects changed. Installation was stopped.'}
 $objects=Join-Path $saves 'Saved Objects'
 $null=New-Item -ItemType Directory -Path $objects -Force
 $backup=Join-Path $TtsRoot ('Lobo Map Backups/Sirocco-Approved46/'+(Get-Date -Format 'yyyyMMdd-HHmmss-ffff'))
 $null=New-Item -ItemType Directory -Path $backup -Force
 $output=Join-Path $saves 'Lobo-Workshop-Sirocco-Approved46.json'
 $items=@(
  @{Target=$output;Text=$patched;Source=$null},
  @{Target=(Join-Path $objects 'Sirocco-Wells-Approved-TS46.json');Text=$generalText;Source=$null},
  @{Target=(Join-Path $objects 'Lobos-Top-40-Losers-Round-2-Map.json');Text=$topText;Source=$null},
  @{Target=(Join-Path $saves 'Lobo-Workshop-Sirocco-Approved46.png');Text=$null;Source=(Join-Path $PSScriptRoot 'Map-Bags/Sirocco-Wells-Approved-TS46.png')},
  @{Target=(Join-Path $objects 'Sirocco-Wells-Approved-TS46.png');Text=$null;Source=(Join-Path $PSScriptRoot 'Map-Bags/Sirocco-Wells-Approved-TS46.png')},
  @{Target=(Join-Path $objects 'Lobos-Top-40-Losers-Round-2-Map.png');Text=$null;Source=(Join-Path $PSScriptRoot 'Map-Bags/Lobos-Top-40-Losers-Round-2-Map.png')}
 )
 foreach ($item in $items) {
  if (Test-Path -LiteralPath $item.Target) {
   $copy=Join-Path $backup ([Guid]::NewGuid().ToString('N')+'-'+[IO.Path]::GetFileName($item.Target))
   Copy-Item -LiteralPath $item.Target -Destination $copy -Force;$backups[$item.Target]=$copy
  }
 }
 foreach ($item in $items) {
  $temporary=$item.Target+'.installing'
  if ($null -ne $item.Text) {[IO.File]::WriteAllText($temporary,$item.Text,(New-Object Text.UTF8Encoding($false)))}
  else {Copy-Item -LiteralPath $item.Source -Destination $temporary -Force}
  $written+=$item.Target;Move-Item -LiteralPath $temporary -Destination $item.Target -Force
 }
 Write-Host 'Installed approved TS_Save_46: general Sirocco and Top 40 Losers Round 2.' -ForegroundColor Green
 Write-Host ('Collection source: '+$chosen)
 if ($usedFallback) {Write-Host 'No installed collection was found; used the bundled collection.' -ForegroundColor Yellow}
 Write-Host 'Unrelated collection objects are preserved byte for byte.'
 Write-Host "In TTS, load: Lobo's Infinity Maps - Approved Sirocco TS46"
 Write-Host 'Then Workshop Upload > Update Workshop > EXISTING item 3719263238.'
 Write-Host 'Keep its existing title and visibility, and wait for Steam to confirm success.'
 Write-Host 'The final Steam upload must be performed inside TTS.'
 Write-Host ('Backups: '+$backup)
 exit 0
} catch {
 foreach ($target in $written) {
  if ($backups.ContainsKey($target)) {Copy-Item -LiteralPath $backups[$target] -Destination $target -Force}
  elseif (Test-Path -LiteralPath $target) {Remove-Item -LiteralPath $target -Force}
 }
 Write-Host ('Installation failed: '+$_.Exception.Message) -ForegroundColor Red
 Write-Host ('Script line: '+$_.InvocationInfo.ScriptLineNumber)
 exit 1
}
