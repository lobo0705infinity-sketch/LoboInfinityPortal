            -- LOBO VANTA R6 CATALOGUE
            if name:find('Vanta Customs Yard',1,true) then
                item.title='Vanta Customs Yard'; item.mission='B-Pong'; item.category='missions'
            end
