﻿param([string]$TtsRoot, [string]$SourceSave, [switch]$NoBrowser)
$ErrorActionPreference = 'Stop'
$tempSave = $null
try {
    if (-not $TtsRoot) { $TtsRoot = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'My Games/Tabletop Simulator' }
    $saveDir = Join-Path $TtsRoot 'Saves'
    if (-not (Test-Path -LiteralPath $saveDir -PathType Container)) { throw 'Tabletop Simulator Saves was not found. Drag your TTS data folder onto INSTALL.cmd if you use a custom location.' }
    $manifest = Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'installer-manifest.json') | ConvertFrom-Json
    foreach ($item in $manifest.files) {
        if ((Get-FileHash -LiteralPath (Join-Path $PSScriptRoot $item.name) -Algorithm SHA256).Hash -ne $item.sha256) { throw ('Checksum failed: ' + $item.name) }
    }
    function Set-ObjectField($o, [string]$field, $value) {
        if ($o.PSObject.Properties[$field]) { $o.$field = $value }
        else { $o | Add-Member -MemberType NoteProperty -Name $field -Value $value }
    }
    function Test-MapBag($o) {
        return ($o.Name -eq 'Bag' -and $o.Nickname -like 'SET_*' -and ([string]$o.Description) -notmatch 'PICKUP COPY:' -and ([string]$o.LuaScript) -match '(?m)^--[0-9a-f]{6},')
    }
    function Get-MapBags($items) {
        foreach ($o in $items) {
            if (Test-MapBag $o) { Write-Output $o }
            else { Get-MapBags $o.ContainedObjects }
        }
    }
    function Get-Vanta($d) { @(Get-MapBags $d.ObjectStates | Where-Object { $_.Nickname -match '(?i)Vanta Customs Yard' }) }
    function Test-Collection($d) {
        $stage = @($d.ObjectStates | Where-Object { $_.GUID -eq '2d647a' -or $_.Nickname -eq 'Stage' })
        $bags = @(Get-MapBags $d.ObjectStates)
        $targets = @(Get-Vanta $d)
        return ($stage.Count -ge 1 -and $bags.Count -ge 100 -and $targets.Count -eq 1 -and ([string]$d.LuaScript).Contains('local function rebuildCatalogue'))
    }
    $sourcePath = Join-Path $PSScriptRoot 'Workshop-Save.json'
    $data = [IO.File]::ReadAllText($sourcePath) | ConvertFrom-Json
    if ($SourceSave) {
        $candidate = [IO.File]::ReadAllText($SourceSave) | ConvertFrom-Json
        if (-not (Test-Collection $candidate)) { throw 'The selected source must be a complete Lobo map collection with a Stage and one Vanta catalogue entry.' }
        $sourcePath = (Resolve-Path -LiteralPath $SourceSave).Path; $data = $candidate
    } else {
        $baselineDate = [DateTime]::Parse($manifest.baseline_date).ToUniversalTime()
        $candidates = foreach ($root in @($saveDir,(Join-Path $TtsRoot 'Mods/Workshop'))) {
            if (Test-Path -LiteralPath $root -PathType Container) {
                Get-ChildItem -LiteralPath $root -Filter '*.json' -File -Recurse -ErrorAction SilentlyContinue |
                    Where-Object { $_.Length -gt 1000000 -and $_.Length -lt 200000000 -and $_.LastWriteTimeUtc -ge $baselineDate -and $_.FullName -notmatch '[\/](Backups?|Saved Objects)[\/]' }
            }
        }
        foreach ($file in ($candidates | Sort-Object LastWriteTimeUtc -Descending)) {
            try {
                $candidate = [IO.File]::ReadAllText($file.FullName) | ConvertFrom-Json
                if (-not (Test-Collection $candidate)) { continue }
                $data = $candidate; $sourcePath = $file.FullName; break
            } catch { continue }
        }
    }
    if (-not (Test-Collection $data)) { throw 'No complete Lobo map collection could be validated.' }
    $bag = @(Get-Vanta $data)[0]
    $fresh = [IO.File]::ReadAllText((Join-Path $PSScriptRoot 'Vanta-Customs-Yard.json')) | ConvertFrom-Json
    function Get-Ids($o) {
        if ($o.GUID) { Write-Output ([string]$o.GUID) }
        foreach ($child in $o.ContainedObjects) { Get-Ids $child }
        if ($o.States) { foreach ($state in $o.States.PSObject.Properties) { Get-Ids $state.Value } }
    }
    $usedIds = New-Object 'System.Collections.Generic.HashSet[string]'
    function Reserve-Ids($o) {
        if ([object]::ReferenceEquals($o,$bag)) { return }
        if ($o.GUID) { [void]$usedIds.Add([string]$o.GUID) }
        foreach ($child in $o.ContainedObjects) { Reserve-Ids $child }
        if ($o.States) { foreach ($state in $o.States.PSObject.Properties) { Reserve-Ids $state.Value } }
    }
    foreach ($root in $data.ObjectStates) { Reserve-Ids $root }
    [void]$usedIds.Add([string]$bag.GUID)
    $mapping = @{}
    if ($fresh.GUID -ne $bag.GUID) { $mapping[[string]$fresh.GUID] = [string]$bag.GUID }
    foreach ($child in $fresh.ContainedObjects) {
        foreach ($id in @(Get-Ids $child)) {
            if (-not $usedIds.Add($id)) {
                do { $nextId = [Guid]::NewGuid().ToString('N').Substring(0,6) } while (-not $usedIds.Add($nextId))
                $mapping[$id] = $nextId
            }
        }
    }
    if ($mapping.Count -gt 0) {
        $pattern = '(?<![a-zA-Z0-9])(?:' + (($mapping.Keys | ForEach-Object { [regex]::Escape($_) }) -join '|') + ')(?![a-zA-Z0-9])'
        $rewrite = [Text.RegularExpressions.MatchEvaluator]{ param($hit) return [string]$mapping[$hit.Value] }
        function Rewrite-Text([string]$value) {
            # Preserve URLs even when a script embeds model data or asset filenames.
            $parts = [regex]::Split($value, '(https?://[^\s"''<>\\]+)')
            for ($i=0; $i -lt $parts.Count; $i++) {
                if ($parts[$i] -notmatch '^https?://') { $parts[$i] = [regex]::Replace($parts[$i],$pattern,$rewrite) }
            }
            return ($parts -join '')
        }
        function Rewrite-ObjectIds($o) {
            if ($o.GUID -and $mapping.ContainsKey([string]$o.GUID)) { $o.GUID = $mapping[[string]$o.GUID] }
            foreach ($field in @('LuaScript','LuaScriptState','XmlUI')) {
                if ($o.PSObject.Properties[$field] -and $o.$field) { $o.$field = Rewrite-Text ([string]$o.$field) }
            }
            if ($o.Tags) { $o.Tags = @($o.Tags | ForEach-Object { Rewrite-Text ([string]$_) }) }
            foreach ($child in $o.ContainedObjects) { Rewrite-ObjectIds $child }
            if ($o.States) { foreach ($state in $o.States.PSObject.Properties) { Rewrite-ObjectIds $state.Value } }
        }
        Rewrite-ObjectIds $fresh
    }
    foreach ($field in @('Nickname','ContainedObjects','LuaScript','LuaScriptState','Tags','Description')) {
        if ($fresh.PSObject.Properties[$field]) { Set-ObjectField $bag $field $fresh.$field }
        else { $bag.PSObject.Properties.Remove($field) }
    }
    if ($bag.ContainedObjects.Count -ne 50) { throw 'The Vanta bag must contain 50 map objects.' }
    foreach ($object in $bag.ContainedObjects) {
        if ($bag.LuaScript -notmatch ('(?m)^--' + [regex]::Escape($object.GUID) + ',')) { throw ('Missing placement record: ' + $object.Nickname) }
    }
    $globalScript = ([string]$data.LuaScript).Replace('-- LOBO VANTA R5 CATALOGUE','-- LOBO VANTA R6 CATALOGUE')
    $data.LuaScript = $globalScript
    if (-not $globalScript.Contains('-- LOBO VANTA R6 CATALOGUE')) {
        $anchor = '            item.home=object.getPosition()'
        if (-not $globalScript.Contains($anchor)) { throw 'The local catalogue layout differs from the supported collection. Use -SourceSave with the bundled Workshop-Save.json.' }
        $patch = [IO.File]::ReadAllText((Join-Path $PSScriptRoot 'Catalogue-Patch.lua'))
        $data.LuaScript = $globalScript.Replace($anchor,$patch+$anchor)
    }
    Set-ObjectField $data 'SaveName' $manifest.save_name
    $text = ConvertTo-Json -InputObject $data -Depth 100 -Compress
    $null = $text | ConvertFrom-Json
    if ($text -match 'file://|__LOBO_TEXTURE_ROOT__|VANTA_COMMIT') { throw 'Unresolved local asset reference found.' }
    $tempSave = Join-Path $saveDir ([Guid]::NewGuid().ToString('N') + '.installing')
    [IO.File]::WriteAllText($tempSave,$text,(New-Object Text.UTF8Encoding($false)))
    $slot = 1
    while ($true) {
        $target = Join-Path $saveDir ('TS_Save_' + $slot + '.json')
        $imageTarget = Join-Path $saveDir ('TS_Save_' + $slot + '.png')
        if (-not (Test-Path -LiteralPath $target) -and -not (Test-Path -LiteralPath $imageTarget)) {
            try { [IO.File]::Move($tempSave,$target); break }
            catch [IO.IOException] { if (-not (Test-Path -LiteralPath $target)) { throw } }
        }
        $slot++
    }
    [IO.File]::Copy((Join-Path $PSScriptRoot 'Workshop-Save.png'),$imageTarget)
    $objectDir = Join-Path $TtsRoot 'Saves/Saved Objects/Lobo Repairs'
    [IO.Directory]::CreateDirectory($objectDir) | Out-Null
    $stem = 'Lobo-Vanta-Customs-Yard-R9'; $suffix = ''; $n = 1
    while (Test-Path -LiteralPath (Join-Path $objectDir ($stem+$suffix+'.json'))) { $suffix = '-' + $n; $n++ }
    [IO.File]::Copy((Join-Path $PSScriptRoot 'Saved-Objects/Vanta-Customs-Yard.json'),(Join-Path $objectDir ($stem+$suffix+'.json')))
    [IO.File]::Copy((Join-Path $PSScriptRoot 'Workshop-Save.png'),(Join-Path $objectDir ($stem+$suffix+'.png')))
    # Also install the user's exact approved table, with rooftop items integrated into the building states.
    $approvedSource = Join-Path $PSScriptRoot 'Approved-Table.json'
    $approvedSlot = 1
    while ($true) {
        $approvedTarget = Join-Path $saveDir ('TS_Save_' + $approvedSlot + '.json')
        $approvedImage = Join-Path $saveDir ('TS_Save_' + $approvedSlot + '.png')
        if (-not (Test-Path -LiteralPath $approvedTarget) -and -not (Test-Path -LiteralPath $approvedImage)) {
            try { [IO.File]::Copy($approvedSource,$approvedTarget,$false); break }
            catch [IO.IOException] { if (-not (Test-Path -LiteralPath $approvedTarget)) { throw } }
        }
        $approvedSlot++
    }
    [IO.File]::Copy((Join-Path $PSScriptRoot 'Workshop-Save.png'),$approvedImage)
    Write-Host 'Approved table: Vanta Customs Yard - Official R9' -ForegroundColor Green
    Write-Host 'Installed: Lobo Infinity Maps - Vanta Customs Yard R9' -ForegroundColor Green
    Write-Host ('Source collection: ' + $sourcePath)
    Write-Host ('New save: ' + $target)
    Write-Host 'Load this collection in Games > Save & Load.'
    Write-Host 'Vanta Customs Yard is updated in its normal catalogue entry.'
    Write-Host 'Use Upload > Workshop Upload > Update Workshop, item 3719263238.'
    Write-Host 'The direct auto-deploy bag is in Objects > Saved Objects > Lobo Repairs.'
    if (-not $NoBrowser) { try { Start-Process 'https://steamcommunity.com/sharedfiles/filedetails/?id=3719263238' } catch {} }
    exit 0
} catch {
    Write-Host ('Installation failed: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
} finally {
    if ($tempSave -and (Test-Path -LiteralPath $tempSave)) { Remove-Item -LiteralPath $tempSave -Force }
}
