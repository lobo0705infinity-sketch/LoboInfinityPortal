@echo off
"%~dp0Vanta-Setup.exe" %*
set "vanta_status=%errorlevel%"
echo.
pause
exit /b %vanta_status%
