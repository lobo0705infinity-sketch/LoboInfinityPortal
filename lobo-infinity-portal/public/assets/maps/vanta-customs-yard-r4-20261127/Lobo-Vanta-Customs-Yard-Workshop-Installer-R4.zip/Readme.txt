﻿VANTA CUSTOMS YARD R4
B-Pong  |  Lobo's Infinity Maps  |  Workshop installer

Extract the entire ZIP and double-click Install.cmd. Open Games > Save & Load
in Tabletop Simulator. Two saves have different thumbnails and names.

To update the existing Steam Workshop item
Open "Lobo Maps - Vanta Customs Yard R4 - Workshop Collection".
Choose Upload > Workshop Upload > Update Workshop. Select "Lobo's Infinity
Maps" (3719263238). This save opens to the 107-map catalogue. Choose B-Pong,
pick up the Vanta Customs Yard bag and drop the copy onto the Infinity Stage.

To play the new layout directly
Open "Vanta Customs Yard R4 - B-Pong - Play Table". The terrain and three
B-Pong objectives are on the table. Use a building's right-click floor menu
to inspect its interior. The map bag is also under Objects > Saved Objects
> Lobo - Vanta Customs Yard.

The installer uses fresh numbered save slots. If you have a custom TTS data
location, drag the Tabletop Simulator data folder or its Saves folder onto
Install.cmd. The table fetches its map assets from public URLs.

Manual install on macOS, Linux or Windows
Open Files/payload.zip. In your TTS Saves folder, copy Workshop-Save.json
and Workshop-Preview.png as TS_Save_N.json and TS_Save_N.png, using the
same unused number for N. For Play-Table.json and Preview.png, use another
unused number. In Saves/Saved Objects, copy Vanta-Customs-Yard.json and a
copy of Preview.png named Vanta-Customs-Yard.png.

R4 is based on TS_Save_448. The mat follows the vehicle positions, the open
bonded-store gate, the staff and drivers' walks, and the Quarantine power run.
