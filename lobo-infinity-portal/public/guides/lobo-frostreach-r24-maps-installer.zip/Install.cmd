@echo off
setlocal EnableExtensions DisableDelayedExpansion
title Lobo Frostreach R24 Maps
echo LOBO FROSTREACH R24 - FROSTHOLD AND POLAR EXPEDITION
set "LOBO_DOCS="
for /f "tokens=2,*" %%A in ('reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders" /v Personal 2^>nul') do set "LOBO_DOCS=%%B"
if not defined LOBO_DOCS set "LOBO_DOCS=%USERPROFILE%\Documents"
set "LOBO_BASE=%LOBO_DOCS%\My Games\Tabletop Simulator"
if exist "%LOBO_BASE%\Saves\" goto found
if exist "%USERPROFILE%\Documents\My Games\Tabletop Simulator\Saves\" set "LOBO_BASE=%USERPROFILE%\Documents\My Games\Tabletop Simulator"
if exist "%LOBO_BASE%\Saves\" goto found
if defined OneDrive if exist "%OneDrive%\Documents\My Games\Tabletop Simulator\Saves\" set "LOBO_BASE=%OneDrive%\Documents\My Games\Tabletop Simulator"
if exist "%LOBO_BASE%\Saves\" goto found
echo Paste your Tabletop Simulator DOCUMENTS folder, which contains Saves.
set "LOBO_BASE="
set /p "LOBO_BASE=Tabletop Simulator folder: "
if not defined LOBO_BASE goto cancelled
set "LOBO_BASE=%LOBO_BASE:"=%"
if not exist "%LOBO_BASE%\Saves\" goto badfolder
:found
if not exist "%~dp0SHA256.txt" goto missing
set "LOBO_HASHFILE=%TEMP%\LoboFrostHash-%RANDOM%-%RANDOM%.txt"
set "LOBO_BACKUP=%LOBO_BASE%\LoboFrostreachBackups\%RANDOM%-%RANDOM%"
echo Checking package files...
for /f "usebackq tokens=1,*" %%H in ("%~dp0SHA256.txt") do (
 call :verify "%%H" "%%I"
 if errorlevel 1 goto failure
)
echo Installing into: %LOBO_BASE%
for /f "usebackq tokens=1,*" %%H in ("%~dp0SHA256.txt") do (
 call :install "%%I"
 if errorlevel 1 goto failure
)
if exist "%LOBO_HASHFILE%" del /q "%LOBO_HASHFILE%" >nul 2>&1
echo INSTALLED.
echo In your Infinity mod: Saved Objects / Lobo-Frostreach-R24.
echo Spawn the chosen map bag and drop it in Place bags here.
echo Preview saves are in Games / Save and Load / Lobo-Frostreach-R24.
pause
exit /b 0
:verify
if not exist "%~dp0Files\%~2" exit /b 1
certutil -hashfile "%~dp0Files\%~2" SHA256 >"%LOBO_HASHFILE%" 2>nul
if errorlevel 1 exit /b 1
findstr /i /c:"%~1" "%LOBO_HASHFILE%" >nul
if errorlevel 1 exit /b 1
exit /b 0
:install
set "LOBO_SOURCE=%~dp0Files\%~1"
set "LOBO_TARGET=%LOBO_BASE%\%~1"
set "LOBO_BAK=%LOBO_BACKUP%\%~1"
for %%D in ("%LOBO_TARGET%") do if not exist "%%~dpD" mkdir "%%~dpD"
if exist "%LOBO_TARGET%" (
 for %%D in ("%LOBO_BAK%") do if not exist "%%~dpD" mkdir "%%~dpD"
 copy /b "%LOBO_TARGET%" "%LOBO_BAK%" >nul
 if errorlevel 1 exit /b 1
 fc /b "%LOBO_TARGET%" "%LOBO_BAK%" >nul
 if errorlevel 1 exit /b 1
)
set "LOBO_TEMP=%LOBO_TARGET%.%RANDOM%-%RANDOM%.tmp"
copy /b "%LOBO_SOURCE%" "%LOBO_TEMP%" >nul
if errorlevel 1 exit /b 1
fc /b "%LOBO_SOURCE%" "%LOBO_TEMP%" >nul
if errorlevel 1 exit /b 1
move /y "%LOBO_TEMP%" "%LOBO_TARGET%" >nul
if errorlevel 1 exit /b 1
fc /b "%LOBO_SOURCE%" "%LOBO_TARGET%" >nul
if errorlevel 1 exit /b 1
exit /b 0
:missing
echo Missing files. Extract the ENTIRE ZIP first.
goto failure
:badfolder
echo Folder not found. No files were installed.
pause
exit /b 1
:cancelled
echo Installation cancelled.
exit /b 1
:failure
if defined LOBO_HASHFILE if exist "%LOBO_HASHFILE%" del /q "%LOBO_HASHFILE%" >nul 2>&1
echo Installation failed. Existing-file backups remain in LoboFrostreachBackups.
pause
exit /b 1
