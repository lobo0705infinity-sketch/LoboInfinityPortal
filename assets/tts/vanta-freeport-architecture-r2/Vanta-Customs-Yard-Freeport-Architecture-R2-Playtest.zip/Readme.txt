﻿Vanta Customs Yard | Freeport Architecture R2
ITS18 B-Pong playtest for Tabletop Simulator

Extract the entire ZIP and run Install.cmd. Open Games > Save & Load and choose
Vanta Customs Yard - Freeport Architecture R2 - B-Pong - Playtest

The installer creates a fresh local save slot and a reusable map bag under Objects > Saved Objects > Lobo-Vanta-Freeport-Architecture-R2. To place the bag on a compatible Infinity table, clear its prior map and drop this bag onto Stage. For a custom TTS data directory, drag that directory onto Install.cmd.

On the table, inspect Dispatch Exchange and Seal Inspection Works on opposite sides of the tracking beacon. Right-click a building and choose Show Ground floor or Show Upper floor to visit a room. Choose Show Roof to close it.

Gate 01 flags consignment VX-417. At Inspection, an examiner has opened the sample case. The matching refrigerated container is held on shore power at Quarantine Q2. The transfer crew is collecting a different, cleared load under the dock canopy.

The Preview folder includes the map at the same angle before and after the rebuild, plus four views of furnished rooms.
