﻿Kestrel Lunar Base | Data Harvest

Installing on Windows

1. Extract the entire ZIP to one folder.
2. Double-click Install.cmd. If you use a custom Tabletop Simulator data folder, drag that folder onto Install.cmd.
3. In Tabletop Simulator, go to Games > Save & Load.

Publishing to the existing Workshop item

Open "Lobo Maps - Kestrel Lunar Base Final - Workshop Collection". This save contains the 107-map collection.
Choose Upload > Workshop Upload > Update Workshop. Select Lobo's Infinity Maps (3719263238) and confirm the update.

Playing Kestrel directly

Open "Kestrel Lunar Base - Station Plan Final - Data Harvest - Play Table". The base and all three Data Harvest Tech-Coffins are on the table.
The shuttle apron has a four-inch return on its blast shield beside the flight-side Tech-Coffin.

On another compatible Infinity table, clear the old map, then drop the Kestrel bag from Objects > Saved Objects on the Stage.

The installer uses two free save slots and creates a new Kestrel folder under Saved Objects. Multiplayer assets use public URLs.
