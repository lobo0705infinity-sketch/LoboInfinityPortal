@echo off
"%~dp0Kestrel-Setup.exe" %*
exit /b %errorlevel%
