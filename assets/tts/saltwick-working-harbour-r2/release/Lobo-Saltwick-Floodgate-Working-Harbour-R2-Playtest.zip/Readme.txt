﻿Saltwick Floodgate
Working Harbour R2 · Area of Interest

Installing the playtest on Windows

1. Extract the entire ZIP into one folder. Run Install.cmd.
2. In Tabletop Simulator, open Games > Save & Load.
3. Choose Saltwick Floodgate - Working Harbour R2 - Area of Interest.

The installer creates a new numbered save slot, with the map already set up for play. It also installs a separate map bag under Objects > Saved Objects, in its own Lobo-Saltwick-Working-Harbour-R2 folder. In a compatible Infinity room, drop that bag on the Stage to load the map. If you use a custom TTS data location, drag your Tabletop Simulator data folder or its Saves folder onto Install.cmd. Initial loading uses public model and texture URLs.

On the table

The net-washing yard, quay pump floodwall and weigh office break up the paved approaches to the crossing. A harbour launch sits on the slipway rails. Passengers have a sheltered ferry waiting area. On the opposite deployment side, the net shed has an insulated catch-ice hopper and dispatch screen.

Four different lorries serve the port. Look for the fitter's folding crane at Slipway Repair, the open tail lift at Tide Works, the Cold Stores refrigerator and the Water Services tanker.

The four truck meshes include inset glass, open driver windows, cab interiors, steering, mirrors, arched fenders and separate chassis components. The R1 floodgate, cable-drum yard and receiving canopy carry over into R2.

Playtest checks

Try moving a 25 mm base from the ferry timetable or the rigging shop to the central 40 mm console. Compare the view along the lower-left apron from either end of the new net rack. The controls, clearance and model sightlines were tested offline. This is an in-game review build.

Artwork

Original Saltwick meshes and texture work. The new material atlas uses CC0 photographs from Poly Haven, including Weathered Brown Planks, Rusty Painted Metal, Rough Wood, Concrete Wall 003 and Worn Corrugated Iron. The cab glass uses reflections sampled from Saltwick's existing estuary panorama.
