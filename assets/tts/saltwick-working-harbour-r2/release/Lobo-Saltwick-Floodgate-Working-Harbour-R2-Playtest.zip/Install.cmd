@echo off
"%~dp0Lobo-Saltwick-Harbour-R2-Setup.exe" %*
