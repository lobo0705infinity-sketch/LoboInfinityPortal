Cairnfall Sanctuary | Courtyards R2
ITS18 Battleground | Tabletop Simulator playtest

1. Extract the entire ZIP and run Install.cmd.
2. In Tabletop Simulator, open Games > Save & Load.
3. Select Cairnfall Sanctuary - Courtyards R2 - Battleground - Play Table.

If you use a custom TTS data location, drag your Tabletop Simulator or Saves folder onto Install.cmd.
The installer creates a new save slot. Both Stage bags are available under Objects > Saved Objects in the Lobo-Cairnfall-Courtyards-R2 folder. Choose the general Battleground bag or the Top 40 Losers Round 4 bag when you already have the Infinity Stage open.

Look for the Laundry drying yard, Refectory delivery cart, Archive receiving counter and the sheltered rest outside the clinic. Opening the Dogleg Cloister or Stepped Archive now removes its rooftop planter. The clinic AC unit has its own roof bay and the exposed upper Archive ladder has been removed.
