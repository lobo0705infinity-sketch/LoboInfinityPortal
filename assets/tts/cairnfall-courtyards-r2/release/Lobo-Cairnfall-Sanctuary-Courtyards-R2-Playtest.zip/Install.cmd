@echo off
"%~dp0Cairnfall-Setup.exe" %*
