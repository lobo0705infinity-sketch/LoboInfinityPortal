# Saltwick Floodgate, Working Harbour R4

R4 adds the moored pump pontoon and four harbour installations, rebuilds the Marlow launch's inner hull, and remounts the departures board. This patch starts from the published R3 playtest in both the ready table and Stage bag. Terrain units are tabletop inches.

Run these commands from the extracted archive root on Linux with Python, NumPy, SciPy, Pillow and the DejaVu fonts.

```sh
python s4/bootstrap.py
python saltwick4/Source/build_assets.py
python saltwick4/Source/package_map.py 4062e5c959b4ea59ff4dee6c5f3863535a90db5c
```

Install Shapely 2 and Lupa with Lua 5.2 support to run the checks. The new geometry is measured in the actual deployed table coordinate system. The tests include the hull's connected faces, sightlines at the water and dry edges, and the existing deployment-to-console paths.

```sh
PYTHONPATH=recovery python s4/verify_assets.py
python s4/check_scene.py
python s4/controls.py
python s4/save_checks.py
blender -b --python-exit-code 2 -P s4/import_meshes.py
```

To render the preview with Blender and UnityPy, run the parent preview-console extractor, copy its two output files, and render the table. The Go installer uses the same staging and checksum process as R3.

```sh
python recovery/preview_console.py
cp saltwick3/Review/console-shaped.obj saltwick3/Review/console.png saltwick4/Review/
blender -b -t 8 --python-exit-code 2 -P s4/render.py
(cd saltwick4/Source/installer && go build -buildvcs=false -trimpath -o ../../Review/installer-test .)
(cd saltwick4/Source/installer && GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -buildvcs=false -trimpath -ldflags='-s -w' -o ../../bundle/Lobo-Saltwick-Harbour-R4-Setup.exe .)
python s4/make_delivery.py
python s4/check_installer.py
```
