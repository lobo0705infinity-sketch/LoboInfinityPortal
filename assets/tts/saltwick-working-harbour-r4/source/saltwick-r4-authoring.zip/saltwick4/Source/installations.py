"""Moored pump pontoon and four edge installations on Saltwick's working waterfront."""
from waterfront import HERE,Mesh,block,label,bent_wire,math,np
from mesh import ring_rect
from harbour import valve_wheel

def panel(g,p,size,mat,solid=False):
    g.box(p,size,mat,r=.012,b=.006,n=1,physical=solid)

def faceplate(g,x,y,h,w,d,side,texture):
    if side in ('left','right'):
        panel(g,(x,y,h),(.028,w+.045,d+.045),'iron')
        x+=.018 if side=='right'else -.018
    else:
        panel(g,(x,y,h),(w+.045,.028,d+.045),'iron')
        y+=.018 if side=='front'else -.018
    label(g,(x,y,h),w,d,side,texture)

def bitt(g,x,y,z):
    panel(g,(x,y,z+.018),(.245,.33,.036),'gatebeam')
    for dy in (-.093,.093):
        g.tube((x,y+dy,z+.026),(x,y+dy,z+.198),.054,'gatebeam',10)
        g.tube((x,y+dy,z+.185),(x,y+dy,z+.211),.067,'iron',12)

def pontoon():
    g=Mesh('tidal-pump-pontoon')
    # Sectional steel float with a raked bow. Its waterline sits in the existing mat.
    def rim(w,points,z):
        return [(x*w,y,z)for x,y in points]
    outline=[(-.8,-2.54),(.8,-2.54),(1,-2.18),(1,2.11),(.76,2.49),(-.76,2.49),(-1,2.11),(-1,-2.18)]
    g.rings([rim(.916,outline,-.034),rim(.978,outline,.18),rim(.978,outline,.34)],'hullblue',True,False)
    g.rings([rim(.983,outline,.34),rim(.983,outline,.387)],'darkwood',True,False)
    g.rings([rim(.971,outline,.387),rim(.971,outline,.413)],'grip',True,False)
    for side in (-1,1):
        g.tube((side*.976,-2.17,.26),(side*.976,2.11,.26),.018,'edge',7)
    # The enclosure and its matching collider provide the principal sight break.
    panel(g,(0,.10,.49),(1.91,2.42,.16),'iron',True)
    g.box((-.007,.10,1.48),(1.884,2.34,1.88),'fleetgreen',r=.046,b=.019,n=2,physical=True)
    g.box((-.007,.1,2.456),(1.95,2.421,.103),'zinc',r=.054,b=.015,n=2,physical=True)
    for y in (-.94,-.51,-.08,.35,.78,1.21):
        panel(g,(-.007,y,2.515),(1.888,.029,.022),'steel')
    # Inspection door, port number, acoustic louvers, conduit and flanged outlet.
    panel(g,(.05,-1.083,1.43),(.94,.041,1.63),'gatebeam')
    panel(g,(.05,-1.110,1.44),(.86,.035,1.54),'fleetcream')
    panel(g,(.05,-1.134,1.78),(.60,.024,.32),'sidelight')
    for dx in (-.31,.31):
        for h in (.82,1.91):g.tube((dx,-1.133,h),(dx,-1.157,h),.023,'bolt',7)
    panel(g,(.346,-1.158,1.29),(.113,.039,.033),'brass')
    faceplate(g,.02,-1.144,1.12,.59,.225,'rear','pontoon-id')
    for y in (-.51,.59):
        panel(g,(.941,y,1.54),(.036,.85,.80),'soot')
        for k in range(8):g.box((.960,y,1.233+.086*k),(.041,.766,.038),'steel',r=.006,n=1,rot=(0,12,0))
    for y in (-.63,.81):
        g.tube((-.944,y,.62),(-.944,y,2.31),.024,'iron',8)
    for x in (-.70,.67):
        g.tube((x,1.69,.421),(x,1.69,.52),.122,'zinc',12)
    g.tube((-.33,1.26,.86),(-.33,1.62,.86),.18,'fleetblue',16)
    g.tube((-.33,1.52,.86),(-.33,1.60,.86),.234,'zinc',16)
    for a in np.arange(8)*math.tau/8:
        x=-.33+.197*math.cos(a);z=.86+.197*math.sin(a)
        g.tube((x,1.50,z),(x,1.62,z),.023,'bolt',6)
    bent_wire(g,[(-.33,1.62,.86),(-.33,1.74,.84),(-.31,1.87,.77),(-.20,2.02,.57),(-.16,2.18,.48),(-.12,2.41,.43),(-.10,2.56,.22),(-.10,2.58,.028)],.128,'rubber',12)
    for y in (1.72,1.84):g.tube((-.33,y,.865),(-.33,y+.023,.865),.145,'iron',12)
    # An outboard guide pile lets the float rise with the tide. The pipe landing reaches the masonry.
    panel(g,(.897,1.40,1.30),(.206,.222,2.60),'gatebeam',True)
    panel(g,(.897,1.40,2.614),(.20,.212,.028),'brass')
    panel(g,(.852,1.39,.585),(.277,.331,.130),'steel')
    panel(g,(-.965,-.68,1.16),(.203,.47,2.32),'gatebeam',True)
    panel(g,(-.965,-.68,2.34),(.203,.48,.048),'zinc',True)
    for y in (-1.86,1.90):
        bitt(g,-.67,y,.416);bitt(g,.60,y,.416)
        # Fairlead on the wall and a short, sagging mooring line.
        panel(g,(-1.058,y+(.47 if y>0 else -.47),.77),(.026,.15,.165),'iron')
        v=.47 if y>0 else -.47
        bent_wire(g,[(-.67,y,.58),(-.79,y+v*.28,.565),(-.93,y+v*.63,.613),(-1.049,y+v,.77)],.027,'cable',7)
    for y in (-1.63,.91):
        for z in (.235,.49):
            panel(g,(-1.008,y,z),(.079,.29,.21),'rubber')
    # Rear deck access at the open end, with a drained coaming and drop handles.
    panel(g,(.04,-1.86,.451),(.86,.66,.072),'gatebeam')
    panel(g,(.04,-1.86,.500),(.78,.59,.028),'grip')
    for x in (-.23,.31):panel(g,(x,-1.83,.524),(.031,.21,.02),'brass')
    # Insulated exhaust and a hanging lifebuoy identify the plant from the quay.
    g.tube((-.69,.94,2.49),(-.69,.94,2.63),.145,'iron',14)
    g.tube((-.69,.94,2.59),(-.69,.94,2.96),.071,'steel',14)
    g.tube((-.69,.94,2.91),(-.69,.94,2.995),.117,'soot',14,r2=.082)
    for y in (-1.02,.02,1.19):panel(g,(.952,y,.90),(.037,.043,.59),'gatebeam')
    for y in (-1.95,-1.07,1.18,1.91):
        for h in (.169,.242):
            g.tube((.971,y,h),(.991,y,h),.018,'bolt',7)
    faceplate(g,.954,-.12,2.15,.73,.205,'right','pontoon-id')
    ring=g.at((.54,-1.19,1.68))
    panel(ring,(0,.035,.01),(.094,.11,.48),'iron')
    for sector in range(8):
        arc=np.linspace(sector*math.pi/4,(sector+1)*math.pi/4,4)
        bent_wire(ring,[(.239*math.cos(a),-.033,.239*math.sin(a))for a in arc],.064,'redoxide' if sector%2 else 'marinewhite',7)
    for i in range(3):
        g.hoop((-.28,-1.84,.530+i*.032),(0,0,1),.16-i*.013,.017,'teak',18,5)
    for x in (-.84,.84):
        for y in (-2.10,2.11):
            panel(g,(x,y,.450),(.086,.26,.028),'amber')
    return g

# Local X starts at the board edge and runs towards the host wall. The dimensions
# below come from the actual blind wall panels in the full table's standing state.
EDGE={
    'pump-bypass':(1.210,1.14,2.38,'fleetgreen','pump-name'),
    'ferry-lamp-store':(1.648,1.11,2.33,'fleetcream','lamp-name'),
    'net-loft-store':(2.618,2.35,2.48,'boardgreen','net-name'),
    'ice-plant':(2.42,2.02,2.32,'fleetcream','ice-name')}

def edge_store(slug):
    depth,width,height,finish,plate=EDGE[slug]
    root=Mesh(slug);g=root.at((-depth/2,0,0))
    # Opaque backs run flush to the map edge from ground level. Narrow connectors
    # at the far end fit the building's blind bay and preserve its other openings.
    neck=.48 if slug=='net-loft-store' else 0.
    body=depth-neck
    # Square footprint corners at the boundary prevent a narrow sight slit there.
    g.box((body/2,0,height/2),(body,width,height),finish,r=0,b=0,physical=True)
    if neck:
        g.box((body+neck/2,0,(height-.12)/2),(neck,.58,height-.12),'darkwood',r=0,b=0,physical=True)
        for y in (-.287,.287):panel(g,(body+neck/2,y,1.21),(neck,.029,.138),'iron')
    panel(g,(body/2,0,.065),(body,width+.046,.13),'wetstone')
    panel(g,(body/2,0,height+.025),(body,width+.080,.050),'zinc',True)
    if slug=='net-loft-store':
        for y in (-1,1):
            for i in range(12):
                panel(g,((i+.5)*body/12,y*(width/2+.014),height*.52),(body/12-.016,.034,height-.23),'boardgreen' if i%4 else 'teak')
            for h in (.31,1.94):
                panel(g,(body/2,y*(width/2+.039),h),(body-.07,.055,.073),'gatebeam')
        panel(g,(body*.49,-width/2-.054,1.03),(body*.70,.043,1.37),'darkwood')
        for i in range(2):panel(g,(body*(.32+.34*i),-width/2-.087,1.05),(body*.32,.046,1.32),'gatebeam')
        for x in (body*.46,body*.53):panel(g,(x,-width/2-.126,1.11),(.037,.039,.142),'brass')
        faceplate(g,body*.5,-width/2-.06,1.935,1.20,.29,'rear',plate)
    elif slug=='ice-plant':
        # Pair of finned heat exchangers on the service side of the insulated enclosure.
        for side in (-1,1):
            y=side*(width/2+.019)
            panel(g,(body/2,y,1.39),(body-.22,.050,1.36),'iron')
            for x in (.29*body,.71*body):
                g.tube((x,y,1.43),(x,y+.040*side,1.43),.40,'soot',20)
                for i in range(4):
                    a=i*math.pi/2;u=.21*math.cos(a);h=.21*math.sin(a)
                    g.box((x+u,y+.057*side,1.43+h),(.33,.025,.112),'steel',r=.028,n=2,rot=(0,-i*90-16,0))
                for rad in (.15,.266,.385):
                    g.hoop((x,y+.084*side,1.43),(0,1,0),rad,.012,'edge',20,4)
                for a in (0,math.pi/2):
                    g.tube((x-.382*math.cos(a),y+.091*side,1.43-.382*math.sin(a)),(x+.382*math.cos(a),y+.091*side,1.43+.382*math.sin(a)),.011,'iron',6)
        faceplate(g,body*.50,-width/2-.040,.455,1.01,.227,'rear',plate)
        for x in (.14*body,.86*body):
            panel(g,(x,0,height+.059),(.053,width-.10,.031),'edge')
    else:
        for y in (-1,1):
            sy=y*(width/2+.022)
            panel(g,(body*.49,sy,height*.52),(body*.82,.040,height*.81),'gatebeam')
            panel(g,(body*.49,sy+.026*y,height*.52),(body*.75,.027,height*.77),finish)
            for z in (.58,1.88):panel(g,(body*.16,sy+.049*y,z),(.092,.055,.057),'iron')
            panel(g,(body*.76,sy+.052*y,1.13),(.038,.053,.141),'brass')
        if slug=='pump-bypass':
            for i in range(7):panel(g,(body*.49,-width/2-.057,.48+.073*i),(body*.59,.034,.032),'iron')
            g.tube((.20,-width/2-.036,.16),(.20,-width/2-.036,.97),.036,'zinc',8)
        else:
            for x in (body*.28,body*.73):
                panel(g,(x,0,height+.085),(.099,.31,.067),'iron')
            for i in range(5):panel(g,(body*.49,-width/2-.057,.55+i*.092),(body*.59,.030,.033),'steel')
        faceplate(g,body*.5,-width/2-.057,1.64,min(body*.78,1.04),.29,'rear',plate)
    return root
