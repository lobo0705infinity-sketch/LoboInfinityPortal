"""Watertight double-skinned Marlow launch and the end-mounted ferry timetable."""
import math
from pathlib import Path
import sys
import numpy as np
from scipy.spatial import ConvexHull
HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE.parent / 'saltwick2/Source'))
import mesh
from mesh import Mesh
from fleet import block, label, box_beam
from props import bent_wire
from harbour import outward, bench, rivet, slipway as original_launch

STATIONS = np.array([(-2.52,.56,.18),(-2.32,.83,.13),(-1.96,.94,.04),(-1.18,1.02,0),(-.30,1.06,-.025),(.61,1.,-.02),(1.23,.83,.025),(1.78,.60,.12),(2.22,.322,.24),(2.54,.045,.41)])
LEVELS = np.linspace(0,1,7)

def skin(index,f,sign,inside=False):
    index %= len(STATIONS)
    x,r,sheer=STATIONS[index]
    width=r*np.interp(f,[0,.18,.43,.72,1],[.030,.42,.74,.94,1])
    height=.73+sheer*(.60+.40*f)+f*(1.13-.12*sheer)
    if inside:
        width-=min(.052,.30*width)
        x+=.060 if index==0 else -.044 if index==len(STATIONS)-1 else 0.
        height+=.081*(1-f)
    return np.array([x,sign*width,height])

def shell(g):
    for inside in (False,True):
        for sign in (-1,1):
            normal=(0,-sign,.2) if inside else (0,sign,-.2)
            for k,(low,high) in enumerate(zip(LEVELS,LEVELS[1:])):
                material=(('darkwood','darkwood','boardgreen','boardgreen','boardgreen','boardgreen') if inside else
                          ('redoxide','redoxide','hullblue','hullblue','hullblue','marinewhite'))[k]
                for i in range(len(STATIONS)-1):
                    pts=[skin(j,h,sign,inside) for j,h in [(i,low),(i+1,low),(i+1,high),(i,high)]]
                    outward(g,pts,normal,material)
        for i in range(len(STATIONS)-1):
            pts=[skin(j,0,s,inside) for j,s in [(i,-1),(i+1,-1),(i+1,1),(i,1)]]
            outward(g,pts,(0,0,1 if inside else -1),'darkwood' if inside else 'redoxide')
        for end,direction in [(0,-1),(-1,1)]:
            for lo,hi in zip(LEVELS,LEVELS[1:]):
                pts=[skin(end,h,s,inside) for h,s in [(lo,-1),(lo,1),(hi,1),(hi,-1)]]
                outward(g,pts,(direction*(-1 if inside else 1),0,0),'boardgreen' if inside else 'hullblue')
    for i in range(len(STATIONS)-1):
        for sign in (-1,1):
            pts=[skin(j,1,sign,inn) for j,inn in [(i,False),(i+1,False),(i+1,True),(i,True)]]
            outward(g,pts,(0,0,1),'teak')
    for end in (0,-1):
        pts=[skin(end,1,sign,inn) for sign,inn in [(-1,False),(1,False),(1,True),(-1,True)]]
        outward(g,pts,(0,0,1),'teak')

def lining(x,f,sign):
    pts=np.array([skin(i,f,sign,True)for i in range(len(STATIONS))])
    return np.array([x,np.interp(x,pts[:,0],pts[:,1]),np.interp(x,pts[:,0],pts[:,2])])

def clip_y(poly,edge,greater):
    result=[]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        va=(a[1]-edge)*(1 if greater else -1);vb=(b[1]-edge)*(1 if greater else -1)
        if va>=0:result.append(a)
        if va*vb<0:result.append(a+(b-a)*va/(va-vb))
    return result

def install_sole(g):
    z=1.27
    sides=[]
    for s in (-1,1):
        line=[]
        for i in range(len(STATIONS)):
            levels=np.linspace(0,1,80);a=np.array([skin(i,f,s,True)for f in levels]);y=np.interp(z,a[:,2],np.abs(a[:,1]))
            line.append(np.array([a[0,0],s*max(.004,y-.016)]))
        sides.append(line)
    outline=sides[0]+sides[1][::-1]
    for j in range(-5,6):
        y=j*.162;poly=clip_y(clip_y(outline,y-.078,True),y+.078,False)
        if len(poly)<3:continue
        lo=[(x,v,z-.035)for x,v in poly];hi=[(x,v,z)for x,v in poly]
        g.rings([lo,hi],('teak','plywood','teak','teak','plywood')[j%5],smooth=False)

def launch():
    g=Mesh('marlow-launch')
    shell(g)
    for s in (-1,1):
        for k in range(1,7):
            f=k/6
            pts=[skin(i,f,s)+[0,s*.009,.003] for i in range(len(STATIONS))]
            bent_wire(g,pts,.031 if k==6 else .011,'teak' if k==6 else 'redoxide' if k<=2 else 'hullblue',7)
        for x in (-2.10,-1.67,-1.17,-.67,-.17,.36,.83,1.27,1.63):
            pts=[lining(x,f,s)+np.array([0,-s*.014,.008]) for f in np.linspace(.24,.955,11)]
            bent_wire(g,pts,.030,'teak',6)
        for f in (.57,.79):
            path=[skin(i,f,s,True)+[0,-s*.008,0] for i in range(len(STATIONS))]
            bent_wire(g,path,.012,'boardgreen',6)
    install_sole(g)
    for x in (-1.61,.67):
        a=lining(x,.745,1);half=a[1]-.015;h=a[2]
        block(g,(x,0,h),(.309,2*half,.080),'teak',.014)
        for s in (-1,1):
            block(g,(x,s*(half-.098),h-.073),(.29,.191,.078),'darkwood',.008)
            for dx in (-.090,.09):
                g.tube((x+dx,s*(half-.091),h+.038),(x+dx,s*(half-.091),h+.043),.016,'brass',8)
    # Fit the decking to the inner sheer and close the stem immediately behind it.
    xs=(1.57,1.78,2.0,2.22,2.496)
    for a,b in zip(xs,xs[1:]):
        pts=[lining(x,.865,s) for x,s in [(a,-1),(b,-1),(b,1),(a,1)]]
        outward(g,pts,(0,0,1),'boardgreen')
    start=[lining(xs[0],.865,s)for s in (-1,1)]
    outward(g,[start[0]-[0,0,.056],start[1]-[0,0,.056],start[1],start[0]],(-1,0,0),'boardgreen')
    for x in xs[1:-1]:
        a,b=[lining(x,.865,s)+[0,0,.004] for s in (-1,1)]
        g.tube(a,b,.006,'darkwood',5)
    # Retain the original named stern, engine cover, tiller, and metal rail carriage.
    old=original_launch()
    for surface in old.surfaces:
        verts,_,_,mat,_,_=surface
        is_carriage=max(verts[:,2])<1.20 and (np.ptp(verts[:,0])<.56 or mat in ('redoxide','darkwood')) and mat not in ('hullblue',)
        if (is_carriage and (max(verts[:,2])<.81 or min(verts[:,2])<.58 or (mat=='darkwood' and min(verts[:,2])>.97))) or mat in ('canvas','cable','boatname') or max(verts[:,0])< -2.48 and mat in ('brass','hullblue'):
            g.surfaces.append(surface)
    g.hulls=old.hulls
    return g

def timetable():
    from harbour import ferry
    # The original free-standing sign is a detached cluster. Only this cluster is replaced.
    old=ferry();g=Mesh('ferry-timetable')
    g.surfaces=[s for s in old.surfaces if s[0][:,1].max()>-1.70]
    g.hulls=[p for p in old.hulls if p[:,1].max()>-1.70]
    def solid(p,d,m,r=.012):g.box(p,d,m,r=r,b=r*.55,n=1,physical=True)
    def trim(p,d,m):g.box(p,d,m,r=.009,b=.005,n=1)
    for x in (-1.72,-.14):
        solid((x,-2.59,1.17),(.103,.12,2.34),'gatebeam')
        trim((x,-2.59,.065),(.18,.21,.13),'washedconcrete')
    for i in range(10):g.box((-.9275,-2.60,.202+i*.218),(1.655,.094,.217),'boardgreen',r=.004,b=.002,n=1)
    g.solid([(x,y,h) for x in (-1.755,-.100) for y in (-2.647,-2.553) for h in (.093,2.275)])
    solid((-.930,-2.60,2.36),(1.77,.17,.097),'teak')
    for h in (.26,1.98):trim((-.9275,-2.53,h),(1.68,.067,.064),'gatebeam')
    # All hardware is on the back. Both original enamel artworks face the approach.
    q=g.at((-1.92,-3.22,0))
    for y in (-.662,.662):
        block(q,(.087,y,1.066),(.096,.094,2.12),'gatebeam',.012,True)
        block(q,(.087,y,.075),(.151,.153,.145),'wetstone',.008)
    block(q,(0,0,1.44),(.101,1.47,1.66),'gatebeam',.017,True)
    label(q,(-.057,0,1.44),1.25,1.47,'left','ferryboard')
    block(q,(0,0,2.343),(.116,1.66,.288),'gatebeam',.020,True)
    label(q,(-.065,0,2.344),1.51,.251,'left','ferrysign')
    for h in (1.05,2.10):
        block(q,(.104,.62,h),(.198,.14,.072),'iron',.006)
    return g
