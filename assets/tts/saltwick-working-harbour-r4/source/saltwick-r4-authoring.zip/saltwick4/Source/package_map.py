"""Apply the waterfront fixes to the original playable R3 save and Stage bag."""
import json,re,sys
from pathlib import Path
from copy import deepcopy
from datetime import datetime
from zoneinfo import ZoneInfo
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT.parent/'saltwick3/Release'
PREFIX='assets/tts/saltwick-working-harbour-r4/'
TAG='LoboMap:1002d9'
NEW={
 'f51ae0':('tidal-pump-pontoon','Port Water Services | Moored pump pontoon','The enclosed pump house interrupts the water lane. The ferry steps and cafe door remain accessible.',(23.0,4.,9.40),0),
 'f51ae1':('pump-bypass','Tide Works | Bypass valve enclosure','The bypass valves are housed against the blind end of the pump house.',(-8.98,4.,24-1.210/2),90),
 'f51ae2':('ferry-lamp-store','Saltwick Ferry | Lamp store','Spare lamps and signal fittings occupy a locker against the crew office.',(10.24,4.,24-1.648/2),90),
 'f51ae3':('net-loft-store','Net Repair Yard | Dry net store','A timber store for dry nets connects to the solid masonry pier between the shed windows.',(-24+2.618/2,4.,15.36),0),
 'f51ae4':('ice-plant','Cold Stores | Ice plant condenser','The paired fans serve the ice dispatch hopper beside the net yard.',(-24+2.42/2,4.,-9.82),0)}
def compact(v):return json.dumps(v,ensure_ascii=False,separators=(',',':'))
def read(p):return json.loads(p.read_bytes())
def build(sha):
    assert re.fullmatch('[a-f0-9]{40}',sha)
    def url(f):
        assert (ROOT/'Assets'/f).exists(),f
        return 'https://raw.githubusercontent.com/lobo0705infinity-sketch/LoboInfinityPortal/'+sha+'/'+PREFIX+f
    def update(items):
        ids={v['GUID']:v for v in items}
        boat=ids['f5103b'];boat['CustomMesh']['MeshURL']=url('marlow-launch.obj')
        timetable=ids['f5101f'];timetable['CustomMesh'].update(MeshURL=url('ferry-timetable.obj'),ColliderURL=url('ferry-timetable-col.obj'))
        for guid,(slug,name,description,xyz,yaw)in NEW.items():
            assert guid not in ids
            o=deepcopy(ids['f51ad4']);o.update(GUID=guid,Nickname=name,Description=description,GMNotes=TAG,Tags=[TAG],Locked=True)
            o['Transform'].update(posX=xyz[0],posY=xyz[1],posZ=xyz[2],rotX=0.,rotY=yaw,rotZ=0.,scaleX=1.,scaleY=1.,scaleZ=1.)
            o['CustomMesh'].update(MeshURL=url(slug+'.obj'),ColliderURL=url(slug+'-col.obj'),DiffuseURL=url('harbour-plant.jpg'),NormalURL=url('harbour-plant-normal.png'))
            items.append(o)
        owner=ids['f5100d'];s=owner['LuaScript'];m=re.search(r'^ local config=JSON.decode\((.+)\)$',s,re.M);cfg=json.loads(json.loads(m[1]))
        cfg['guids'].update(dict.fromkeys(NEW,True));owner['LuaScript']=s[:m.start(1)]+json.dumps(compact(cfg))+s[m.end(1):]
    table=read(BASE/'Play-Table.json');stage=read(BASE/'Saltwick-Floodgate.json');bag=stage['ObjectStates'][0]
    update(table['ObjectStates']);update(bag['ContainedObjects'])
    appended=['--'+g+','+','.join(f'{k:.10f}'for k in (*pos,0.,yaw,0.))for g,(_,__,___,pos,yaw)in NEW.items()]
    bag['LuaScript']=bag['LuaScript'].rstrip('\r\n')+'\r\n'+'\r\n'.join(appended)+'\r\n'
    bag['Nickname']=bag['Nickname'].replace('Working Harbour R3','Working Harbour R4')
    bag['Description']='Working Harbour R4 playtest. Drop this bag on the Infinity Stage.'
    table['SaveName']=table['SaveName'].replace('Working Harbour R3','Working Harbour R4');stage['SaveName']=bag['Nickname']
    now=datetime.now(ZoneInfo('America/New_York'));out=ROOT/'Release';out.mkdir(exist_ok=True)
    for name,v in [('Play-Table.json',table),('Saltwick-Floodgate.json',stage)]:
        v.update(Date=now.strftime('%m/%d/%Y %I:%M:%S %p'),EpochTime=int(now.timestamp()));(out/name).write_text(compact(v))
if __name__=='__main__':build(sys.argv[1])
