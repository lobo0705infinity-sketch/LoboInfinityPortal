from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import numpy as np
from scipy.ndimage import gaussian_filter
from waterfront import HERE,mesh,launch,timetable
from installations import pontoon,edge_store,EDGE

ATLAS=HERE.parent/'saltwick2/Assets'
OUT=HERE/'Assets'
LABELS={
    'pontoon-id':('fleetmark','P-04','SALTWICK WATER'),
    'pump-name':('fittermark','BYPASS','TIDE WORKS'),
    'lamp-name':('watermark','LAMP STORE','SALTWICK FERRY'),
    'net-name':('fleetplate2','NET STORE','LOFT No. 2'),
    'ice-name':('fleetplate3','ICE PLANT','COLD STORES')}
def lettering(title,sub,i):
    w,h=720,220
    rng=np.random.default_rng(4012+i)
    noise=gaussian_filter(rng.normal(0,9,(h,w)),.69)
    base=np.array([(58,79,83),(55,79,71),(55,75,88),(59,79,74),(66,79,86)][i])
    im=Image.fromarray(np.uint8(np.clip(base+noise[:,:,None],0,255)))
    d=ImageDraw.Draw(im);ink=(226,219,191)
    d.rounded_rectangle((8,8,w-9,h-9),radius=11,outline=ink,width=3)
    fonts='/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed'
    ft=ImageFont.truetype(fonts+'-Bold.ttf',95)
    d.text((w/2,84),title,font=ft,anchor='mm',fill=ink,stroke_width=0)
    d.text((w/2,170),sub,font=ImageFont.truetype(fonts+'.ttf',43),anchor='mm',fill=ink)
    return im.resize((256,256),Image.Resampling.LANCZOS)
def paint():
    diffuse=Image.open(ATLAS/'harbour-diffuse.jpg').convert('RGB')
    normal=Image.open(ATLAS/'harbour-normal.png').convert('RGB')
    for i,(key,(slot,title,sub))in enumerate(LABELS.items()):
        ix=mesh.INDEX[slot];mesh.INDEX[key]=ix;xy=(ix%8*256,ix//8*256)
        diffuse.paste(lettering(title,sub,i),xy);normal.paste(Image.new('RGB',(256,256),(128,128,255)),xy)
    diffuse.save(OUT/'harbour-plant.jpg',quality=95,optimize=True,subsampling=0)
    normal.save(OUT/'harbour-plant-normal.png',optimize=True)
def vertical_scale(g,scale):
    for points,faces,normals,mat,uv,smooth in g.surfaces:
        points[:,2]*=scale;normals[:,2]/=scale;normals[:]/=np.linalg.norm(normals,axis=1)[:,None]
    for points in g.hulls:points[:,2]*=scale
    return g
def build():
    OUT.mkdir(parents=True,exist_ok=True);mesh.UNBAKED=mesh.OUT=OUT
    paint()
    boat=launch();boat.write()
    # The rail carriage and hull's original collision volumes have the same geometry.
    (OUT/'marlow-launch-col.obj').unlink()
    timetable().write()
    # The pump and its shoreside connection must screen a standing silhouette at high tide.
    vertical_scale(pontoon(),1.18).write()
    for slug in EDGE:
        height_scale=1.16 if slug in ('pump-bypass','net-loft-store') else 1.0
        vertical_scale(edge_store(slug),height_scale).write()
if __name__=='__main__':build()
