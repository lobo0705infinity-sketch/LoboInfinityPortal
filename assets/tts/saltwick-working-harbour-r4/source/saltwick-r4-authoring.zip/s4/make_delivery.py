"""Assemble the ready table, Stage object and Windows installer after saving review renders."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont,ImageOps
import json,hashlib,zipfile,sys
root=Path('saltwick4')
rel=root/'Release';rev=root/'Review';bundle=root/'bundle';delivery=root/'delivery'
name='Lobo-Saltwick-Floodgate-Working-Harbour-R4-Playtest.zip'
def writezip(dest,items):
 with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for k,v in sorted(items.items()):z.writestr(k,v)
def previews():
 with Image.open(rev/'overview.png')as im:
  im.convert('RGB').resize((640,533),Image.Resampling.LANCZOS).save(rel/'Preview.png',optimize=True)
 canvas=Image.new('RGB',(1548,1256),(27,39,42));draw=ImageDraw.Draw(canvas)
 font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed-Bold.ttf',24)
 def photo(asset,label,x,y,w,h):
  with Image.open(rev/(asset+'.png'))as src:
   im=ImageOps.fit(src.convert('RGB'),(w,h),method=Image.Resampling.LANCZOS)
   canvas.paste(im,(x,y))
  draw.text((x+1,y+h+9),label,font=font,fill=(233,229,209))
 photo('water','Ferry waterfront and moored pump pontoon',16,16,1008,414)
 photo('pump','Pump deckhouse',1040,16,492,414)
 for i,(asset,title)in enumerate([('net','Net store'),('ice','Ice plant'),('bypass','Pump bypass'),('lamp','Ferry lamp store')]):
  photo(asset,title,16+383*i,487,367,230)
 photo('boat','Marlow on the slipway',16,771,494,426)
 photo('sign','Ferry timetable',527,771,494,426)
 photo('overview','Saltwick Floodgate',1038,771,494,426)
 canvas.save(rel/'Saltwick-R4-Terrain.jpg',quality=93,optimize=True,subsampling=0)

def assemble():
 previews()
 data={n:(rel/n).read_bytes()for n in ('Play-Table.json','Saltwick-Floodgate.json','Preview.png')}
 data['manifest.json']=json.dumps({n:hashlib.sha256(v).hexdigest()for n,v in data.items()},sort_keys=True).encode()
 writezip(bundle/'Files/payload.zip',data)
 files={'Install.cmd':(bundle/'Install.cmd').read_bytes(),'Lobo-Saltwick-Harbour-R4-Setup.exe':(bundle/'Lobo-Saltwick-Harbour-R4-Setup.exe').read_bytes(),'Files/payload.zip':(bundle/'Files/payload.zip').read_bytes(),'Readme.txt':(bundle/'Readme.txt').read_bytes()}
 writezip(delivery/name,files);print((delivery/name).stat().st_size,'bytes')
if __name__=='__main__':assemble()
