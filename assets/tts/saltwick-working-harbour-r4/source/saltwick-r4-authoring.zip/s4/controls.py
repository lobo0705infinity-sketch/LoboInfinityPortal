import sys,re,json,copy
from pathlib import Path
root=Path.cwd()
std=root/'controls/tts-map-controls-standard';sys.path.insert(0,str(std))
import validate_release,test_standard
from test_standard import RealWorld
from test_zones import py,check_render
from mission_links import assignment
ref=root/'saltwick4/Review/r7-approved';ref.mkdir(exist_ok=True)
stage=root/'saltwick4/Release/Saltwick-Floodgate.json'
def bag(path):return json.loads(path.read_bytes())['ObjectStates'][0]
def owner(b):return next(o for o in b['ContainedObjects']if o['GUID']=='f5100d')
previous=owner(bag(root/'saltwick3/Release/Saltwick-Floodgate.json'))['LuaScript'];current=bag(stage)
source=json.loads(json.loads(re.search(r'local loboLifeBrokerData=(".*")',previous)[1]))['LuaScript']
(ref/'standard-broker.lua').write_text(source)
validate_release.ROOT=test_standard.ROOT=ref
start=previous.index(' -- The room starts with two empty launch buttons');end=previous.index(' local function mount()',start)
validate_release.LOADER=previous[start:end].rstrip();report=validate_release.validate(stage)
class Room(RealWorld):
 def xml_root(self):
  node=super().xml_root()
  for elem in node.iter():
   for key,v in self.attr_updates.get(elem.get('id'),{}).items():elem.set(key,v)
  return node
 def panel(self,color='White'):
  group=color if color in ('Blue','Red')else 'Other'
  return self.xml_root().find(".//*[@id='loboMapDrawerV1_"+group+"_compact']")
 def button(self,suffix,color='White'):
  p=self.panel(color);return p.find(".//*[@id='"+p.get('id')+"_"+suffix+"']")
 def click(self,suffix,color='White'):
  button=self.button(suffix,color);assert button is not None and button.get('interactable')!='false',suffix
  self.invoke(button,color)
w=Room(current);w.attr_updates={}
def set_xml(text,*unused):
 w.xml=text;w.attr_updates.clear()
def set_attr(key,name,v,*unused):
 w.attr_updates.setdefault(key,{})[name]=str(v)

for rt,g in w.run.values():
 g.UI.setXml=set_xml;g.UI.setAttribute=set_attr
 rt.execute('''
 UI.getAttribute=function(id,attr) if attr=="allowDragging" then return "true" else return "" end end
 UI.setValue=UI.setValue or function()end
 local all=getAllObjects;getObjects=function() local copy={} for i,v in ipairs(all()) do copy[i]=v end copy[#copy+1]={getName=function()return "Lobo Infinity Order Panel R4" end,hasTag=function(k)return k=="LoboInfinityOrderPanel" end};return copy end
 local original=getObjectsWithTag
 local function existing(n) return {getGUID=function()return n end,isDestroyed=function()return false end,getVar=function(key) if key=='LOBO_ARMY_LAUNCHER_REVISION' then return 7 end if key=='LOBO_MOVE_STATES_REVISION' then return 1 end if key=='LOBO_ORDER_PANEL_REVISION' then return 4 end return true end,call=function()end,addTag=function()end,hasTag=function()return true end,getPosition=function()return{x=30,y=1,z=0}end,setPosition=function()end,setRotation=function()end,setLock=function()end} end
 getObjectsWithTag=function(n) if n=='LoboArmyLauncherBlue' or n=='LoboArmyLauncherRed' or n=='LoboOrderPanel' then return {existing(n)} end return original(n) end
 ''')
w.load({owner(current)['GUID']:owner(current)['LuaScriptState']})
for color in ('Red','Blue','White'):
 frame=w.xml_root().find(".//*[@id='loboMapDrawerV1_"+(color if color!='White'else'Other')+"_frame']")
 assert frame.get('allowDragging')=='true' and frame.get('returnToOriginalPositionWhenReleased')=='false'
 for suffix in ['mission','turn','dz_off','dz_0','dz_4','dz_8','dzcolor','excolor','grid','scoring','bg_day','bg_night','bg_off','clear']:
  b=w.button(suffix,color);assert b is not None and b.get('interactable')!='false',(suffix,color)
 messages=[]
 for _,g in w.run.values():
  g.printToColor=lambda msg,seat,*unused:messages.append(('chat',seat,msg))
  for seat in ['Blue','Red','White']:g.Player[seat].showInputDialog=lambda title,value,cb,s=seat:messages.append(('dialog',s,value))
 w.click('mission',color)
 url=assignment(current)[1];assert messages==[('chat',color,url),('dialog',color,url)],messages
for mode in ['day','night','off']:
 w.click('bg_'+mode);assert w.button('bg_'+mode).get('color')=='#82BCCDFF',(mode,w.button('bg_'+mode).attrib,py(w.call('loboStandardState')),getattr(w,'background_url',''));assert w.background_url.startswith('https://')
for key in ['dz_0','dz_4','dz_8','dz_off']:w.click(key)
assert not any(x.get('loboZoneKind')=='deployment'for x in w.source())
w.click('dz_0');check_render(w)
for expected in [True,False]:
 w.click('grid');assert py(w.call('loboStandardState'))['grid']==expected
w.click('scoring');w.click('scoring')
old={k:copy.deepcopy(o['Transform'])for k,o in w.items.items()}
w.click('turn');assert py(w.call('loboStandardState'))['flipped']
new=[k for k in old if k.startswith('f51ae')]
for k in new:
 for axis in ('posX','posZ'):assert abs(old[k][axis]+w.items[k]['Transform'][axis])<.002
w.click('dz_4');check_render(w)
for kind,btn,c in [('deployment','dzcolor',4),('exclusion','excolor',7)]:
 w.click(btn);rt,g=w.run[w.primary['GUID']]
 g.loboZonePickColor(rt.table_from({'color':'White'}),'','loboMission_ZoneColors_'+w.primary['GUID']+'_pick_'+kind+'_'+str(c));w.advance(3)
 assert w.tables[w.mat]['LoboZoneColorsR1'][kind]==c
w.click('turn');assert not py(w.call('loboStandardState'))['flipped']
for key,t in old.items():
 newt=w.items[key]['Transform']
 assert all(abs(t[k]-newt[k])<.00001 for k in ['posX','posY','posZ']),key
 assert abs((newt.get('rotY',0)-t.get('rotY',0)+180)%360-180)<.00001,key
w.click('clear')
assert all(k in w.dead for k in new),new
assert not w.errors
report.update(seats=['Red','Blue','White'],mission=url,rotation_and_clear_new_roots=len(new),palette=True,standard_controls=True)
(root/'saltwick4/Review/lua-results.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
