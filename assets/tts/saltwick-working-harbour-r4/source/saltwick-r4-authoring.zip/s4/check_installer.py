from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile
from io import BytesIO
import hashlib,json,subprocess,struct
from make_delivery import root,rev,delivery,rel,name
def assert_save(actual,release):
 assert actual.read_bytes()==(rel/release).read_bytes(),actual
def run(folder,payload):
 return subprocess.run([str((rev/'installer-test').resolve()),'-no-pause','-tts-root',str(folder),'-payload',str(payload)],capture_output=True,text=True)
with TemporaryDirectory()as folder:
 scratch=Path(folder)
 with ZipFile(delivery/name) as dist:
  assert dist.testzip()is None;assert set(dist.namelist())=={'Install.cmd','Lobo-Saltwick-Harbour-R4-Setup.exe','Files/payload.zip','Readme.txt'}
  dist.extractall(scratch)
 exe=(scratch/'Lobo-Saltwick-Harbour-R4-Setup.exe').read_bytes();assert exe[:2]==b'MZ'
 offset=struct.unpack_from('<I',exe,0x3c)[0];assert exe[offset:offset+4]==b'PE\0\0' and struct.unpack_from('<H',exe,offset+4)[0]==0x8664
 payload=scratch/'Files/payload.zip'
 with ZipFile(payload)as z:
  assert z.testzip()is None;parts={k:z.read(k)for k in z.namelist()};checks=json.loads(parts['manifest.json'])
 for key,h in checks.items():
  assert parts[key]==(rel/key).read_bytes() and hashlib.sha256(parts[key]).hexdigest()==h
 fresh=scratch/'clean';one=run(fresh,payload);assert one.returncode==0,one.stderr
 assert_save(fresh/'Saves/TS_Save_1.json','Play-Table.json');assert_save(fresh/'Saves/TS_Save_1.png','Preview.png')
 custom=scratch/'custom-root with spaces';saves=custom/'Saves';saves.mkdir(parents=True)
 (saves/'TS_Save_1.json').write_text('existing');(saves/'TS_Save_2.png').write_text('orphan')
 for slot,p in [(3,custom),(4,saves)]:
  proc=run(p,payload);assert proc.returncode==0,proc.stderr
  for ext,nm in [('json','Play-Table.json'),('png','Preview.png')]:assert_save(saves/f'TS_Save_{slot}.{ext}',nm)
 assert (saves/'TS_Save_1.json').read_text()=='existing'and (saves/'TS_Save_2.png').read_text()=='orphan'
 bags=list((saves/'Saved Objects').glob('*/Saltwick-Floodgate.json'));assert len(bags)==2
 for bag in bags:assert_save(bag,'Saltwick-Floodgate.json');assert_save(bag.with_suffix('.png'),'Preview.png')
 target=scratch/'parallel'
 from concurrent.futures import ThreadPoolExecutor
 with ThreadPoolExecutor(3) as pool:ps=list(pool.map(lambda _:run(target,payload),range(3)))
 assert all(p.returncode==0 for p in ps),[p.stderr for p in ps]
 for i in (1,2,3):assert_save(target/f'Saves/TS_Save_{i}.json','Play-Table.json')
 bad=scratch/'bad.zip'
 with ZipFile(bad,'w')as z:
  for k,v in parts.items():z.writestr(k,b'broken'if k=='Play-Table.json'else v)
 fail=run(custom,bad);assert fail.returncode!=0 and 'checksum' in fail.stderr and not (saves/'TS_Save_5.json').exists()
 partial=scratch/'partial';(partial/'Saves').mkdir(parents=True);(partial/'Saves/Saved Objects').write_text('original')
 assert run(partial,payload).returncode!=0 and not list((partial/'Saves').glob('TS_Save*'))
 assert json.loads(parts['Play-Table.json'])['SaveName']=='Saltwick Floodgate - Working Harbour R4 - Area of Interest'
result={'platform_executable':'Windows x86-64','archive_sha256':hashlib.sha256((delivery/name).read_bytes()).hexdigest(),'unpacked_content_hashes':checks,'cases':['first install','occupied slot','orphan thumbnail','redirected Saves path','repeat install','concurrent install','corrupt payload','rollback after write error']}
(rev/'installer-results.json').write_text(json.dumps(result,indent=1))
print(json.dumps(result))
