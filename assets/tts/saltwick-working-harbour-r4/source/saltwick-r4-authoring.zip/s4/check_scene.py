"""Measure the three R4 sightlines on the deployed table and audit the repaired models."""
from pathlib import Path
from collections import Counter
import json, itertools, sys
import numpy as np
sys.path.insert(0,'recovery')
import geometry as geo
from common import local as inherited
TEST_ROOT=Path('saltwick4')
def local(u):return TEST_ROOT/'Assets'/u.split('/')[-1] if '/saltwick-working-harbour-r4/'in u else inherited(u)
def reset(scene):
    geo.objects={o['GUID']:o for o in scene['ObjectStates'] if geo.TAG in o.get('Tags',[]) and o.get('CustomMesh')}
    geo.model.cache_clear()
def scene(name):return json.loads((Path(name)/'Release/Play-Table.json').read_bytes())
def first(a,b,ids=None):
    hits=geo.sight(a,b,ids);return hits[0][1] if hits else None
def pair(lane,d1,d2,h1,h2):
    if lane=='left':return ((22.8,4+h1,24-d1),(-22.8,4+h2,24-d2))
    if lane=='bottom':return ((-24+d1,4+h1,23.0),(-24+d2,4+h2,-23.0))
    return ((d1,4+h1,3.12),(d2,4+h2,21.0))
def check_shell():
    sys.path.insert(0,'saltwick4/Source')
    from waterfront import Mesh,shell
    g=Mesh('hull');shell(g);edges=Counter();directions=Counter();volume=0
    def key(p):return tuple(round(float(x),6) for x in p)
    for pts,faces,*_ in g.surfaces:
        for face in faces:
            q=[key(pts[i])for i in face]
            for j in range(1,len(q)-1):
                tri=[q[0],q[j],q[j+1]]
                for a,b in zip(tri,tri[1:]+tri[:1]):
                    edges[tuple(sorted((a,b)))]+=1;directions[a,b]+=1
                volume+=np.dot(tri[0],np.cross(tri[1],tri[2]))/6
    assert set(edges.values())=={2} and all(v==directions[b,a] for (a,b),v in directions.items()) and volume>0
    # Confirm every triangle of the tested shell is in the exact exported OBJ.
    p,faces=geo.read(TEST_ROOT/'Assets/marlow-launch.obj')
    t=p*np.array([-1,1,1]);t=t[:,[0,2,1]]
    exported={tuple(sorted(key(v) for v in t[f])) for f in faces}
    for pts,faces,*_ in g.surfaces:
        for f in faces:
            for a in range(1,len(f)-1):
                assert tuple(sorted(key(pts[i])for i in (f[0],f[a],f[a+1]))) in exported
    return len(edges)
def report():
    geo.ROOT=TEST_ROOT;geo.local=local
    reset(scene('saltwick3'));prior={}
    h=40/25.4
    for lane,offsets in [('left',[.05,.49]),('bottom',[.05,.49]),('water',[22.48,23.25,23.5])]:
        for d in offsets:
            a,b=pair(lane,d,d,h,h);prior[lane+' '+str(d)]=first(a,b)
    assert all(x is None for x in prior.values()),prior
    reset(scene('saltwick4'))
    samples={};both={'left':('f51ae1','f51ae2'),'bottom':('f51ae3','f51ae4'),'water':('f51ae0',)}
    for lane in ('left','bottom','water'):
        ds=(.001,.065,.49,.98,1.17) if lane!='water' else (21.95,22.01,22.25,22.48,22.80,23.15,23.50,23.82,23.96,23.996)
        modes=[(.21,.21),(.72,.72),(h,h),(2.,2.),(2.64,2.64),(.55,h),(1.9,.75)]
        for d1,d2,(h1,h2)in itertools.product(ds,ds,modes):
            a,b=pair(lane,d1,d2,h1,h2);blocker=first(a,b,both[lane]);assert blocker,(lane,d1,d2,h1,h2)
        samples[lane]=len(ds)**2*len(modes)
        if lane!='water':
            for d1,d2 in itertools.product((.002,.49,.97),repeat=2):
                a,b=pair(lane,d1,d2,h,h)
                assert all(first(a,b,[uid])==uid for uid in both[lane]),(lane,d1,d2)
    # Verify the pontoon leaves both the door and the ferry stair-to-gangway clear.
    pontoon=geo.model('f51ae0',False)[0].reshape(-1,3);assert pontoon[:,2].max()<13.40 and pontoon[:,2].min()>2.11
    for uid in ('f51ae0','f51ae1','f51ae2','f51ae3','f51ae4'):
        for phys in (False,True):
            tri=geo.model(uid,phys)[0];assert np.abs(tri[:,:,[0,2]]).max()<=24.00001,(uid,phys,np.abs(tri[:,:,[0,2]]).max())
        if uid in both['left'] or uid in both['bottom']:
            for phys in (False,True):
                t=geo.model(uid,phys)[0]
                edge=t[:,:,2].max() if uid in both['left']else -t[:,:,0].min()
                assert abs(edge-24)<.00001,(uid,phys)
    # Cast through the ends and centre of the four departure rows and the header,
    # using oblique approaches from both sides at miniature and overhead heights.
    sign=0
    for h,half,xface in [(1.04,.57,.057),(1.25,.57,.057),(1.47,.57,.057),(1.70,.57,.057),(1.98,.57,.057),(2.343,.70,.065)]:
        for across,az,eye in itertools.product((-.97,0,.97),(-.54,0,.54),(1.50,2.65,4.30)):
            target=(11.63-1.92-xface-.0002,4+h,12.45-3.22+across*half)
            start=(target[0]-1.88,4+eye,target[2]+az*1.88)
            assert first(start,target,['f5101f']) is None,(start,target);sign+=1
    result={'old_full_length_lanes':prior,'blocked_mesh_rays':samples,'watertight_launch_edges':check_shell(),'clear_timetable_rays':sign}
    (TEST_ROOT/'Review/r4-geometry.json').write_text(json.dumps(result,indent=1));print(result,flush=True)
    geo.main()
if __name__=='__main__':report()
