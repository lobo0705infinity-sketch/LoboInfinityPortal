"""Fetch the immutable parent playtest and its authored dependencies into a new checkout."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from io import BytesIO
import json,sys,subprocess,zipfile
from urllib.request import urlopen
base=Path(__file__).resolve().parent.parent
parent='https://raw.githubusercontent.com/lobo0705infinity-sketch/LoboInfinityPortal/f23d51ba555e147a5c92099e252e327322387d75/assets/tts/saltwick-working-harbour-r3/'
for name in ('saltwick3/Assets','saltwick3/Review','saltwick3/Release','saltwick4/Assets','saltwick4/Release','saltwick4/Review','saltwick4/bundle/Files','saltwick4/delivery','recovery'):
    (base/name).mkdir(exist_ok=True,parents=True)
with zipfile.ZipFile(BytesIO(urlopen(parent+'source/saltwick-r3-authoring.zip').read()))as archive:
    for f in archive.namelist():
        if f.startswith(('saltwick3/','recovery/')):archive.extract(f,base)
sys.path.insert(0,str(base/'recovery'))
from baseline import write,links
subprocess.run([sys.executable,'recovery/baseline.py'],cwd=base,check=True)
subprocess.run([sys.executable,'recovery/extras.py'],cwd=base,check=True)
for name in ('Play-Table.json','Saltwick-Floodgate.json'):
    write(parent+'release/'+name,base/'saltwick3/Release'/name)
p=base/'saltwick3/Release/Saltwick-Floodgate.json';urls={u for u in links(json.loads(p.read_bytes())) if 'saltwick-working-harbour-r3/' in u}
with ThreadPoolExecutor(8)as pool:list(pool.map(lambda u:write(u,base/'saltwick3/Assets'/u.rsplit('/',1)[-1]),urls))
