@echo off
"%~dp0Lobo-Saltwick-Harbour-R4-Setup.exe" %*
