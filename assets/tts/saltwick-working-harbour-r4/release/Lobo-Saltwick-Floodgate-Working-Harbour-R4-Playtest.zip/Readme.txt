Saltwick Floodgate | Working Harbour R4
Infinity N5 | Area of Interest | Tabletop Simulator playtest

1. Extract the entire ZIP to a folder on your Windows PC.
2. Double-click Install.cmd.
3. In Tabletop Simulator, open Games > Save & Load and select
   Saltwick Floodgate - Working Harbour R4 - Area of Interest.

The installer picks an unused save slot. It also adds the Saltwick map bag
under Objects > Saved Objects for use with the Infinity Stage.

If you chose a custom Tabletop Simulator folder, drag that folder or its
Saves folder onto Install.cmd. The table retrieves its terrain from public
HTTPS links the first time you open it.

On another operating system you can open Files/payload.zip and use the
Play-Table.json and Preview.png pair in a free numbered TTS save slot.
