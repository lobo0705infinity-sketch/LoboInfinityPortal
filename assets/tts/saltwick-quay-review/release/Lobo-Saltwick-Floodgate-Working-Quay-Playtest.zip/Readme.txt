﻿Saltwick Floodgate
Working Quay playtest · Area of Interest

Install on Windows

1. Extract the entire ZIP to a folder and run Install.cmd.
2. In Tabletop Simulator, open Games > Save & Load.
3. Open Saltwick Floodgate - Working Quay Playtest - Area of Interest.

The installer adds a new save slot and a reusable map bag under Objects > Saved Objects > Lobo-Saltwick-Quay-Playtest. The folder name ends in a unique number. The table opens with the map deployed. To use the bag in another compatible Infinity room, drop it onto that room's Stage.

If your TTS data folder is in a custom location, drag the Tabletop Simulator data folder or its Saves folder onto Install.cmd. The first load requires internet access for the models and textures.

On the table

At the water's edge, look for the riveted gate, stone guides and tide gauges under the existing hoist. At the rigging shop, follow the wire from the timber drum to the splicing bench. On the side of Tide Control facing the central road, one of the four customs lorries is backed up to a new covered receiving bay, with the shutter up and a pallet on the tail lift.

Suggested playtest

Move a 25 mm base from the rigging shop into the lane between the drums. Then compare the view of the covered freight approach and the open road crossing from the Tide Control roof. The central communication antenna has room for base contact all the way around.

Materials

The new meshes were built for this playtest. Material photographs used in their texture atlas are from Poly Haven (CC0): Weathered Brown Planks, Rusty Painted Metal, Rough Wood, Concrete Wall 003 and Worn Corrugated Iron.
