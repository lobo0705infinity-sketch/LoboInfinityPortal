@echo off
"%~dp0Lobo-Saltwick-Quay-Setup.exe" %*
