@echo off
"%~dp0Vanta-Setup.exe" %*
exit /b %errorlevel%
