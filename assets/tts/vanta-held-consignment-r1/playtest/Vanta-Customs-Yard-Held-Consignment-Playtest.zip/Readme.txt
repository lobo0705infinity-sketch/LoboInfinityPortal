﻿Vanta Customs Yard | Held Consignment
ITS18 B-Pong playtest

Extract the entire ZIP, run Install.cmd, then open Games > Save & Load in Tabletop Simulator and select:
Vanta Customs Yard - Held Consignment - B-Pong - Playtest

A ready-to-play table occupies a fresh save slot. A copy of the map is in Objects > Saved Objects under Lobo-Vanta-Held-Consignment. To use it on another compatible Infinity table, clear the previous map and drop the Vanta bag onto Stage. For a custom Tabletop Simulator data directory, drag that directory onto Install.cmd.

Start at Gate Intake. The axle scale has flagged VX-417 for a seal discrepancy. At the inspection hall the evidence case is open. At the quarantine warehouse the same refrigerated box is on shore power, with a tagged load on the forklift. Cleared goods leave from the separate transfer dock. The two consoles and the central tracking beacon belong to the B-Pong mission.
