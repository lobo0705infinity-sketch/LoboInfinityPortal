Cairnfall Sanctuary | Courtyards R3
ITS18 Battleground | Tabletop Simulator playtest

1. Extract the entire ZIP and run Install.cmd.
2. In Tabletop Simulator, open Games > Save & Load.
3. Select Cairnfall Sanctuary - Courtyards R3 - Battleground - Play Table.

If you use a custom TTS data location, drag your Tabletop Simulator or Saves folder onto Install.cmd.
The installer creates a new save slot. Both Stage bags are available under Objects > Saved Objects in the Lobo-Cairnfall-Courtyards-R3 folder. Choose the general Battleground bag or the Top 40 Losers Round 4 bag when you already have the Infinity Stage open.

The Gardeners Workshop has a flat copper terrace with a roof drain. The widened ladder and the opening in the stone parapet share a centerline. The roof and its collision follow the building state.
