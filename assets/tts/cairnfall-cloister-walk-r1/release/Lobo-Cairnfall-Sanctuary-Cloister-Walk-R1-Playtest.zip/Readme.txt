Cairnfall Sanctuary | Cloister Walk R1
ITS18 Battleground | Tabletop Simulator playtest

1. Extract the entire ZIP and run Install.cmd.
2. In Tabletop Simulator, open Games > Save & Load.
3. Select Cairnfall Sanctuary - Cloister Walk R1 - Battleground - Play Table.

If you use a custom TTS data location, drag your Tabletop Simulator or Saves folder onto Install.cmd.
The installer creates a new save slot. Both Stage bags are available under Objects > Saved Objects in the Lobo-Cairnfall-Cloister-Walk-R1 folder. Choose the general Battleground bag or the Top 40 Losers Round 4 bag when you already have the Infinity Stage open.

Try the sheltered route beside the Guesthouse fountain, the offset herb garden gate, and the clinic approach from the side ramp. Opening the clinic removes its canopy with the roof. The equipment stays on the receiving porch.
