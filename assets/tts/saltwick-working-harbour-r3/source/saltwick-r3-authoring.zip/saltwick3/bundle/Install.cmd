@echo off
"%~dp0Lobo-Saltwick-Harbour-R3-Setup.exe" %*
