"""Working-port furniture. Collision volumes follow substantial surfaces and keep passages open."""
import math
from common import *
from harbour import ferry as original_ferry

def distribution():
    g=Mesh('distribution-cabinet')
    slab(g,(0,0,.065),(.96,2.45,.13),'washedconcrete',True,.044)
    slab(g,(0,0,.24),(.77,2.21,.22),'iron',True,.025)
    slab(g,(0,0,1.0),(.82,2.19,1.38),'gatebeam',True,.055)
    for y in (-.55,.55):
        slab(g,(-.427,y,1.02),(.043,1.052,1.28),'boardgreen',r=.028)
        for h in np.linspace(.48,.77,5):slab(g,(-.454,y,h),(.033,.67,.026),'iron',r=.005)
        slab(g,(-.463,y+.32,1.05),(.061,.064,.19),'brass')
        for h in (.53,1.44):slab(g,(-.453,y-.43,h),(.038,.074,.098),'zinc')
    slab(g,(0,0,1.76),(.94,2.32,.13),'zinc',True,.044);label(g,(-.456,.54,1.35),.80,.30,'left','electric')
    bent_wire(g,[(.20,1.2,.12),(.20,1.2,1.28),(.20,1.16,1.36),(.20,1.08,1.40)],.068,'iron',9)
    return g

def creels():
    g=Mesh('creel-landing')
    for x in (-.63,.63):slab(g,(x,0,.10),(.17,2.52,.17),'darkwood',True)
    for y in np.linspace(-1.13,1.13,8):slab(g,(0,y,.231),(1.66,.275,.092),'teak')
    for x,y,h,yaw in [(0,-.55,.29,0),(.02,.54,.29,1),(-.11,.50,.93,-4)]:
        q=g.at((x,y,h),(0,0,yaw));slab(q,(0,0,.26),(1.48,.94,.52),'netting',True,.07)
        for v in (-.49,.49):
            for z in (.145,.48):slab(q,(0,v,z),(1.56,.055,.070),'teak')
            for u in np.linspace(-.70,.70,8):slab(q,(u,v,.31),(.044,.058,.49),'teak',r=.006)
        for u in (-.75,.75):slab(q,(u,0,.39),(.067,.96,.16),'darkwood')
        for u in (-.48,.48):bent_wire(q,[(u,-.50,.12),(u,-.50,.52),(u,-.42,.58),(u,.43,.58),(u,.5,.51),(u,.5,.12)],.024,'cable',5)
    for j in range(4):g.hoop((.22,-.54,.88+.042*j),(0,0,1),.25-j*.019,.030,'teak',16,5)
    for j in range(3):g.tube((-.36+j*.25,-.94,.90),(-.26+j*.25,-.94,.90),.067,'fleetochre',9)
    return g

def delivery():
    g=Mesh('slipway-delivery')
    for x in (-.36,.36):
        for y in (-.55,.55):
            g.tyre((x,y,.147),.14,.11,'rubber',12);g.tube((x-.072,y,.147),(x+.072,y,.147),.060,'zinc',9)
    slab(g,(0,0,.32),(.89,1.44,.13),'fleetochre',True,.045)
    for y in (-.42,.39):slab(g,(0,y,.455),(.84,.19,.14),'teak',True)
    slab(g,(0,-.04,.69),(.71,1.04,.37),'fleetblue',True,.084)
    for y in (-.31,.19):
        g.tube((-.26,y,.76),(.30,y,.76),.26,'gatebeam',14);g.tube((.29,y,.76),(.41,y,.76),.13,'zinc',12);g.tube((.4,y,.76),(.46,y,.76),.068,'steel',10)
    for x in (-.27,.27):g.path([(x,-.56,.47),(x,-.52,1.01),(x,-.17,1.12),(x,.42,.98),(x,.55,.46)],.026,'canvas',6)
    bent_wire(g,[(-.36,.61,.34),(-.36,.74,.91),(-.36,.82,1.02),(.36,.82,1.02),(.36,.74,.91),(.36,.61,.34)],.034,'gatebeam',8)
    return g

def rack():
    g=Mesh('pump-stores-rack')
    for x in (-.71,.71):
        slab(g,(x,0,.08),(.20,2.38,.16),'darkwood',True)
        for y in (-1.05,1.05):slab(g,(x,y,.92),(.12,.12,1.72),'gatebeam',True)
    for h in (.28,1.05):
        slab(g,(0,0,h),(1.62,2.27,.14),'gatebeam',True)
        for y in np.linspace(-.94,.94,7):slab(g,(0,y,h+.095),(1.51,.238,.055),'teak')
    for y in (-.61,.05,.66):
        g.tube((-.57,y,.63),(.57,y,.63),.252,'fleetblue',12,True)
        for x in (-.56,.53):g.hoop((x,y,.63),(1,0,0),.25,.065,'iron',14,5)
    for y in (-.63,.45):
        g.tube((-.44,y,1.4),(.43,y,1.4),.204,'redoxide',14,True)
        for x in (-.39,.4):g.hoop((x,y,1.4),(1,0,0),.21,.067,'iron',14,5)
        g.tube((0,y,1.52),(0,y,1.85),.072,'brass',9);g.hoop((0,y,1.872),(0,0,1),.202,.029,'red',15,5)
    return g

def diesel():
    g=Mesh('marine-diesel')
    for y in (-.43,.43):
        slab(g,(0,y,.115),(2.43,.15,.21),'darkwood',True);slab(g,(0,y,.267),(2.29,.12,.12),'redoxide',True)
    for x in (-.84,.79):
        slab(g,(x,0,.345),(.17,1.02,.14),'iron',True)
        for y in (-.33,.33):slab(g,(x,y,.455),(.255,.21,.16),'fleetgreen',True)
    slab(g,(0,0,.613),(1.86,.71,.32),'gatebeam',True,.085);slab(g,(0,0,.786),(1.99,.83,.12),'zinc',True,.025)
    for y in (-.365,.365):
        slab(g,(0,y,1.0),(1.87,.095,.38),'fleetgreen',True,.033)
        for x in (-.68,-.23,.22,.67):slab(g,(x,y*1.1,.954),(.20,.047,.18),'boardgreen',r=.035)
    for x in (-.917,.917):slab(g,(x,0,1.002),(.088,.71,.386),'fleetgreen',True,.025)
    for j,x in enumerate((-.681,-.227,.227,.681)):
        ts=np.arange(16)*math.tau/16;rim=[(x+.164*math.cos(a),.164*math.sin(a),1.206)for a in ts]
        ext=[(x+.227*math.cos(a)/max(abs(math.cos(a)),abs(math.sin(a))),.407*math.sin(a)/max(abs(math.cos(a)),abs(math.sin(a))),1.206)for a in ts]
        g.surface(rim+ext,[[i,i+16,(i+1)%16+16,(i+1)%16]for i in range(16)],'zinc')
        deep=.86+[.024,.17,.08,.12][j];lower=[(u,v,deep)for u,v,h in rim]
        g.surface(rim+lower,[[i,(i+1)%16,(i+1)%16+16,i+16]for i in range(16)],'iron',smooth=True)
        g.tube((x,0,deep-.034),(x,0,deep+.004),.158,'soot',16)
        for y in (-.28,.28):g.tube((x+.14,y,1.207),(x+.14,y,1.27),.025,'bolt',6)
        bent_wire(g,[(x,-.395,1.08),(x,-.47,1.1),(x,-.54,1.02),(x,-.55,.94)],.064,'redoxide',8)
        bent_wire(g,[(x,.395,1.08),(x+.044,.453,1.14),(x+.14,.47,1.09),(x+.15,.47,.91)],.018,'brass',6)
    g.tube((-.87,-.55,.93),(.87,-.55,.93),.096,'redoxide',10);g.tube((.94,0,.78),(1.16,0,.78),.277,'iron',18);g.tube((1.16,0,.78),(1.27,0,.78),.133,'steel',12)
    label(g,(0,-.419,.96),.46,.165,'rear','dieselplate')
    # The existing bench top is 1.025 inches above the deck. The engine sits on the shop floor at .145.
    bench=g.at((-.53,1.85,.880))
    for x in (-.53,.53):slab(bench,(x,0,.053),(.13,.45,.105),'teak')
    slab(bench,(0,0,.205),(1.56,.476,.20),'gatebeam',True,.048)
    for x in (-.57,-.19,.19,.57):
        for y in (-.085,.085):bench.tube((x,y,.297),(x,y,.340),.061,'zinc',10)
        slab(bench,(x-.14,0,.332),(.042,.26,.044),'brass')
    return g

def drain():
    g=Mesh('open-kerb-drain');w,d=1.24,.63
    for x in (-w/2,w/2):slab(g,(x,0,.025),(.049,d+.04,.05),'iron')
    for y in (-d/2,d/2):slab(g,(0,y,.025),(w,.045,.05),'iron')
    q=g.at((0,d*.50,.046),(73,0,0))
    for x in (-.574,.574):slab(q,(x,.304,0),(.054,.607,.067),'iron')
    for y in (.023,.302,.583):slab(q,(0,y,0),(1.192,.041,.066),'iron')
    for x in np.linspace(-.48,.48,10):slab(q,(x,.302,0),(.037,.56,.067),'iron')
    t=OBJECTS['f5103a']['Transform'];a=math.radians(t['rotY']);x,y=-.36,-2.487
    start=(t['posX']+math.cos(a)*x+math.sin(a)*y+13.35,t['posZ']-math.sin(a)*x+math.cos(a)*y-1.47,1.26)
    p=bezier([start,(start[0]-.35,start[1]+.08,1.24),(-2.09,-1.02,.22),(-1.95,-.70,.108)],9)
    p+=bezier([p[-1],(-1.78,-.33,.092),(-1.06,-.34,.098),(-.64,-.535,.095)],9)[1:]
    p+=bezier([p[-1],(-.33,-.63,.09),(-.08,-.33,.12),(-.04,-.05,.08)],8)[1:]+[(-.04,.04,.025)]
    bent_wire(g,p,.087,'rubber',10);g.tube(start,p[1],.113,'brass',10)
    for i in range(1,len(p)-1,2):g.hoop(p[i],np.subtract(p[i+1],p[i-1]),.086,.009,'soot',10,4)
    g.solid([(x,y,h)for x in (-.598,.598)for y,h in [(.31,.035),(.37,.035),(.54,.60),(.49,.60)]])
    for a,b in zip(p[::3],p[3::3]):g.solid([e+[x,y,h]for e in np.asarray([a,b])for x in (-.074,.074)for y in (-.074,.074)for h in (-.040,.052)])
    return g

def gangway():
    g=Mesh('ferry-gangway');x0,x1=-1.28,.99;slope=-.061
    def deck(x):return .29+slope*(x-x0)
    for y in (-.54,.54):
        q=g.at(((x0+x1)/2,y,(deck(x0)+deck(x1))/2-.062),(0,math.degrees(-math.atan(slope)),0))
        slab(q,(0,0,0),(2.38,.091,.15),'zinc',True)
    for x in np.linspace(x0+.05,x1-.05,16):slab(g,(x,0,deck(x)),(.132,1.07,.052),'teak')
    g.solid([(x,y,deck(x)+h) for x in (x0,x1)for y in (-.53,.53)for h in (-.12,.024)])
    for side in (-1,1):
        y=side*.566
        for x in (-1.20,-.18,.89):g.tube((x,y,deck(x)),(x,y,deck(x)+1.),.034,'zinc',8)
        bent_wire(g,[(-1.24,y,deck(-1.24)+.72),(-1.24,y,deck(-1.24)+.93),(-1.17,y,deck(-1.17)+1.01),(.86,y,deck(.86)+1.01),(.94,y,deck(.94)+.93),(.94,y,deck(.94)+.74)],.034,'edge',8)
        g.tube((-1.20,y,deck(-1.20)+.53),(.88,y,deck(.88)+.53),.018,'cable',6);g.tube((x0-.04,y,.19),(x0+.16,y,.19),.075,'iron',10)
    slab(g,(1.24,0,.077),(.61,1.73,.14),'gatebeam',True,.06)
    for y in np.linspace(-.70,.70,7):slab(g,(1.25,y,.164),(.57,.205,.055),'teak')
    for y in (-.73,.73):g.tube((1.33,y,.16),(1.33,y,.31),.051,'iron',9)
    c=(-.92,-.603,.93);g.hoop(c,(0,-1,0),.261,.063,'red',28,7)
    for a in (0,math.pi/2,math.pi,3*math.pi/2):
        pts=[(c[0]+.261*math.cos(t),c[1]-.007,c[2]+.261*math.sin(t))for t in np.linspace(a-.16,a+.16,4)]
        bent_wire(g,pts,.064,'ivory',7)
    g.hoop((c[0],c[1]+.015,c[2]),(0,-1,0),.344,.012,'teak',24,4)
    return g

def masonry(g,center,size):
    x,y,z=center;w,d,h=size;x0,x1=x-w/2,x+w/2;y0,y1=y-d/2,y+d/2;z0,z1=z-h/2,z+h/2
    g.solid([(a,b,c)for a in (x0,x1)for b in (y0,y1)for c in (z0,z1)])
    count=0.;repeat_w,repeat_h=.99,.745
    for a,b,length in [((x0,y0),(x1,y0),w),((x1,y0),(x1,y1),d),((x1,y1),(x0,y1),w),((x0,y1),(x0,y0),d)]:
        a,b=np.array(a),np.array(b)
        ends=[count]+[k*repeat_w for k in range(1,20) if count+1e-7<k*repeat_w<count+length-1e-7]+[count+length]
        levels=[z0]+[k*repeat_h for k in range(1,10)if z0+1e-7<k*repeat_h<z1-1e-7]+[z1]
        for left,right in zip(ends,ends[1:]):
            aa=a+(b-a)*(left-count)/length;bb=a+(b-a)*(right-count)/length
            u=(left+1e-8)%repeat_w/repeat_w;uu=min(1,u+(right-left)/repeat_w)
            for lo,hi in zip(levels,levels[1:]):
                v=(lo+1e-8)%repeat_h/repeat_h;vv=min(1,v+(hi-lo)/repeat_h)
                g.surface([(*aa,lo),(*bb,lo),(*bb,hi),(*aa,hi)],[[0,1,2,3]],'brick',manual=[[(u,v),(uu,v),(uu,vv),(u,vv)]])
        count+=length
    g.surface([(x0,y0,z1),(x1,y0,z1),(x1,y1,z1),(x0,y1,z1)],[[0,1,2,3]],'stone')

def wicket():
    g=Mesh('customs-wicket')
    for x in (-1.22,.48):
        masonry(g,(x,0,.93),(.51,.53,1.86));slab(g,(x,0,1.89),(.57,.60,.125),'coping',True,.028)
    masonry(g,(-1.23,-.94,.72),(.34,1.87,1.44));slab(g,(-1.23,-.94,1.47),(.398,1.93,.092),'coping',True)
    slab(g,(-.36,0,.012),(1.22,.40,.024),'washedconcrete')
    q=g.at((-1.01,-.16,.03),(0,0,-86))
    for z in (.24,1.45):slab(q,(.54,0,z),(1.08,.077,.075),'gatebeam',True)
    for x in np.linspace(.02,1.04,8):slab(q,(x,0,.85),(.043,.052,1.44),'gatebeam')
    slab(q,(.99,0,.95),(.083,.12,.05),'brass');slab(g,(.48,.277,1.32),(.44,.068,.35),'gatebeam')
    label(g,(.48,.315,1.32),.427,.322,'front','customs')
    for h in (.49,1.35):g.tube((-1,-.18,h-.053),(-1,-.18,h+.053),.047,'brass',7)
    return g

def entrances():
    g=Mesh('slipway-doors')
    for y in (-.77,.77):
        slab(g,(-.049,y,1.344),(.078,1.53,2.60),'fleetblue',True)
        for j in np.linspace(-.67,.67,9):slab(g,(-.101,y+j,1.36),(.042,.056,2.50),'gatebeam',r=.006)
        for h in (.19,1.29,2.49):slab(g,(-.129,y,h),(.061,1.50,.062),'steel')
        slab(g,(.287,y,1.34),(.059,1.51,2.58),'gatebeam')
        for h in (.32,1.37,2.39):slab(g,(.327,y,h),(.041,1.5,.063),'iron')
        for off in (-.52,.52):
            g.tube((-.13,y+off,2.75),(-.203,y+off,2.75),.088,'iron',10);slab(g,(-.115,y+off,2.61),(.062,.08,.23),'iron')
    slab(g,(-.11,-.57,2.81),(.13,4.51,.12),'zinc',True)
    for y in (-1.56,1.56):slab(g,(-.07,y,1.34),(.13,.074,2.67),'iron',True)
    for y in (-.14,.14):bent_wire(g,[(-.14,y,1.03),(-.20,y,1.04),(-.20,y,1.25),(-.14,y,1.26)],.019,'brass',7)
    label(g,(-.166,.72,1.77),.92,.33,'left','boatdoors')
    door=-5.86
    for y in (door-.622,door+.622):slab(g,(-.041,y,1.10),(.24,.11,2.10),'darkwood',True)
    slab(g,(-.036,door,2.18),(.25,1.36,.13),'darkwood',True)
    q=g.at((.06,door-.60,.135),(0,0,-86));slab(q,(.02,.53,.956),(.068,1.03,1.91),'boardgreen',True)
    for y in (.08,.98):slab(q,(-.043,y,.95),(.039,.06,1.89),'gatebeam')
    slab(q,(-.046,.87,.98),(.055,.13,.038),'brass');slab(g,(-.073,door,2.46),(.081,1.56,.36),'gatebeam');label(g,(-.117,door,2.46),1.49,.32,'left','worksplate')
    return g

def windbreak():
    g=original_ferry();g.name='ferry-windbreak'
    for x in (-1.72,-.44):
        slab(g,(x,-2.59,1.17),(.103,.12,2.34),'gatebeam',True);slab(g,(x,-2.59,.065),(.18,.21,.13),'washedconcrete')
    for i in range(10):slab(g,(-1.08,-2.60,.202+i*.218),(1.35,.094,.217),'boardgreen',r=.004)
    # The board backing is a single physical surface behind the slats.
    g.solid([(x,y,h)for x in(-1.755,-.405)for y in(-2.647,-2.553)for h in(.093,2.275)])
    slab(g,(-1.08,-2.60,2.36),(1.47,.17,.097),'teak',True)
    for h in (.26,1.98):slab(g,(-1.08,-2.53,h),(1.39,.067,.064),'gatebeam')
    return g

def locker():
    g=Mesh('rigging-sling-locker')
    slab(g,(.16,0,1.16),(.122,1.84,2.32),'gatebeam',True)
    for y in (-.89,.89):slab(g,(-.105,y,1.14),(.56,.079,2.26),'fleetblue',True)
    slab(g,(-.103,0,2.31),(.68,1.94,.096),'zinc',True,.023);slab(g,(-.09,0,.18),(.57,1.77,.14),'darkwood',True)
    for z in (.51,1.99):slab(g,(.071,0,z),(.063,1.68,.086),'teak')
    for i,y in enumerate((-.54,-.06,.46)):
        for j in range(3):
            x=-.021-j*.029;pts=[(x,y-.14,1.72),(x-.02,y-.16,1.07-i*.09),(x-.02,y-.08,.92-i*.09),(x-.02,y+.075,.92-i*.09),(x-.02,y+.16,1.08-i*.09),(x,y+.14,1.72),(x,y+.083,1.86),(x,y-.08,1.86),(x,y-.14,1.72)]
            bent_wire(g,pts,.032,'canvas'if i!=1 else'teak',7)
        g.tube((.07,y,1.87),(-.12,y,1.87),.039,'zinc',9)
    return g
if __name__=='__main__':
    configure()
    for fn in (distribution,creels,delivery,rack,diesel,drain,gangway,wicket,entrances,windbreak,locker):fn().write()
