"""Rebuild the failed tanker and remount the weigh-office fascia on its canopy."""
import math
from common import *
import fleet,harbour
class TankerMesh(Mesh):
    def at(self,xyz,rot=(0,0,0)):
        g=type(self)(self.name);g.origin=self.origin+self.axes@xyz;g.axes=self.axes@mesh.rotation(rot)
        g.surfaces=self.surfaces;g.hulls=self.hulls
        return g
    def box(self,xyz,size,mat,r=0.,b=0.,rot=(0,0,0),physical=False,n=2):
        if r<.035 or min(size)<.075:r=b=0.
        else:n=1
        super().box(xyz,size,mat,r,b,rot,physical,n)
    def tube(self,a,b,r,mat,n=9,physical=False,r2=None):
        limit=5 if r<.046 else 8 if r<.125 else 14 if r<.30 else 16
        if mat in ('bolt','soot') and r<=.044 and np.linalg.norm(np.subtract(b,a))<.035:
            frame=mesh.from_z(np.subtract(b,a))
            pts=[b+frame@np.array([r*math.cos(t),r*math.sin(t),0.]) for t in np.arange(5)*math.tau/5]
            self.surface(pts,[[0,1,2,3,4]],mat)
        else:super().tube(a,b,r,mat,min(n,limit),physical,r2)
    def surface(self,verts,faces,mat,physical=False,smooth=False,manual=None):
        if len(verts)==100 and len(faces)==98 and mat in ('rubber','fleetgreen') and manual is None:
            n=13;verts=[verts[25*k+j] for k in range(4) for j in range(0,25,2)]
            faces=[[a*n+i,a*n+i+1,(a+1)%4*n+i+1,(a+1)%4*n+i]for a in range(4)for i in range(n-1)]
            faces.extend([[3*n,2*n,n,0],[n-1,2*n-1,3*n-1,4*n-1]])
        super().surface(verts,faces,mat,physical,smooth,manual)
    def rings(self,rings,mat,physical=False,smooth=True):
        if len(rings[0])==32 and mat in ('fleetgreen','tankalloy'):
            ix=np.rint(np.arange(24)*32/24).astype(int);rings=[[r[i]for i in ix] for r in rings]
            if len(rings)==2 and mat=='fleetgreen':
                self.surface(rings[0]+rings[1],[[j,(j+1)%24,(j+1)%24+24,j+24]for j in range(24)],mat,smooth=True);return
        super().rings(rings,mat,physical,smooth)
    def hoop(self,center,normal,radius,thick,mat,n=16,s=6):
        if radius<.075 and thick<.011:
            frame=mesh.from_z(normal)
            rings=[[np.asarray(center)+frame@np.array([(radius+thick)*math.cos(t),(radius+thick)*math.sin(t),d]) for t in np.arange(10)*math.tau/10]for d in (-thick*.76,thick*.76)]
            self.surface(rings[0]+rings[1],[[j,(j+1)%10,(j+1)%10+10,j+10]for j in range(10)],mat,smooth=True)
        elif radius>.30 and thick<=.01 and abs(normal[0])>.99:
            frame=mesh.from_z((math.copysign(1,center[0]),0,0))
            rings=[[center+frame@np.array([r*math.cos(t),r*math.sin(t),.002])for t in np.arange(18)*math.tau/18]for r in (radius-thick,radius+thick)]
            self.surface(rings[0]+rings[1],[[j,j+18,(j+1)%18+18,(j+1)%18]for j in range(18)],mat)
        else:super().hoop(center,normal,radius,thick,mat,min(n,16),min(s,4))
    def tyre(self,pos,r,width,mat='tyre',n=20):
        x,y,z=pos;n=18
        profile=[(-.50,.64),(-.48,.86),(-.28,1),(.28,1),(.48,.86),(.50,.64)]
        rings=[[(x+a*width,y+r*b*math.cos(t),z+r*b*math.sin(t))for t in np.arange(n)*math.tau/n]for a,b in profile]
        faces=[[j*n+i,j*n+(i+1)%n,(j+1)*n+(i+1)%n,(j+1)*n+i]for j in range(len(rings)-1)for i in range(n)]
        self.surface(sum(rings,[]),faces,mat,smooth=True);self.solid(rings[1]+rings[-2]+rings[2]+rings[-3])
def repair():
    configure();g=TankerMesh('water-services-tanker')
    fleet.chassis(g,'fleetgreen');fleet.cab(g,'fleetgreen',4);fleet.tank_body(g);g.write()
    office=harbour.weigh_office();office.name='weighbridge-office'
    kept=[];removed=[]
    for s in office.surfaces:
        pts,_,_,mat,_,_=s
        if mat=='weighsign' or (mat=='gatebeam' and np.allclose((pts.min(0)+pts.max(0))/2,(1.383,-.040,2.029),atol=.001)):removed.append(mat)
        else:kept.append(s)
    assert sorted(removed)==['gatebeam','weighsign']
    office.surfaces=kept
    a,b,c,d,e,f=1.443,1.516,-1.14,1.045,1.76,2.051
    p=[(a,c,e),(b,c,e),(b,d,e),(a,d,e),(a,c,f),(b,c,f),(b,d,f),(a,d,f)]
    office.surface(p,[[0,3,2,1],[4,5,6,7],[0,1,5,4],[2,3,7,6],[3,0,4,7]],'gatebeam')
    office.surface([p[i]for i in (1,2,6,5)],[[0,1,2,3]],'weighsign',manual=[[(0,0),(1,0),(1,1),(0,1)]])
    for y in (-.96,.85):block(office,(1.371,y,1.963),(.224,.075,.059),'iron')
    office.write()
    for name in (office.name,g.name):(ASSETS/(name+'-col.obj')).unlink()
if __name__=='__main__':repair()
