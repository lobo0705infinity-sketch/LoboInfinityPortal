"""Saltwick Working Harbour R3. Local modelling coordinates are X, Z, height in inches."""
from pathlib import Path
from hashlib import sha1
import json,sys
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
WS=ROOT.parent
R2=WS/'saltwick2'
R1=WS/'saltwick'
ASSETS=ROOT/'Assets'
REVIEW=ROOT/'Review'
sys.path.insert(0,str(R2/'Source'))
import mesh,finishes
from mesh import Mesh
from fleet import block,label
from props import bent_wire
BASE_URL='https://raw.githubusercontent.com/lobo0705infinity-sketch/LoboInfinityPortal/'
PREFIX='assets/tts/saltwick-working-harbour-r3/'
BASE_COMMIT='1d201f004e8e29de3904c14afb159f75b1120822'
RD=json.loads((R2/'Release/Saltwick-Floodgate.json').read_bytes())['ObjectStates'][0]
OBJECTS={o['GUID']:o for o in RD['ContainedObjects']}
ALIASES={'lockplate':'fleetmark','dispatchplate':'fishmark','tideclock':'watermark','dispatchclock':'fittermark','worksplate':'boatname','boatdoors':'fleetplate1','customs':'fleetplate2','brick':'fleetplate3','dieselplate':'fleetplate4','electric':'ferryboard'}
def configure(out=ASSETS):
    mesh.OUT=mesh.UNBAKED=out
    for a,k in ALIASES.items():mesh.INDEX[a]=mesh.INDEX[k]
def local(u):
    f=u.rsplit('/',1)[-1]
    if PREFIX in u:return ASSETS/f
    if '/saltwick-quay-review/'in u:return R1/'Assets'/f
    if '/saltwick-working-harbour-r2/'in u:return R2/'Assets'/f
    return R1/'Review/cache'/(sha1(u.encode()).hexdigest()[:9]+'-'+f)
def slab(g,p,d,m,solid=False,r=.012):
    g.box(p,d,m,r=r,b=r*.55,n=1,physical=solid)
def bezier(points,n):
    p=np.asarray(points,float)
    return [tuple((1-t)**3*p[0]+3*(1-t)**2*t*p[1]+3*(1-t)*t*t*p[2]+t**3*p[3]) for t in np.linspace(0,1,n)]
