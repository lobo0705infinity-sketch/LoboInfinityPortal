"""Photo-based finishes and the two paved installations are baked into the original quay."""
import math
from PIL import Image,ImageDraw,ImageFont,ImageOps
from scipy.ndimage import gaussian_filter
from common import *
def font(n,b=True):
    return ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed'+('-Bold' if b else '')+'.ttf',n)
def plate(title,sub,blue=False):
    width,height=820,230
    rng=np.random.default_rng(sum(map(ord,title)))
    grain=gaussian_filter(rng.normal(0,9,(height,width)),(.5,.55))
    a=np.clip(np.array([47,74,79]if blue else [64,83,67])+grain[:,:,None],0,255).astype('uint8')
    im=Image.fromarray(a);d=ImageDraw.Draw(im);ink=(232,221,188)
    d.rounded_rectangle((7,7,width-8,height-8),radius=12,outline=ink,width=3)
    sz=108
    while d.textlength(title,font=font(sz))>width*.90:sz-=2
    d.text((width/2,height*.41),title,anchor='mm',font=font(sz),fill=ink)
    d.text((width/2,height*.78),sub,anchor='mm',font=font(36,False),fill=ink)
    for x in (18,width-19):
        for y in (18,height-19):d.ellipse((x-4,y-4,x+4,y+4),fill=(151,147,129))
    return im.resize((256,256),Image.Resampling.LANCZOS)
def dial(tide):
    im=Image.new('RGB',(512,512),(48,67,63));d=ImageDraw.Draw(im);d.ellipse((15,15,497,497),fill=(212,210,184),outline=(136,128,104),width=9)
    def xy(a,r):
        a=math.radians(a-90);return (256+math.cos(a)*r,256+math.sin(a)*r)
    for i in range(60):d.line([xy(i*6,204),xy(i*6,186 if i%5==0 else 197)],fill=(47,52,49),width=5 if i%5==0 else 2)
    if tide:
        for deg,t in [(0,'HIGH'),(180,'LOW')]:d.text(xy(deg,143),t,font=font(45),anchor='mm',fill=(52,70,68))
        d.text((256,192),'SALTWICK',font=font(25,False),anchor='mm',fill=(65,72,66))
        d.line([xy(238,42),xy(58,160)],fill=(136,54,43),width=15)
    else:
        for h in range(1,13):d.text(xy(h*30,145),str(h),font=font(38),anchor='mm',fill=(48,58,52))
        for a,r,w in [(302,103,15),(78,155,10)]:d.line([(256,256),xy(a,r)],fill=(43,50,48),width=w)
    d.ellipse((245,245,267,267),fill=(86,67,49));return im.resize((256,256),Image.Resampling.LANCZOS)
def reference(photo,n):
    return np.asarray(ImageOps.fit(Image.open(R1/'Review/photos'/(photo+'.jpg')).convert('L'),(n,n)),float)
def brick():
    y,x=np.mgrid[:256,:256];row=y//32;xx=(x+(row%2)*32)%64;yy=y%32;rg=np.random.default_rng(77)
    g=reference('concrete_wall_003',256);v=rg.normal(0,9,(8,5))[row,((x+(row%2)*32)//64)%5]
    a=[125,84,65]+(.45*(g-g.mean()))[:,:,None]+v[:,:,None]*[1,.77,.64]
    m=(xx<3)|(yy<3);a[m]=[153,146,127]+(g[m,None]-g.mean())*.32
    return Image.fromarray(np.uint8(np.clip(a,0,255)))
def atlases():
    im=Image.open(R2/'Assets/harbour-diffuse.jpg').convert('RGB');nm=Image.open(R2/'Assets/harbour-normal.png').convert('RGB')
    tiles=dict(lockplate=plate('LOCKMASTER','TIDE CONTROL  /  NO. 2',True),dispatchplate=plate('GOODS DISPATCH','SALTWICK PORT  /  RECEIVING BAY'),tideclock=dial(True),dispatchclock=dial(False),
        worksplate=plate('SLIPWAY REPAIR','MARINE ENGINEERING',True),boatdoors=plate('BOAT DOORS','KEEP TRACK CLEAR'),customs=plate('CUSTOMS','CREW ENTRANCE',True),brick=brick(),dieselplate=plate('M.6 DIESEL','SALTWICK MARINE'),electric=plate('PORT ELECTRIC','JUNCTION 04',True))
    for a,tile in tiles.items():
        i=finishes.INDEX[ALIASES[a]];xy=(i%8*256,i//8*256);im.paste(tile,xy);nm.paste(Image.new('RGB',(256,256),(128,128,255)),xy)
    im.save(ASSETS/'yard-finish.jpg',quality=94,subsampling=0,optimize=True);nm.save(ASSETS/'yard-normal.png',optimize=True)
    buildings=Image.open(local(OBJECTS['f51044']['CustomMesh']['DiffuseURL'])).convert('RGB')
    def join(a,b,name):
        out=Image.new('RGB',(4096,2048));out.paste(a,(0,0));out.paste(b,(2048,0))
        if name.endswith('.jpg'):out.save(ASSETS/name,quality=94,subsampling=0,optimize=True)
        else:out.save(ASSETS/name,optimize=True)
    join(buildings,im,'building-workshop.jpg')
    old=Image.open(R1/'Assets/quayside-diffuse.jpg').convert('RGB');old.paste(old.crop((256,256,512,512)),(512,256))
    norm=Image.open(R1/'Assets/quayside-normal.png').convert('RGB');norm.paste(norm.crop((256,256,512,512)),(512,256))
    raw=np.asarray(old,dtype=float);noise=gaussian_filter(np.random.default_rng(800).normal(0,10,raw.shape[:2]),2)
    wet=Image.fromarray(np.uint8(np.clip(raw*[.57,.66,.55]+[1,5,4]+noise[:,:,None],0,255)))
    join(old,wet,'outfall-finish.jpg');join(norm,norm,'outfall-normal.png')
def pavement():
    im=Image.open(local(OBJECTS['f5100b']['CustomImage']['ImageURL'])).convert('RGB');n=im.width
    def px(x,z):return ((x+24)*n/48,(24-z)*n/48)
    def poly(d,pts,col):d.polygon([px(*p)for p in pts],fill=col)
    def line(d,pts,col,w=1):d.line([px(*p)for p in pts],fill=col,width=w,joint='curve')
    def rect(d,a,col):
        x,y,u,v=a;poly(d,[(x,y),(x,v),(u,v),(u,y)],col)
    def photo(mask,source,tint,power):
        p=reference(source,n);v=np.array(tint)+(p-p.mean())[:,:,None]*power
        im.paste(Image.fromarray(np.uint8(np.clip(v,0,255))),mask=mask)
    mask=Image.new('L',im.size);rect(ImageDraw.Draw(mask),(-1.53,-11.86,1.53,-4.78),255)
    photo(mask,'concrete_wall_003',(139,138,124),.63);d=ImageDraw.Draw(im)
    for z in (-11.87,-10.93,-5.65,-4.77):line(d,[(-1.5,z),(1.52,z)],(72,73,65),2)
    rect(d,(-1.17,-10.95,1.19,-5.64),(48,50,47));mask=Image.new('L',im.size)
    rect(ImageDraw.Draw(mask),(-1.115,-10.88,1.135,-5.71),255);photo(mask,'rusty_painted_metal',(106,116,109),.42)
    d=ImageDraw.Draw(im)
    for z in (-10.82,-9.61,-8.30,-7.01,-5.76):
        line(d,[(-1.08,z),(1.1,z)],(67,73,70),2)
        for x in (-.95,.95):
            u,v=px(x,z+.05);d.ellipse((u-1.2,v-1.2,u+1.2,v+1.2),fill=(175,171,146))
    for x in (-1.33,1.34):
        for z in (-10.81,-6.02):line(d,[(x,z),(x,z+.29)],(192,164,88),3)
    pts=[(1.32*math.cos(a),1.32*math.sin(a))for a in np.arange(8)*math.tau/8+math.pi/8]
    mask=Image.new('L',im.size);poly(ImageDraw.Draw(mask),pts,255);photo(mask,'concrete_wall_003',(154,151,134),.52)
    d=ImageDraw.Draw(im);line(d,pts+[pts[0]],(97,102,91),2);route=[(.88,.78),(1.53,1.41),(2.46,1.47),(3.34,2.46)]
    for ds,col,w in [(0,(79,86,81),5),(.015,(153,151,132),2)]:line(d,[(x,z+ds)for x,z in route],col,w)
    for x,z in [(1.59,1.43),(2.45,1.48)]:rect(d,(x-.10,z-.14,x+.10,z+.14),(74,82,77));line(d,[(x-.08,z),(x+.08,z)],(162,153,125))
    rect(d,(-13.96,1.19,-12.74,1.75),(43,44,40));rect(d,(-13.91,1.23,-12.79,1.71),(29,34,33))
    im.save(ASSETS/'saltwick-working-quay.jpg',quality=95,subsampling=0,optimize=True)
if __name__=='__main__':atlases();pavement()
