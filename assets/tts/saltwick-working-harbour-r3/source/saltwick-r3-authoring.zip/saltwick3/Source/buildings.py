"""Attach fittings to their building states and stain the gate and steps at a shared tide level."""
import math,tempfile
from scipy.spatial.transform import Rotation
from common import *
from mesh import fmt,unit
def read_obj(file):
    p=[];u=[];n=[];tri=[]
    for line in Path(file).read_text().splitlines():
        f=line.split()
        if not f:continue
        if f[0]=='v':p.append(tuple(map(float,f[1:4])))
        elif f[0]=='vt':u.append(tuple(map(float,f[1:3])))
        elif f[0]=='vn':n.append(tuple(map(float,f[1:4])))
        elif f[0]=='f':
            face=[tuple(int(v)-1 for v in c.split('/')) for c in f[1:]]
            tri.extend((face[0],face[k],face[k+1])for k in range(1,len(face)-1))
    return np.array(p),np.array(u),np.array(n),tri
class Model:
    def __init__(self,name):self.name=name;self.p={};self.t={};self.n={};self.faces=[]
    @staticmethod
    def index(table,v):
        k=tuple(np.round(v,6));return table.setdefault(k,len(table)+1)
    def add(self,v):
        if np.linalg.norm(np.cross(v[1][:3]-v[0][:3],v[2][:3]-v[0][:3]))<1e-9:return
        self.faces.append([(self.index(self.p,x[:3]),self.index(self.t,x[3:5]),self.index(self.n,unit(x[5:8])))for x in v])
    def write(self):
        with (ASSETS/(self.name+'.obj')).open('w')as f:
            f.write('# Saltwick Floodgate | '+self.name+'\ng '+self.name+'\n')
            for tag,d in [('v',self.p),('vt',self.t),('vn',self.n)]:
                for k in d:f.write(tag+' '+' '.join(map(fmt,k))+'\n')
            for face in self.faces:f.write('f '+' '.join('/'.join(map(str,x))for x in face)+'\n')
        print(self.name,len(self.faces),'triangles',flush=True)
def append(m,file,side,convert=None):
    p,t,n,faces=read_obj(file)
    if convert:p,n=convert(p,n)
    t[:,0]=(t[:,0]+side)/2
    for face in faces:m.add([np.r_[p[a],t[b],n[c]]for a,b,c in face])
def transform(o):
    t=o['Transform'];scale=np.array([t['scale'+a]for a in 'XYZ']);mirror=np.array([-1,1,1])
    rot=Rotation.from_euler('YXZ',[t['rot'+a] for a in 'YXZ'],degrees=True).inv()
    origin=np.array([t['posX'],t['posY']-4,t['posZ']])
    def convert(p,n):
        q=rot.apply(p*mirror-origin)/scale;norm=rot.apply(n*mirror)*scale;norm/=np.maximum(np.linalg.norm(norm,axis=1)[:,None],1e-9)
        return q*mirror,norm*mirror
    return convert
def office(which,level):
    g=Mesh('building-fittings')
    if which=='lockmaster':
        slab(g,(7.943,-4.72,2.55),(.123,2.05,.43),'brass',r=.027)
        label(g,(7.876,-4.72,2.55),1.94,.365,'left','lockplate')
        if level>1:
            g.tube((7.907,-4.70,3.68),(7.745,-4.70,3.68),.45,'brass',24)
            slab(g,(7.743,-4.70,3.68),(.039,.82,.82),'gatebeam',r=.075)
            label(g,(7.717,-4.70,3.68),.792,.792,'left','tideclock')
        for j,mat in enumerate(('redlamp','fleetgreen')):
            y=-5.95+j*.28;slab(g,(7.946,y,2.40),(.12,.226,.38),'iron')
            g.tube((7.875,y,2.40),(7.828,y,2.40),.084,mat,12)
        g.path([(7.928,-5.99,2.15),(7.928,-5.99,1.55),(7.96,-6.14,1.42)],.023,'iron',6)
    else:
        h=3.65 if level>1 else 2.43
        slab(g,(4.24,-16.245,h),(2.27,.10,.44),'zinc',r=.028);label(g,(4.24,-16.188,h),2.18,.387,'front','dispatchplate')
        g.tube((5.72,-16.275,h),(5.72,-16.14,h),.32,'iron',20)
        slab(g,(5.72,-16.128,h),(.623,.035,.623),'gatebeam',r=.06);label(g,(5.72,-16.104,h),.598,.598,'front','dispatchclock')
        slab(g,(6.37,-16.204,1.37),(.47,.135,.57),'fleetgreen',r=.028)
        slab(g,(6.37,-16.128,1.48),(.33,.024,.043),'iron');slab(g,(6.37,-16.133,1.60),(.21,.025,.081),'ivory')
    return g
def hoist():
    g=Mesh('building-fittings');y=8.8
    slab(g,(-7.32,y,3.23),(8.82,.10,.14),'iron')
    for z in (3.141,3.312):slab(g,(-7.32,y,z),(8.86,.253,.047),'gatebeam')
    for x in (-11.64,-3.04):slab(g,(x,y,3.13),(.29,.42,.16),'iron')
    x=-6.60
    for dy in (-.113,.113):g.tube((x,y+dy-.03,3.14),(x,y+dy+.03,3.14),.10,'steel',11)
    slab(g,(x,y,2.998),(.29,.30,.204),'fleetochre',r=.048);g.tube((x-.12,y,2.89),(x+.12,y,2.89),.135,'fleetochre',12)
    for i in range(13):g.hoop((x,y,2.74-i*.057),(1,0,0)if i%2 else(0,1,0),.047,.011,'iron',8,4)
    bent_wire(g,[(x,y,2.04),(x-.028,y,1.94),(x+.002,y,1.87),(x+.078,y,1.86),(x+.117,y,1.912)],.028,'brass',8)
    for d in (-.042,.042):g.tube((x+.18+d,y,2.83),(x+.18+d,y,2.15),.010,'cable',6)
    return g
def steps():
    g=Mesh('gate-steps')
    for i in range(6):
        x=-2.26+i*.302;h=.77-i*.142;slab(g,(x,-2.095,h/2),(.302,.82,h),'stone',True)
    for x,h in [(-2.31,.78),(-1.66,.48),(-.88,.132)]:g.tube((x,-2.46,h),(x,-2.46,h+.81),.026,'iron',8)
    bent_wire(g,[(-2.33,-2.46,1.44),(-2.33,-2.46,1.55),(-2.26,-2.46,1.58),(-.89,-2.46,.96),(-.82,-2.46,.90)],.031,'zinc',9)
    return g
def tideheight(v):return v[1]-(.626+.008*v[2]-.004*v[0])
def split(poly,wet):
    out=[]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        da,db=tideheight(a),tideheight(b)
        if (da<=0)==wet:out.append(a)
        if da*db<0:out.append(a+(b-a)*da/(da-db))
    return out
def build():
    with tempfile.TemporaryDirectory()as folder:
        tmp=Path(folder);configure(tmp)
        for guid,role in [('f5103e','dispatch'),('f51041','lockmaster'),('f51044','slipway')]:
            o=OBJECTS[guid]
            levels=[(3,o),(1,o['States']['1']),(2,o['States']['2'])] if role!='slipway'else[(2,o['States']['2'])]
            for i,node in levels:
                detail=hoist() if role=='slipway'else office(role,i);detail.write();out=Model(f'{role}-{i}')
                append(out,local(node['CustomMesh']['MeshURL']),0);append(out,tmp/'building-fittings.obj',1,transform(o));out.write()
        steps().write();old=OBJECTS['f51ac0']['CustomMesh'];out=Model('sluice-and-inspection-steps')
        for path in (local(old['MeshURL']),tmp/'gate-steps.obj'):
            p,uv,n,tri=read_obj(path)
            for face in tri:
                poly=[np.r_[p[a],uv[b],n[c]]for a,b,c in face];ds=[tideheight(v)for v in poly]
                layers=[(min(ds)<0,poly)] if min(ds)>=0 or max(ds)<0 else [(k,split(poly,k))for k in (True,False)]
                for wet,vertices in layers:
                    v=[x.copy()for x in vertices]
                    for point in v:point[3]=(point[3]+int(wet))/2
                    for j in range(1,len(v)-1):out.add([v[0],v[j],v[j+1]])
        out.write();lines=[];off=0
        for g,f in enumerate([local(old['ColliderURL']),tmp/'gate-steps-col.obj']):
            cnt=0
            for l in f.read_text().splitlines():
                if l.startswith('o '):lines.append(f'o section{g}-'+l[2:])
                if l.startswith('v '):lines.append(l);cnt+=1
                if l.startswith('f '):lines.append('f '+' '.join(str(int(s)+off)for s in l.split()[1:]))
            off+=cnt
        (ASSETS/'sluice-and-inspection-steps-col.obj').write_text('\n'.join(lines)+'\n')
if __name__=='__main__':build()
