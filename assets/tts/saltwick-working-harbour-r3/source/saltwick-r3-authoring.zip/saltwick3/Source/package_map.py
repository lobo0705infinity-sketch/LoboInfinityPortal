"""Apply only Saltwick-owned edits to the archived R2 ready table and its Stage bag."""
from copy import deepcopy
from datetime import datetime
import re
from zoneinfo import ZoneInfo
from common import *
TITLE='Saltwick Floodgate - Working Harbour R3 - Area of Interest'
TAG='LoboMap:1002d9'
POSE=('posX','posY','posZ','rotX','rotY','rotZ')
NEW={
'f51012':('distribution-cabinet','Port Electric | Junction cabinet','The feeder duct runs from this cabinet to the central antenna.',(3.34,4,2.46)),
'f5101c':('creel-landing','Net Loft | Landed creels','Warp and marker floats are packed into the last creel on the landing.',(-4.70,4,-3.76)),
'f5101e':('marine-diesel','Slipway Repair | Open marine diesel','The cylinder liners and exhaust are exposed. The removed head rests on the workshop bench.',(-6.60,4.145,8.8)),
'f5103c':('pump-stores-rack','Tide Works | Pump spares','Flanged suction spools and isolation valves in the steel stores rack.',(12.64,4,-18.18)),
'f5103d':('slipway-delivery','Slipway Repair | Gearbox delivery','A replacement gearbox is strapped to the trolley beside the crew entrance.',(-12.69,4,5.54)),
'f51ad0':('open-kerb-drain','Port Water Services | Open kerb drain','The hose connects the vacuum tanker to the open road gully.',(-13.35,4,1.47)),
'f51ad1':('ferry-gangway','Saltwick Ferry | Boarding gangway','A hinged ramp and floating landing at the foot of the ferry steps.',(22.41,4,22.45)),
'f51ad2':('customs-wicket','Customs Inspection | Crew wicket','Open pedestrian wicket and brick return beside the vehicle entrance.',(-8.33,4,-14.91)),
'f51ad3':('slipway-doors','Slipway Repair | Rail and crew entrances','Sliding boat doors line up with the slipway. The crew entrance remains open.',(-12.028,4,9.602)),
'f51ad4':('rigging-sling-locker','Rigging Yard | Covered sling locker','Lifting slings hang inside the sheltered rack against the crew office.',(-13.43,4,-16.48))}
TOWERS={'f5103e':('dispatch','Harbour Dispatch'),'f51041':('lockmaster',"Lockmaster's Office")}
MODIFIED=set(NEW)|set(TOWERS)|{'f5103a','f51014','f5101f','f51ac0','f51044','f5100b','f5100d','f51001','f51000','f51004'}
def compact(v):return json.dumps(v,ensure_ascii=False,separators=(',',':'))
def data(p):return json.loads(Path(p).read_bytes())
def build(commit):
    assert re.fullmatch('[a-f0-9]{40}',commit)
    base=BASE_URL+commit+'/'+PREFIX
    stage=data(R2/'Release/Saltwick-Floodgate.json');bag=stage['ObjectStates'][0];table=data(R2/'Release/Play-Table.json')
    def url(f):
        assert (ASSETS/f).is_file(),f
        return base+f
    def update(objects):
        ids={o['GUID']:o for o in objects}
        for guid,(asset,name,desc,world) in NEW.items():
            if guid not in ids:
                o=deepcopy(ids['f51012']);objects.append(o);ids[guid]=o
            o=ids[guid];o.update(GUID=guid,Nickname=name,Description=desc,GMNotes=TAG,Tags=[TAG],Locked=True)
            o['Transform'].update(dict(zip(POSE,(*world,0.,0.,0.))),scaleX=1.,scaleY=1.,scaleZ=1.)
            o['CustomMesh'].update(MeshURL=url(asset+'.obj'),ColliderURL=url(asset+'-col.obj'),DiffuseURL=url('yard-finish.jpg'),NormalURL=url('yard-normal.png'),Convex=False,CastShadows=True)
            o['CustomMesh']['CustomShader'].update(SpecularIntensity=.055,SpecularSharpness=14.,FresnelStrength=.075)
        for g,name in [('f5103a','water-services-tanker'),('f51014','weighbridge-office')]:ids[g]['CustomMesh']['MeshURL']=url(name+'.obj')
        ids['f5101f']['CustomMesh'].update(MeshURL=url('ferry-windbreak.obj'),ColliderURL=url('ferry-windbreak-col.obj'))
        for guid,(slug,name)in TOWERS.items():
            o=ids[guid]
            for level,node in [(3,o),*[(int(st),n)for st,n in o['States'].items()]]:
                node['CustomMesh'].update(MeshURL=url(f'{slug}-{level}.obj'),DiffuseURL=url('building-workshop.jpg'))
                node['Nickname']=name+' | '+('Ground Floor','Upper Floor','Roof')[level-1]
                node['Description']=node.get('Description','').replace('Tide Control',name)
        for guid in ('f51001','f51000','f51004'):ids[guid]['Nickname']=ids[guid]['Nickname'].replace('Tide Control',"Lockmaster's Office")
        ids['f51044']['States']['2']['CustomMesh'].update(MeshURL=url('slipway-2.obj'),DiffuseURL=url('building-workshop.jpg'))
        ids['f51ac0']['CustomMesh'].update(MeshURL=url('sluice-and-inspection-steps.obj'),ColliderURL=url('sluice-and-inspection-steps-col.obj'),DiffuseURL=url('outfall-finish.jpg'),NormalURL=url('outfall-normal.png'))
        ids['f51ac0']['Description']='Sluice, tide staff and inspection steps on the quay share one high-water line.'
        ids['f5100b']['CustomImage']['ImageURL']=url('saltwick-working-quay.jpg')
        owner=ids['f5100d'];script=owner['LuaScript'];m=re.search(r'^ local config=JSON.decode\((.+)\)$',script,re.M)
        cfg=json.loads(json.loads(m[1]));cfg['guids'].update(dict.fromkeys(NEW,True));owner['LuaScript']=script[:m.start(1)]+json.dumps(compact(cfg))+script[m.end(1):]
    update(bag['ContainedObjects']);update(table['ObjectStates'])
    poses={g:'--'+g+','+','.join(f'{v:.10f}'for v in (*coords,0.,0.,0.))for g,(_,_,_,coords)in NEW.items()}
    lines=[poses.pop(l[2:8],l) if l.startswith('--')else l for l in bag['LuaScript'].splitlines()];bag['LuaScript']='\r\n'.join(lines+list(poses.values()))+'\r\n'
    bag['Nickname']='SET_ITS18 Area Of Interest - Saltwick Floodgate - Working Harbour R3';bag['Description']='Working Harbour R3 playtest. Drop this bag on the Infinity Stage.'
    stage['SaveName']=bag['Nickname'];table['SaveName']=TITLE;now=datetime.now(ZoneInfo('America/New_York'))
    for filename,v in [('Saltwick-Floodgate.json',stage),('Play-Table.json',table)]:
        v['Date']=now.strftime('%m/%d/%Y %I:%M:%S %p');v['EpochTime']=int(now.timestamp());(ROOT/'Release'/filename).write_text(compact(v))
if __name__=='__main__':build(sys.argv[1])
