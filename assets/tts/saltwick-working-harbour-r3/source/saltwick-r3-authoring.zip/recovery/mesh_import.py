from pathlib import Path
import bpy,json
base=Path.cwd()/'saltwick3'
result={}
for obj in sorted((base/'Assets').glob('*.obj')):
 bpy.ops.wm.read_factory_settings(use_empty=True)
 bpy.ops.wm.obj_import(filepath=str(obj))
 objs=[o for o in bpy.context.scene.objects if o.type=='MESH']
 count=sum(len(o.data.polygons) for o in objs)
 assert count==sum(l.startswith(b'f ')for l in obj.read_bytes().splitlines()),(obj,count)
 if not obj.name.endswith('-col.obj'):assert all(o.data.uv_layers for o in objs),obj
 result[obj.name]=count
(base/'Review/blender-import.json').write_text(json.dumps(result,indent=1))
print('Imported',len(result),'meshes and colliders')
