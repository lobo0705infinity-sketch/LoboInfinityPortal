"""Review TTS footprints and model-height sightlines at full table scale."""
import sys,json
from functools import lru_cache
from pathlib import Path
import numpy as np
from shapely import union_all,make_valid
from shapely.geometry import LineString,Point,box
from shapely.ops import polygonize
from scipy.spatial.transform import Rotation
sys.path.insert(0,'saltwick3/Source')
from common import local,ROOT
from package_map import TAG
objects={o['GUID']:o for o in json.loads((ROOT/'Release/Play-Table.json').read_bytes())['ObjectStates'] if TAG in o.get('Tags',[]) and o.get('CustomMesh')}
@lru_cache(None)
def read(path):
 verts=[];faces=[]
 for l in path.read_text().splitlines():
  if l.startswith('v '):verts.append(tuple(map(float,l.split()[1:4])))
  elif l.startswith('f '):
   f=[int(k.split('/')[0])-1 for k in l.split()[1:]];faces.extend([f[0],f[i],f[i+1]]for i in range(1,len(f)-1))
 return np.array(verts),np.array(faces)
@lru_cache(None)
def model(guid,physical):
 obj=objects[guid];cm=obj['CustomMesh'];coords,faces=read(local(cm['ColliderURL'] if physical and cm.get('ColliderURL') else cm['MeshURL']));t=obj['Transform']
 scale=np.array([t['scale'+a]for a in 'XYZ']);p=coords*[-1,1,1]*scale
 p=Rotation.from_euler('YXZ',[t['rot'+a]for a in 'YXZ'],degrees=True).apply(p)+[t['pos'+a]for a in 'XYZ']
 tri=p[faces];return tri,tri.min(1),tri.max(1)
def sliced(y):
 shapes=[]
 for guid in objects:
  a,lo,hi=model(guid,True);a=a[(lo[:,1]<y)&(hi[:,1]>y)];segs=[]
  if not len(a):continue
  for tri in a:
   pts=[]
   for i,j in [(0,1),(1,2),(2,0)]:
    start,end=tri[i],tri[j]
    if (start[1]<=y)!=(end[1]<=y):
     p=start+(end-start)*((y-start[1])/(end[1]-start[1]));pts.append(np.round(p[[0,2]],4))
   if len(pts)==2 and tuple(pts[0])!=tuple(pts[1]):segs.append(LineString(pts))
  if segs:shapes.extend(polygonize(segs));shapes.append(union_all(segs).buffer(.008,quad_segs=2))
 return union_all([s if s.is_valid else make_valid(s) for s in shapes],grid_size=.00001)
def sight(a,b,only=None):
 a,b=np.array(a),np.array(b);d=b-a;hits=[]
 for guid in (only or objects):
  tri,lo,hi=model(guid,False);sel=np.all(lo<=np.maximum(a,b)+1e-7,1)&np.all(hi>=np.minimum(a,b)-1e-7,1)
  if not sel.any():continue
  q=tri[sel];v=q[:,0];e=q[:,1]-v;f=q[:,2]-v;h=np.cross(d,f);det=(e*h).sum(1);keep=np.abs(det)>1e-9
  if not keep.any():continue
  h,e,f,v,det=[arr[keep] for arr in [h,e,f,v,det]];s=a-v;u=(s*h).sum(1)/det;k=np.cross(s,e);v2=(k*d).sum(1)/det;t=(f*k).sum(1)/det
  t=t[(u>=-1e-7)&(v2>=-1e-7)&(u+v2<=1.0000001)&(t>1e-6)&(t<1-1e-6)]
  if len(t):hits.append((float(t.min()),guid))
 return sorted(hits)
def main():
 report={};levels=[4.19,4.47,4.78,5.05,5.32,5.56,5.84,6.16,6.58]
 polys=[sliced(y)for y in levels];routes={}
 for diam,levels_used,starts in [(25,6,[(11.20,10.82),(-19.74,-18.81)]),(55,9,[(9.7,11.57),(-14.95,-16.75)])]:
  walls=union_all(polys[:levels_used]);r=diam/50.8;touch=(diam/2+20)/25.4
  point=Point(touch,0);floor=box(-24+r,-24+r,24-r,24-r).difference(union_all([walls.buffer(r+.009,quad_segs=12),Point(0,0).buffer(touch-.003,quad_segs=32)]))
  comp=next(p for p in getattr(floor,'geoms',[floor])if p.covers(point))
  for start,corner in zip(starts,[(24,24),(-24,-24)]):
   assert Point(corner).distance(Point(start))<24-r,(diam,start,'deployment')
   assert comp.covers(Point(start)),(diam,start,'no ground route')
  routes[str(diam)]={'seats':starts,'console_contact':list(point.coords)[0]}
  if diam==25:
   widths={}
   for name,line in [('customs',[(-8.68,-14.13),(-8.68,-15.61)]),('crew',[(-12.74,3.743),(-10.85,3.743)])]:
    d=walls.distance(LineString(line));assert d>=r+.009,(name,d*50.8);widths[name]=round(50.8*d,2)
   report['measured_clear_width_mm']=widths
 report['reachable_from_each_deployment_zone_mm']=routes
 eyes={'Dispatch':(1.43,9.995+40/25.4,-17.),'Lockmaster':(8.8,10.008+40/25.4,-1.8)};sights={}
 for name,start in eyes.items():
  for test,(x,z)in {'Ferry':(11.2,10.82),'Rigging':(-14.70,-16.),'Central crossing':(-.42,-8.6),'Receiving bay':(3.48,-13.10)}.items():
   ray=np.array([x-start[0],z-start[2]]);perp=np.array([-ray[1],ray[0]])/np.linalg.norm(ray);hits=[]
   for margin in (-.45,0.,.45):
    tx,tz=np.array([x,z])+margin*perp;h=sight(start,(tx,4+40/25.4,tz));hits.append(h[0][1] if h else None)
   sights[name+' to '+test]=hits
   if test in ('Ferry','Rigging'):assert all(hits),(name,test,hits)
   if test=='Central crossing':assert not any(hits),(name,test,hits)
   if test=='Receiving bay': assert all(hits) if name=='Dispatch' else not any(hits),(name,test,hits)
 report['sampled_rooftop_sightlines']=sights
 count=0
 for eye_x in (3.8,4.6):
  for eye_h in (40/25.4,2.8,5.4):
   for h in (1.80,1.93,2.012):
    for v in (-.94,-.05,.89):
     a=(-2.72+eye_x,4+eye_h,-8.35-.24);b=(-2.72+1.516,4+h,-8.35+v)
     assert not sight(a,b,['f51014']),(a,b);count+=1
 report['unobstructed_weigh_office_sign_samples']=count
 for gid in ['f51ad0','f51ad1','f51ad2','f51ad3','f51ad4']:
  for physical in [False,True]:
   model_data=model(gid,physical)[0];assert abs(model_data[:,:,[0,2]]).max()<=24.001,(gid,physical)
 (ROOT/'Review/geometry-results.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
if __name__=='__main__':main()
