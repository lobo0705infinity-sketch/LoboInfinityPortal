from baseline import *
def reference(i):
 d=json.loads(get('https://api.polyhaven.com/files/'+i))
 kind=next(k for k in ('Diffuse','diffuse','color','Color','albedo','Albedo')if k in d)
 ver=d[kind]['1k'];url=(ver.get('jpg')or ver['png'])['url']
 write(url,R/'saltwick/Review/photos'/(i+'.jpg'))
def control(n):
 listing=json.loads(get('https://api.github.com/repos/lobo0705infinity-sketch/LoboInfinityPortal/contents/tts-map-controls-standard?ref='+sha))
 items=[x for x in listing if x['type']=='file' and x['name'].endswith(('.py','.json','.lua'))]
 with ThreadPoolExecutor(8)as w:list(w.map(lambda f:write(f['download_url'],R/'controls'/f['path']),items))
 print('Canonical validation files:',len(items),flush=True)
with ThreadPoolExecutor(3)as w:
 jobs=[w.submit(reference,i)for i in ['concrete_wall_003','rusty_painted_metal']]+[w.submit(control,True)]
 for j in jobs:j.result()
