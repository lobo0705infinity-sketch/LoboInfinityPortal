"""Rebuild the R3 terrain against the immutable playtest inputs."""
from pathlib import Path
import os,subprocess,sys
base=Path(__file__).resolve().parent.parent
os.chdir(base)
for directory in ('saltwick3/Review','saltwick3/Assets','saltwick3/Release','saltwick3/bundle/Files','saltwick3/delivery'):(base/directory).mkdir(parents=True,exist_ok=True)
for script in ['recovery/baseline.py','recovery/extras.py','saltwick3/Source/finishes3.py','saltwick3/Source/repairs.py','saltwick3/Source/yard.py','saltwick3/Source/buildings.py']:
 subprocess.run([sys.executable,script],check=True)
sha=sys.argv[1] if len(sys.argv)>1 else '763993a9b01f032883fdd578f55365b0d1da0e44'
subprocess.run([sys.executable,'saltwick3/Source/package_map.py',sha],check=True)
