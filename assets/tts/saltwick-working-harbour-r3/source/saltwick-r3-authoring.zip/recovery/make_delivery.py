"""Assemble the ready table, Stage object and Windows installer after saving review renders."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont,ImageOps
import json,hashlib,zipfile,sys
root=Path('saltwick3')
rel=root/'Release';rev=root/'Review';bundle=root/'bundle';delivery=root/'delivery'
name='Lobo-Saltwick-Floodgate-Working-Harbour-R3-Playtest.zip'
def writezip(dest,items):
 with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for k,v in sorted(items.items()):z.writestr(k,v)
def previews():
 with Image.open(rev/'overview.png')as im:
  im.convert('RGB').resize((640,533),Image.Resampling.LANCZOS).save(rel/'Preview.png',optimize=True)
 canvas=Image.new('RGB',(1464,1000),(26,39,42));draw=ImageDraw.Draw(canvas)
 ft='/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed'
 font=ImageFont.truetype(ft+'-Bold.ttf',25)
 entries=[('gully','Vacuum tanker and open gully'),('office','Weighbridge office'),('engine','Slipway engine overhaul'),('bridge','Ferry gangway'),('gate','Floodgate inspection steps'),('wicket','Customs crew wicket')]
 for i,(asset,label) in enumerate(entries):
  x=18+(i%3)*482;y=18+(i//3)*491
  with Image.open(rev/(asset+'.png'))as im:
   tile=ImageOps.fit(im.convert('RGB'),(464,411),method=Image.Resampling.LANCZOS)
   canvas.paste(tile,(x,y))
  draw.text((x+1,y+431),label,font=font,fill=(232,230,209))
 canvas.save(rel/'Saltwick-R3-Terrain.jpg',quality=91,optimize=True,subsampling=0)
def assemble():
 previews()
 data={n:(rel/n).read_bytes()for n in ('Play-Table.json','Saltwick-Floodgate.json','Preview.png')}
 data['manifest.json']=json.dumps({n:hashlib.sha256(v).hexdigest()for n,v in data.items()},sort_keys=True).encode()
 writezip(bundle/'Files/payload.zip',data)
 files={'Install.cmd':(bundle/'Install.cmd').read_bytes(),'Lobo-Saltwick-Harbour-R3-Setup.exe':(bundle/'Lobo-Saltwick-Harbour-R3-Setup.exe').read_bytes(),'Files/payload.zip':(bundle/'Files/payload.zip').read_bytes(),'Readme.txt':(bundle/'Readme.txt').read_bytes()}
 writezip(delivery/name,files);print((delivery/name).stat().st_size,'bytes')
if __name__=='__main__':assemble()
