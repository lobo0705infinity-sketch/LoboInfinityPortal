from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from urllib.request import urlopen,Request
from urllib.parse import urlparse
from hashlib import sha1
import time, json,re
R=Path(__file__).resolve().parent.parent
repo='https://raw.githubusercontent.com/lobo0705infinity-sketch/LoboInfinityPortal/'
sha='1d201f004e8e29de3904c14afb159f75b1120822'
prefix='assets/tts/saltwick-working-harbour-r2/'
def get(url):
 for j in range(5):
  try:
   with urlopen(Request(url,headers={'User-Agent':'Saltwick-map-release'}),timeout=32) as r:
    assert r.status==200
    return r.read()
  except Exception:
   if j==4:raise
   time.sleep(.75+j)
def write(url,path):
 path=Path(path);path.parent.mkdir(exist_ok=True,parents=True)
 if not path.exists():path.write_bytes(get(url))
 return path
def local(url):
 fname=url.rsplit('/',1)[-1]
 if '/saltwick-quay-review/' in url:return R/'saltwick/Assets'/fname
 if '/saltwick-working-harbour-r2/' in url:return R/'saltwick2/Assets'/fname
 return R/'saltwick/Review/cache'/(sha1(url.encode()).hexdigest()[:9]+'-'+fname)
def links(o):
 if isinstance(o,list):
  for x in o:yield from links(x)
 if isinstance(o,dict):
  for k,x in o.items():
   if k.endswith('URL') and isinstance(x,str) and x.startswith(('https://','http://')):yield x
   elif isinstance(x,(list,dict)):yield from links(x)
def main():
 base=repo+sha+'/'+prefix
 desired={**{'source/'+n+'.py':R/'saltwick2/Source'/(n+'.py') for n in ['mesh','props','fleet','harbour','finishes','rebuild']},
  'release/Saltwick-Floodgate.json':R/'saltwick2/Release/Saltwick-Floodgate.json','release/Saltwick-Floodgate-R2-Playtest-Table.json':R/'saltwick2/Release/Play-Table.json',
  'release/Lobo-Saltwick-Floodgate-Working-Harbour-R2-Playtest.zip':R/'recovery/R2.zip'}
 with ThreadPoolExecutor(8) as pool:list(pool.map(lambda p:write(base+p[0],p[1]),desired.items()))
 b=json.loads((R/'saltwick2/Release/Saltwick-Floodgate.json').read_bytes())['ObjectStates'][0]
 owner=next(x for x in b['ContainedObjects']if x['GUID']=='f5100d')
 cfg=json.loads(json.loads(re.search(r'^local backgroundConfig=JSON.decode\((.+)\)$',owner['LuaScript'],re.M)[1]))
 urls=sorted(set(links(b['ContainedObjects']))|{cfg[k]for k in ('day','night','off')})
 with ThreadPoolExecutor(12)as pool:list(pool.map(lambda u:write(u,local(u)),urls))
 (R/'recovery/base-resources.json').write_text(json.dumps({u:str(local(u).relative_to(R))for u in urls},indent=1))
 preserved=['AGENTS.md','assets/tts/AGENTS.md','tts-map-controls-standard/STANDARD.md','tts-map-controls-standard/validate_release.py','tts-map-controls-standard/test_standard.py','tts-map-controls-standard/test_zones.py','tts-map-controls-standard/test_workshop_startup.py','tts-map-controls-standard/standard-broker.lua']
 with ThreadPoolExecutor(6)as pool:list(pool.map(lambda p:write(repo+sha+'/'+p,R/'controls'/p),preserved))
 from zipfile import ZipFile
 import io
 with ZipFile(R/'recovery/R2.zip')as z:
  print('Recovered installer:',z.namelist(),flush=True)
  with ZipFile(io.BytesIO(z.read('Files/payload.zip')))as zp:
   (R/'saltwick2/Release/Preview.png').write_bytes(zp.read('Preview.png'))
 print('Recovered R2',len(urls),'exact map and sky assets',flush=True)
if __name__=='__main__':main()
