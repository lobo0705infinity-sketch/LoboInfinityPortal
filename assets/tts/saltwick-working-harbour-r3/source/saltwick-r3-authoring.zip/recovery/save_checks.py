from pathlib import Path
import json
from collections import Counter
root=Path('saltwick3');counts=Counter()
def walk(node):
 if isinstance(node,dict):
  for k,v in node.items():
   if k=='ColorDiffuse' or k.lower()=='visiblecolor':
    assert isinstance(v,dict) and set('rgb')<=v.keys() and all(type(x) in (int,float) for x in v.values()),(k,v)
    counts[k]+=1
   if k.endswith('URL') and isinstance(v,str) and v:
    assert not v.startswith(('file:/','C:','/workspace/','http://localhost')),v
   walk(v)
 elif isinstance(node,list):
  for item in node:walk(item)
for filename in ['Play-Table.json','Saltwick-Floodgate.json']:
 path=root/'Release'/filename;data=path.read_bytes()
 assert not any(v in data for v in (b'file://',b'/workspace/',b'localhost:',b'127.0.0.1:',b'C:\\\\'))
 walk(json.loads(data))
print('Valid typed colour fields:',dict(counts))
