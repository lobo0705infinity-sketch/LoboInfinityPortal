from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from collections import Counter
from hashlib import sha256
from io import BytesIO
import sys,re,json,math
from PIL import Image
from baseline import get,links
sys.path.insert(0,'saltwick3/Source')
from common import local,PREFIX,ASSETS,ROOT
r2=json.loads(Path('saltwick2/Release/Play-Table.json').read_bytes())
r3=json.loads((ROOT/'Release/Play-Table.json').read_bytes())
bag=json.loads((ROOT/'Release/Saltwick-Floodgate.json').read_bytes())['ObjectStates'][0]
db={o['GUID']:o for o in r3['ObjectStates']}
objs=bag['ContainedObjects']; ids={o['GUID'] for o in objs}
assert len(ids)==len(objs)==62
assert len(r3['ObjectStates'])==len(r2['ObjectStates'])+5
assert all(obj==db[obj['GUID']] for obj in r2['ObjectStates'] if obj['GUID'] not in ids)
prev={x['GUID']:x for x in r2['ObjectStates']}
assert db['f5100c']==prev['f5100c']
for o in objs:
 assert set(links(o))==set(links(db[o['GUID']]))
 assert not any(key in json.dumps(o)for key in ('file://','/workspace/scratch','localhost:'))
for uid in ('f51021','f51022','f51023'): assert db[uid]==prev[uid]
for k in ['ColliderURL','DiffuseURL','NormalURL']:assert db['f5103a']['CustomMesh'][k]==prev['f5103a']['CustomMesh'][k]
owner=db['f5100d']['LuaScript'];pattern=r'^ local config=JSON.decode\((.+)\)$'
assert re.sub(pattern,'',owner,flags=re.M)==re.sub(pattern,'',prev['f5100d']['LuaScript'],flags=re.M)
cfg=json.loads(json.loads(re.search(pattern,owner,re.M)[1]))
assert all(g in cfg['guids']for g in ids-{'f5100d'}) 
poses={m[1]:list(map(float,m[2].split(','))) for m in re.finditer(r'^--([a-f0-9]{6}),([^\n]+)',bag['LuaScript'],re.M)}
assert len(poses)==len(ids) and poses.keys()==ids
for guid,pose in poses.items():
 t=db[guid]['Transform']
 assert all(abs(a-t[b])<.003 for a,b in zip(pose,['posX','posY','posZ','rotX','rotY','rotZ'])),guid
background=json.loads(json.loads(re.search(r'^local backgroundConfig=JSON.decode\((.+)\)$',owner,re.M)[1]))
urls=sorted(set(links(objs))|{background[k]for k in ['day','night','off']})
new=[u for u in urls if PREFIX in u];assert set(u.split('/')[-1] for u in new)=={f.name for f in ASSETS.iterdir() if f.suffix in {'.obj','.jpg','.png'}}
def verify(u):
 assert u.startswith('https://'),u
 if 'raw.githubusercontent' in u:assert re.search('/[a-f0-9]{40}/',u),u
 expected=local(u).read_bytes();b=get(u);assert b==expected,u
 path=local(u);summary={'sha256':sha256(b).hexdigest(),'bytes':len(b)}
 if b.startswith((b'\xff\xd8',b'\x89PNG')):
  with Image.open(BytesIO(b)) as im:im.load();summary['size']=list(im.size)
 elif path.suffix=='.obj':
  vs=Counter();tri=0;groups=Counter();g=0
  for line in b.splitlines():
   parts=line.split()
   if not parts or parts[0].startswith(b'#'):continue
   if parts[0] in (b'v',b'vt',b'vn'):
    vs[parts[0]]+=1;assert all(math.isfinite(float(x)) for x in parts[1:]),path
   if parts[0] in (b'o',b'g'):g+=1
   if parts[0]==b'f':
    for part in parts[1:]:
     for ix,v in zip(part.split(b'/'),(b'v',b'vt',b'vn')):
      if ix:assert 0<int(ix)<=vs[v],(path,v,ix,vs)
    n=len(parts)-3;tri+=n;groups[g]+=n
  assert tri>0 and vs[b'v']>0
  if PREFIX in u:
   assert 3*tri<=25000,(path,tri)
   if path.name.endswith('-col.obj'):assert max(groups.values())<=255,(path,groups)
   else:assert vs[b'vt']>0 and vs[b'vn']>0,path
  summary.update(triangles=tri)
 return u,summary
with ThreadPoolExecutor(10) as pool:report=dict(pool.map(verify,urls))
(ROOT/'Review/hosted.json').write_text(json.dumps(report,indent=1))
print('VERIFIED',len(urls),'exact asset URLs;',len(new),'new assets;',sum(local(u).suffix=='.obj' for u in new),'new meshes/colliders')
