from pathlib import Path
import sys,bpy,json,math
from mathutils import Vector,Matrix
from functools import lru_cache
from hashlib import sha1
ws=Path.cwd();r=ws/'saltwick3/Review';release=ws/'saltwick3/Release';cache=json.loads((ws/'recovery/base-resources.json').read_text())
def file(url):return (ws/'saltwick3/Assets'/url.rsplit('/',1)[-1]) if 'saltwick-working-harbour-r3/'in url else ws/cache[url]
bpy.ops.wm.read_factory_settings(use_empty=True)
scene=bpy.context.scene
@lru_cache(None)
def mat(path):
 m=bpy.data.materials.new(path.name);m.use_nodes=True
 nodes=m.node_tree.nodes;shader=nodes.get('Principled BSDF');shader.inputs['Roughness'].default_value=.78
 t=nodes.new('ShaderNodeTexImage');t.image=bpy.data.images.load(str(path),check_existing=True);t.interpolation='Linear'
 m.node_tree.links.new(t.outputs['Color'],shader.inputs['Base Color']);return m
@lru_cache(None)
def data(path,texture):
 v=[];u=[];poly=[];tex=[]
 for row in path.read_text(errors='replace').splitlines():
  if row.startswith('v '):
   x,h,z=map(float,row.split()[1:4]);v.append((-x,z,h))
  elif row.startswith('vt '):u.append(tuple(map(float,row.split()[1:3])))
  elif row.startswith('f '):
   f=[a.split('/')for a in row.split()[1:]];poly.append([int(a[0])-1 for a in f]);tex.extend([int(a[1])-1 if len(a)>1 and a[1] else 0 for a in f])
 m=bpy.data.meshes.new(path.stem);m.from_pydata(v,[],poly);m.update()
 if u:
  layer=m.uv_layers.new(name='UVMap');layer.data.foreach_set('uv',[n for index in tex for n in u[index]])
 m.materials.append(mat(texture));return m
def add(name,m):o=bpy.data.objects.new(name,m);scene.collection.objects.link(o);return o
def put(name,o,path,tex):
 e=add(name,data(path,tex));t=o['Transform'];e.location=(t['posX'],t['posZ'],t['posY']-4);e.scale=(t['scaleX'],t['scaleZ'],t['scaleY'])
 w=Matrix(((1,0,0),(0,0,1),(0,1,0)));q=Matrix.Rotation(math.radians(t['rotY']),3,'Y')@Matrix.Rotation(math.radians(t['rotX']),3,'X')@Matrix.Rotation(math.radians(t['rotZ']),3,'Z')
 e.rotation_mode='QUATERNION';e.rotation_quaternion=(w@q@w).to_quaternion()
objs=json.loads((release/'Play-Table.json').read_bytes())['ObjectStates']
for o in objs:
 g=o['GUID']
 if 'LoboMap:1002d9' not in o.get('Tags',[]) and g!='7e9e14':continue
 if g=='f5100b':
  m=bpy.data.meshes.new('Paving');m.from_pydata([(-24,-24,-.017),(24,-24,-.017),(24,24,-.017),(-24,24,-.017)],[],[(0,1,2,3)]);uv=m.uv_layers.new();uv.data.foreach_set('uv',[0,0,1,0,1,1,0,1]);m.materials.append(mat(file(o['CustomImage']['ImageURL'])));add(g,m)
 elif g=='f5100c':put(g,o,r/'console-shaped.obj',r/'console.png')
 elif o.get('CustomMesh'):
  c=o['CustomMesh'];put(g,o,file(c['MeshURL']),file(c['DiffuseURL']))
world=bpy.data.worlds.new('Exterior daylight');scene.world=world;world.use_nodes=True
world.node_tree.nodes['Background'].inputs[0].default_value=(.72,.80,.94,1);world.node_tree.nodes['Background'].inputs[1].default_value=.72
sun=bpy.data.lights.new('Afternoon sun','SUN');sun.energy=2.6;sun.angle=math.radians(13);l=add('Key daylight',sun);l.rotation_euler=(math.radians(30),math.radians(-34),math.radians(-28))
bpy.ops.mesh.primitive_plane_add(size=250,location=(0,0,-3.16));back=bpy.context.object;back.name='Studio floor';m=bpy.data.materials.new('Dark slate');m.diffuse_color=(.038,.064,.076,1);back.data.materials.append(m)
cam=bpy.data.cameras.new('Review camera');co=add('Review camera',cam);scene.camera=co;cam.type='ORTHO';cam.clip_end=500
scene.render.engine='CYCLES';scene.cycles.samples=14;scene.cycles.use_denoising=False;scene.render.threads_mode='FIXED';scene.render.threads=8;scene.render.resolution_percentage=100
scene.view_settings.view_transform='AgX';scene.view_settings.exposure=.8;scene.view_settings.look='AgX - Medium High Contrast';scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGB'
shots={'overview':((-.4,0,1),(-52,1,76),57,(1380,1150)),'engine':((-6.78,9.24,1.03),(.8,-2.86,3.58),4.32,(840,580)),'office':((-1.235,-8.39,1.85),(3.3,.15,-.22),3.35,(840,580)),'crew':((-12.1,7.22,1.1),(-6.4,-1.92,3.65),9,(840,580)),'gully':((-13.32,-.46,.92),(-1.48,2.85,5.9),7.45,(840,580)),'gate':((21.3,-4.25,1.26),(-1.95,-2.24,3.3),7.65,(840,580)),'bridge':((22.55,22.20,.59),(-3.2,4.6,2.8),6.9,(840,580)),'wicket':((-8.70,-15.11,1.05),(.8,1.55,2.72),5.4,(840,580))}
for name,(target,delta,width,res) in shots.items():
 co.location=Vector(target)+Vector(delta);co.rotation_euler=(-Vector(delta)).to_track_quat('-Z','Y').to_euler();cam.ortho_scale=width
 for e in scene.objects:
  if e.name.startswith('f51') or e.name=='7e9e14':e.hide_render=(name=='gully' and e.name not in {'f5103a','f51ad0','f5100b','7e9e14'})
 scene.render.resolution_x,scene.render.resolution_y=res;scene.render.filepath=str(r/(name+'.png'));bpy.ops.render.render(write_still=True)
