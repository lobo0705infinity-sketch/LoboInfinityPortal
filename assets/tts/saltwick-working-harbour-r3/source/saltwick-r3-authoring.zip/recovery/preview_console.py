"""Extract the existing table's original 40 mm console for the offline thumbnail."""
import json,sys
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation
import UnityPy
ws=Path.cwd();rev=ws/'saltwick3/Review'
room=json.loads((ws/'saltwick3/Release/Play-Table.json').read_bytes())
obj=next(o for o in room['ObjectStates'] if o['GUID']=='f5100c')
url=obj['CustomAssetbundle']['AssetbundleURL']
bundle=UnityPy.load(str(ws/json.loads((ws/'recovery/base-resources.json').read_text())[url]))
def vector(p,n):return np.array([getattr(p,a)for a in 'xyzw'[:n]])
for entry in bundle.objects:
 if entry.type.name=='Transform':
  tf=entry.read()
  if tf.m_Father.path_id:child=tf
  else:parent=tf
 elif entry.type.name=='Mesh':mesh=entry.read().export()
 elif entry.type.name=='Texture2D':entry.read().image.save(rev/'console.png')
rot=Rotation.from_quat(vector(child.m_LocalRotation,4))
root_rotation=Rotation.from_quat(vector(parent.m_LocalRotation,4))
res=[]
for line in mesh.splitlines():
 fields=line.split()
 if fields and fields[0] in ('v','vn'):
  p=np.array(list(map(float,fields[1:4])))*[-1,1,1]
  if fields[0]=='v':
   p=rot.apply(p*vector(child.m_LocalScale,3))+vector(child.m_LocalPosition,3)
   p=root_rotation.apply(p*vector(parent.m_LocalScale,3))+vector(parent.m_LocalPosition,3)
  else:p=root_rotation.apply(rot.apply(p))
  res.append(fields[0]+' '+' '.join(str(x)for x in p*[-1,1,1]))
 else:res.append(line)
(rev/'console-shaped.obj').write_text('\n'.join(res)+'\n')
