# Saltwick Floodgate, Working Harbour R3

The map is a playtest of Area of Interest. Source uses inches for table positions. The generator stores TTS OBJ coordinates and deploys models through the map's existing Stage bag and full save.

## Build the map

Use Python 3 with NumPy, SciPy, Pillow and DejaVu fonts. Run from the extracted archive root on Linux.

```sh
python recovery/rebuild.py
```

This downloads the immutable R2 save and its existing models, two CC0 Poly Haven reference textures and the original repository's control validators. The script generates the R3 wavefront meshes and textures in `saltwick3/Assets/`, then applies their published R3 URLs to the complete table and bag in `saltwick3/Release/`. A different immutable asset commit may be passed as the first argument when preparing a future revision. New exports use the current time for the TTS save metadata.

## Review

Use Shapely 2 and Lupa with Lua 5.2 support for the geometry and controls checks. The tests assume the working directory is the archive root.

```sh
python recovery/verify_assets.py
python recovery/geometry.py
python recovery/controls_check.py
python recovery/save_checks.py
blender -b -t 2 --python-exit-code 2 -P recovery/mesh_import.py
```

The geometry check compares the collision geometry at base and silhouette heights. The sightline check uses the visible mesh triangles. The console remains the original 40 mm model.

## Installer and preview

Use UnityPy to extract the original console from its existing asset bundle for the thumbnail. Blender renders the published terrain geometry. Go builds the Windows installer and a native binary that exercises the same installation path.

```sh
python recovery/preview_console.py
blender -b -t 8 --python-exit-code 2 -P recovery/render.py
(cd saltwick3/Source/installer && go build -trimpath -o ../../Review/installer-test .)
(cd saltwick3/Source/installer && GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags='-s -w' -o ../../bundle/Lobo-Saltwick-Harbour-R3-Setup.exe .)
python recovery/make_delivery.py
python recovery/check_installer.py
```

No automated offline test starts Tabletop Simulator. A fresh-cache in-game load and a two-player session need to be evaluated in that client.
