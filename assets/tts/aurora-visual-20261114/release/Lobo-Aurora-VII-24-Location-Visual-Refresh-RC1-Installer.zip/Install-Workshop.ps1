param([string]$TtsRoot)
$ErrorActionPreference = 'Stop'
$tempSave = $null
$tempImage = $null
try {
    if (-not $TtsRoot) {
        $documents = [Environment]::GetFolderPath('MyDocuments')
        $TtsRoot = Join-Path $documents 'My Games/Tabletop Simulator'
    }
    $saveDir = Join-Path $TtsRoot 'Saves'
    if (-not (Test-Path -LiteralPath $saveDir -PathType Container)) {
        throw 'Tabletop Simulator Saves was not found. Open TTS and save a game first. For a custom data location, drag the Tabletop Simulator data folder onto INSTALL.cmd.'
    }

    $payload = Join-Path $PSScriptRoot 'Workshop-Save.json'
    $thumbnail = Join-Path $PSScriptRoot 'Workshop-Save.png'
    $expected = 'DE34E3BE8D1BE7E1BC220FF81B2C460D0B102291A7DCF70DA397F3FB4DA3A33B'
    if ((Get-FileHash -LiteralPath $payload -Algorithm SHA256).Hash -ne $expected) {
        throw 'Workshop save checksum failed. Extract a fresh copy of the entire installer ZIP.'
    }

    $tempSave = Join-Path $saveDir ([Guid]::NewGuid().ToString('N') + '.installing')
    [IO.File]::Copy($payload, $tempSave, $false)
    if ((Get-FileHash -LiteralPath $tempSave -Algorithm SHA256).Hash -ne $expected) { throw 'Installed save checksum failed.' }

    $slot = 1
    while ($true) {
        $stem = 'TS_Save_' + $slot
        $target = Join-Path $saveDir ($stem + '.json')
        $imageTarget = Join-Path $saveDir ($stem + '.png')
        if (-not (Test-Path -LiteralPath $target) -and -not (Test-Path -LiteralPath $imageTarget)) {
            try {
                [IO.File]::Move($tempSave, $target)
                break
            } catch [IO.IOException] {
                if (-not (Test-Path -LiteralPath $target)) { throw }
            }
        }
        $slot++
    }

    try {
        $tempImage = Join-Path $saveDir ([Guid]::NewGuid().ToString('N') + '.installing')
        [IO.File]::Copy($thumbnail, $tempImage)
        [IO.File]::Move($tempImage, $imageTarget)
    } catch {
        Write-Warning 'The save installed successfully. Its thumbnail could not be installed.'
    }

    Write-Host 'Installed: Lobo Infinity Maps - Aurora VII 24 Locations Visual Refresh - RC1' -ForegroundColor Green
    Write-Host $target
    Write-Host 'Load this save in Games > Save & Load. All visual assets are already hosted publicly. Use Upload > Workshop Upload > Update Workshop, enter 3719263238 and click Update.'
    try {
        Start-Process 'https://steamcommunity.com/sharedfiles/filedetails/?id=3719263238'
    } catch {
        Write-Warning 'Open Steam Workshop item 3719263238 in your browser.'
    }
    exit 0
} catch {
    Write-Host ('Installation failed: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
} finally {
    foreach ($temp in @($tempSave, $tempImage)) {
        if ($temp -and (Test-Path -LiteralPath $temp -PathType Leaf)) {
            Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue
        }
    }
}
