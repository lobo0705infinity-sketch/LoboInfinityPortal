@echo off
setlocal
if "%~1"=="" (
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Workshop.ps1"
) else (
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Workshop.ps1" -TtsRoot "%~1"
)
set "LOBO_INSTALL_EXIT=%ERRORLEVEL%"
echo.
pause
exit /b %LOBO_INSTALL_EXIT%
