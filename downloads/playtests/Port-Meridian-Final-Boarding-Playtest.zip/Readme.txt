﻿PORT MERIDIAN — FINAL BOARDING
Last Launch | Lobo’s Infinity Maps | TTS playtest

On Windows, extract the entire ZIP and double-click Install.cmd. In Tabletop
Simulator, open Games > Save & Load > Port Meridian - Final Boarding -
Last Launch Playtest. The full map opens with the aircraft parked at Stand 04.

The installer adds a fresh numbered save and a Port Meridian - Final Boarding
bag to Objects > Saved Objects. Drop that bag onto a clean standard Infinity
Stage to deploy it. For a custom TTS data location, drag your Tabletop
Simulator data folder or its Saves folder onto Install.cmd.

To inspect a building, hover over it and choose its numbered native state.
State 1 is the ground floor. The map panel also has Shared interiors, which
changes the physical floors for everyone. Leave the central tower open during
Last Launch. The play table includes the mission link and map controls.

On macOS or Linux, open Files/payload.zip. Copy Play-Table.json and Preview.png
to the TTS Saves folder as TS_Save_N.json and TS_Save_N.png, using the same
unused number in both names. Copy Port-Meridian-Final-Boarding.json and a
second copy of Preview.png to Saves/Saved Objects, giving both the stem
Port Meridian - Final Boarding.

Review/Port-Meridian-Final-Boarding-Review.pdf includes the saved map viewed
from above, miniature-scale close-ups and the annotated original screenshot.
