@echo off
"%~dp0Port-Meridian-Setup.exe" %*
set "port_status=%errorlevel%"
echo.
pause
exit /b %port_status%
